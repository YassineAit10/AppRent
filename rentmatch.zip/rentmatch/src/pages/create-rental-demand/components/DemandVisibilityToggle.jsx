import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const DemandVisibilityToggle = ({ 
  visibility = 'open', 
  onVisibilityChange,
  showDetails = true 
}) => {
  const [selectedVisibility, setSelectedVisibility] = useState(visibility);

  const visibilityOptions = [
    {
      id: 'open',
      title: 'Marché ouvert',
      description: 'Votre demande sera visible par toutes les agences partenaires',
      icon: 'Globe',
      color: 'primary',
      benefits: [
        'Plus d\'offres disponibles',
        'Concurrence entre agences',
        'Meilleurs prix possibles',
        'Réponse plus rapide'
      ],
      drawbacks: [
        'Qualité variable des agences',
        'Vérification manuelle requise'
      ]
    },
    {
      id: 'verified',
      title: 'Agences vérifiées uniquement',
      description: 'Seules les agences certifiées et bien notées peuvent répondre',
      icon: 'ShieldCheck',
      color: 'success',
      benefits: [
        'Agences pré-vérifiées',
        'Historique de qualité',
        'Service client garanti',
        'Moins de risques'
      ],
      drawbacks: [
        'Moins d\'offres disponibles',
        'Prix potentiellement plus élevés'
      ]
    },
    {
      id: 'premium',
      title: 'Agences premium',
      description: 'Uniquement les agences avec les meilleures notes et certifications',
      icon: 'Crown',
      color: 'warning',
      benefits: [
        'Service premium garanti',
        'Véhicules haut de gamme',
        'Support prioritaire',
        'Garantie satisfaction'
      ],
      drawbacks: [
        'Choix limité d\'agences',
        'Tarifs premium'
      ]
    }
  ];

  const handleVisibilityChange = (newVisibility) => {
    setSelectedVisibility(newVisibility);
    onVisibilityChange(newVisibility);
  };

  const getColorClasses = (color, isSelected) => {
    const colorMap = {
      primary: isSelected ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50',
      success: isSelected ? 'border-success bg-success/10 text-success' : 'border-border hover:border-success/50',
      warning: isSelected ? 'border-warning bg-warning/10 text-warning' : 'border-border hover:border-warning/50'
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  const selectedOption = visibilityOptions?.find(opt => opt?.id === selectedVisibility);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Visibilité de votre demande</h3>
        <p className="text-sm text-muted-foreground">
          Choisissez qui peut voir et répondre à votre demande de location
        </p>
      </div>
      {/* Visibility Options */}
      <div className="space-y-4">
        {visibilityOptions?.map((option) => {
          const isSelected = selectedVisibility === option?.id;
          return (
            <div
              key={option?.id}
              onClick={() => handleVisibilityChange(option?.id)}
              className={`relative cursor-pointer rounded-lg border-2 p-6 transition-all hover:shadow-md ${
                getColorClasses(option?.color, isSelected)
              }`}
            >
              <div className="flex items-start space-x-4">
                {/* Icon */}
                <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                  isSelected 
                    ? `bg-${option?.color}/20 text-${option?.color}`
                    : 'bg-muted text-muted-foreground'
                }`}>
                  <Icon name={option?.icon} size={24} />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-lg font-semibold">{option?.title}</h4>
                    {isSelected && (
                      <div className={`w-6 h-6 rounded-full bg-${option?.color} flex items-center justify-center`}>
                        <Icon name="Check" size={14} color="white" />
                      </div>
                    )}
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-4">
                    {option?.description}
                  </p>

                  {showDetails && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Benefits */}
                      <div>
                        <h5 className="text-sm font-medium text-success mb-2 flex items-center">
                          <Icon name="Plus" size={14} className="mr-1" />
                          Avantages
                        </h5>
                        <ul className="space-y-1">
                          {option?.benefits?.map((benefit, index) => (
                            <li key={index} className="text-xs text-muted-foreground flex items-center">
                              <Icon name="Check" size={12} className="mr-2 text-success flex-shrink-0" />
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Drawbacks */}
                      <div>
                        <h5 className="text-sm font-medium text-warning mb-2 flex items-center">
                          <Icon name="Minus" size={14} className="mr-1" />
                          Inconvénients
                        </h5>
                        <ul className="space-y-1">
                          {option?.drawbacks?.map((drawback, index) => (
                            <li key={index} className="text-xs text-muted-foreground flex items-center">
                              <Icon name="AlertCircle" size={12} className="mr-2 text-warning flex-shrink-0" />
                              {drawback}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {/* Selected Option Summary */}
      <div className={`bg-${selectedOption?.color}/5 border border-${selectedOption?.color}/20 rounded-lg p-4`}>
        <div className="flex items-center space-x-3">
          <Icon name={selectedOption?.icon} size={20} className={`text-${selectedOption?.color}`} />
          <div>
            <p className={`text-sm font-medium text-${selectedOption?.color}`}>
              Option sélectionnée: {selectedOption?.title}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {selectedOption?.description}
            </p>
          </div>
        </div>
      </div>
      {/* Statistics */}
      <div className="bg-muted/50 rounded-lg p-4">
        <h5 className="text-sm font-medium text-foreground mb-3 flex items-center">
          <Icon name="BarChart3" size={16} className="mr-2 text-primary" />
          Statistiques par type de visibilité
        </h5>
        
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-xs text-muted-foreground">Marché ouvert</p>
            <p className="text-lg font-semibold text-foreground">~8</p>
            <p className="text-xs text-muted-foreground">offres moyennes</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Agences vérifiées</p>
            <p className="text-lg font-semibold text-foreground">~5</p>
            <p className="text-xs text-muted-foreground">offres moyennes</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Premium</p>
            <p className="text-lg font-semibold text-foreground">~3</p>
            <p className="text-xs text-muted-foreground">offres moyennes</p>
          </div>
        </div>
      </div>
      {/* Tips */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-foreground">Conseil</p>
            <p className="text-xs text-muted-foreground">
              {selectedVisibility === 'open' && 
                "Le marché ouvert vous donne accès au plus grand nombre d'offres. Vérifiez toujours les avis et certifications des agences avant de réserver."
              }
              {selectedVisibility === 'verified' && 
                "Les agences vérifiées offrent un bon équilibre entre choix et qualité. Elles ont été pré-validées par notre équipe."
              }
              {selectedVisibility === 'premium' && 
                "Les agences premium garantissent le meilleur service mais avec moins de choix. Idéal pour les occasions spéciales."
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DemandVisibilityToggle;