import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const OfferTemplates = ({ templates, onUseTemplate, onCreateTemplate, onEditTemplate }) => {
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const defaultTemplates = [
    {
      id: 'economy-standard',
      name: 'Économique Standard',
      category: 'economy',
      description: 'Offre standard pour véhicules économiques',
      vehicleType: 'Économique',
      basePrice: 35,
      features: ['Assurance de base', 'Kilométrage illimité', 'Carburant non inclus'],
      terms: 'Paiement à la prise en charge. Caution de 300€ requise.',
      responseTime: '2h',
      validityPeriod: '24h',
      usageCount: 15
    },
    {
      id: 'premium-package',
      name: 'Premium Tout Inclus',
      category: 'premium',
      description: 'Offre premium avec services inclus',
      vehicleType: 'Premium/Luxe',
      basePrice: 85,
      features: ['Assurance tous risques', 'GPS inclus', 'Carburant plein/plein', 'Nettoyage inclus'],
      terms: 'Paiement sécurisé en ligne. Aucune caution requise.',
      responseTime: '1h',
      validityPeriod: '48h',
      usageCount: 8
    },
    {
      id: 'business-express',
      name: 'Business Express',
      category: 'business',
      description: 'Réponse rapide pour clientèle professionnelle',
      vehicleType: 'Berline/SUV',
      basePrice: 65,
      features: ['Assurance professionnelle', 'Livraison possible', 'Facture entreprise'],
      terms: 'Paiement sur facture 30 jours. Contrat entreprise requis.',
      responseTime: '30min',
      validityPeriod: '72h',
      usageCount: 12
    }
  ];

  const allTemplates = [...defaultTemplates, ...(templates || [])];

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'economy': return 'DollarSign';
      case 'premium': return 'Star';
      case 'business': return 'Briefcase';
      default: return 'FileText';
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'economy': return 'text-success bg-success/10';
      case 'premium': return 'text-warning bg-warning/10';
      case 'business': return 'text-primary bg-primary/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const handleTemplateSelect = (template) => {
    setSelectedTemplate(template?.id === selectedTemplate?.id ? null : template);
  };

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="FileText" size={20} className="text-primary" />
          <h3 className="font-semibold text-foreground">Modèles d'offres</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onCreateTemplate}
          className="text-xs"
        >
          <Icon name="Plus" size={14} />
          Nouveau
        </Button>
      </div>
      {/* Templates List */}
      <div className="max-h-96 overflow-y-auto">
        {allTemplates?.map((template) => (
          <div
            key={template?.id}
            className={`p-4 border-b border-border cursor-pointer transition-colors ${
              selectedTemplate?.id === template?.id ? 'bg-primary/5 border-l-4 border-l-primary' : 'hover:bg-muted/50'
            }`}
            onClick={() => handleTemplateSelect(template)}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3 flex-1">
                <div className={`w-8 h-8 rounded-md flex items-center justify-center ${getCategoryColor(template?.category)}`}>
                  <Icon name={getCategoryIcon(template?.category)} size={16} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-medium text-foreground">{template?.name}</h4>
                    <span className="text-xs text-muted-foreground">
                      ({template?.usageCount} utilisations)
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{template?.description}</p>
                  
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <span className="flex items-center space-x-1">
                      <Icon name="Car" size={12} />
                      <span>{template?.vehicleType}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Icon name="DollarSign" size={12} />
                      <span>{template?.basePrice}€/jour</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Icon name="Clock" size={12} />
                      <span>Réponse {template?.responseTime}</span>
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e?.stopPropagation();
                    onUseTemplate?.(template);
                  }}
                  className="h-8 px-2 text-xs"
                >
                  Utiliser
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e?.stopPropagation();
                    onEditTemplate?.(template);
                  }}
                  className="h-8 w-8"
                >
                  <Icon name="Edit2" size={12} />
                </Button>
              </div>
            </div>

            {/* Expanded Details */}
            {selectedTemplate?.id === template?.id && (
              <div className="mt-4 pt-4 border-t border-border animate-slide-down">
                <div className="space-y-3">
                  {/* Features */}
                  <div>
                    <h5 className="text-sm font-medium text-foreground mb-2">Services inclus</h5>
                    <div className="flex flex-wrap gap-1">
                      {template?.features?.map((feature, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Terms */}
                  <div>
                    <h5 className="text-sm font-medium text-foreground mb-1">Conditions</h5>
                    <p className="text-sm text-muted-foreground">{template?.terms}</p>
                  </div>

                  {/* Template Settings */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Validité offre:</span>
                      <span className="ml-2 font-medium text-foreground">{template?.validityPeriod}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Temps réponse:</span>
                      <span className="ml-2 font-medium text-foreground">{template?.responseTime}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      {/* Quick Actions */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            {allTemplates?.length} modèle(s) disponible(s)
          </span>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-xs">
              <Icon name="Download" size={12} />
              Exporter
            </Button>
            <Button variant="ghost" size="sm" className="text-xs">
              <Icon name="Upload" size={12} />
              Importer
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfferTemplates;