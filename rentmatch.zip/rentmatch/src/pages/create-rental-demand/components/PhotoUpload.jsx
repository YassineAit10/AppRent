import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PhotoUpload = ({ 
  photos = [], 
  onPhotosChange,
  maxPhotos = 5,
  error 
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  // Mock uploaded photos for demonstration
  const mockPhotos = [
    {
      id: 1,
      url: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=400',
      name: 'reference-car-1.jpg',
      size: '2.3 MB',
      type: 'image/jpeg'
    }
  ];

  const [uploadedPhotos, setUploadedPhotos] = useState(photos?.length > 0 ? photos : mockPhotos);

  const handleDrag = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    if (e?.type === "dragenter" || e?.type === "dragover") {
      setDragActive(true);
    } else if (e?.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setDragActive(false);
    
    if (e?.dataTransfer?.files && e?.dataTransfer?.files?.[0]) {
      handleFiles(e?.dataTransfer?.files);
    }
  };

  const handleChange = (e) => {
    e?.preventDefault();
    if (e?.target?.files && e?.target?.files?.[0]) {
      handleFiles(e?.target?.files);
    }
  };

  const handleFiles = (files) => {
    const fileArray = Array.from(files);
    const validFiles = fileArray?.filter(file => {
      const isValidType = file?.type?.startsWith('image/');
      const isValidSize = file?.size <= 10 * 1024 * 1024; // 10MB max
      return isValidType && isValidSize;
    });

    if (validFiles?.length === 0) return;

    setUploading(true);

    // Simulate upload process
    setTimeout(() => {
      const newPhotos = validFiles?.map((file, index) => ({
        id: Date.now() + index,
        url: URL.createObjectURL(file),
        name: file?.name,
        size: formatFileSize(file?.size),
        type: file?.type,
        file: file
      }));

      const updatedPhotos = [...uploadedPhotos, ...newPhotos]?.slice(0, maxPhotos);
      setUploadedPhotos(updatedPhotos);
      onPhotosChange(updatedPhotos);
      setUploading(false);
    }, 1500);
  };

  const removePhoto = (photoId) => {
    const updatedPhotos = uploadedPhotos?.filter(photo => photo?.id !== photoId);
    setUploadedPhotos(updatedPhotos);
    onPhotosChange(updatedPhotos);
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  const canUploadMore = uploadedPhotos?.length < maxPhotos;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Photos de référence</h3>
        <p className="text-sm text-muted-foreground">
          Ajoutez des photos du type de véhicule souhaité pour aider les agences à mieux comprendre vos attentes
        </p>
      </div>
      {error && (
        <div className="text-sm text-error bg-error/10 border border-error/20 rounded-md p-3">
          {error}
        </div>
      )}
      {/* Upload Area */}
      {canUploadMore && (
        <div
          className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragActive 
              ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 hover:bg-muted/50'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*"
            onChange={handleChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
              <Icon name="Upload" size={24} className="text-muted-foreground" />
            </div>
            
            <div>
              <p className="text-lg font-medium text-foreground mb-2">
                Glissez vos photos ici ou cliquez pour sélectionner
              </p>
              <p className="text-sm text-muted-foreground">
                Formats acceptés: JPG, PNG, WebP • Taille max: 10MB par photo
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {uploadedPhotos?.length}/{maxPhotos} photos ajoutées
              </p>
            </div>
            
            <Button variant="outline" size="sm">
              <Icon name="Plus" size={16} className="mr-2" />
              Sélectionner des photos
            </Button>
          </div>
        </div>
      )}
      {/* Upload Progress */}
      {uploading && (
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Icon name="Loader2" size={20} className="animate-spin text-primary" />
            <div className="flex-1">
              <p className="text-sm font-medium text-primary">Téléchargement en cours...</p>
              <div className="w-full bg-primary/20 rounded-full h-2 mt-2">
                <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Uploaded Photos Grid */}
      {uploadedPhotos?.length > 0 && (
        <div className="space-y-4">
          <h4 className="text-md font-semibold text-foreground flex items-center">
            <Icon name="Image" size={18} className="mr-2 text-success" />
            Photos ajoutées ({uploadedPhotos?.length})
          </h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {uploadedPhotos?.map((photo) => (
              <div key={photo?.id} className="relative group">
                <div className="aspect-video rounded-lg overflow-hidden border border-border">
                  <Image
                    src={photo?.url}
                    alt={photo?.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                </div>
                
                {/* Photo Info */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3 rounded-b-lg">
                  <p className="text-white text-sm font-medium truncate">{photo?.name}</p>
                  <p className="text-white/80 text-xs">{photo?.size}</p>
                </div>
                
                {/* Remove Button */}
                <button
                  onClick={() => removePhoto(photo?.id)}
                  className="absolute top-2 right-2 w-8 h-8 bg-error text-error-foreground rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-error/80"
                  title="Supprimer cette photo"
                >
                  <Icon name="X" size={16} />
                </button>
                
                {/* Preview Button */}
                <button
                  className="absolute top-2 left-2 w-8 h-8 bg-background/80 text-foreground rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background"
                  title="Aperçu"
                >
                  <Icon name="Eye" size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Photo Guidelines */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-primary mt-0.5" />
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">Conseils pour de meilleures photos</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Ajoutez des photos du modèle exact ou similaire que vous souhaitez</li>
              <li>• Montrez l'extérieur, l'intérieur et les équipements importants</li>
              <li>• Les photos claires et bien éclairées attirent plus d'offres</li>
              <li>• Évitez les photos floues ou de mauvaise qualité</li>
            </ul>
          </div>
        </div>
      </div>
      {/* Quick Examples */}
      {uploadedPhotos?.length === 0 && (
        <div className="space-y-3">
          <h5 className="text-sm font-medium text-foreground">Exemples de véhicules populaires</h5>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { name: 'Citadine', image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Berline', image: 'https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'SUV', image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=200' },
              { name: 'Utilitaire', image: 'https://images.pexels.com/photos/1335077/pexels-photo-1335077.jpeg?auto=compress&cs=tinysrgb&w=200' }
            ]?.map((example) => (
              <button
                key={example?.name}
                onClick={() => {
                  // Simulate adding example photo
                  const newPhoto = {
                    id: Date.now(),
                    url: example?.image,
                    name: `${example?.name?.toLowerCase()}-reference.jpg`,
                    size: '1.2 MB',
                    type: 'image/jpeg'
                  };
                  const updatedPhotos = [...uploadedPhotos, newPhoto];
                  setUploadedPhotos(updatedPhotos);
                  onPhotosChange(updatedPhotos);
                }}
                className="group relative aspect-video rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors"
              >
                <Image
                  src={example?.image}
                  alt={example?.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="text-center">
                    <Icon name="Plus" size={16} className="text-white mb-1 mx-auto" />
                    <p className="text-white text-xs font-medium">{example?.name}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PhotoUpload;