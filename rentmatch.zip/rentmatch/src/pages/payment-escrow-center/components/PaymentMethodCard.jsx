import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PaymentMethodCard = ({ paymentMethod, isDefault, onSetDefault, onEdit, onDelete }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getMethodIcon = (type) => {
    const icons = {
      card: 'CreditCard',
      bank: 'Building2',
      paypal: 'Wallet',
      apple: 'Smartphone',
      google: 'Chrome'
    };
    return icons?.[type] || 'CreditCard';
  };

  const getMethodColor = (type) => {
    const colors = {
      card: 'text-primary',
      bank: 'text-success',
      paypal: 'text-warning',
      apple: 'text-foreground',
      google: 'text-error'
    };
    return colors?.[type] || 'text-primary';
  };

  const formatCardNumber = (number) => {
    return `•••• •••• •••• ${number?.slice(-4)}`;
  };

  const formatExpiryDate = (month, year) => {
    return `${month?.toString()?.padStart(2, '0')}/${year?.toString()?.slice(-2)}`;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-elevation-2 transition-shadow">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start space-x-3">
          <div className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center`}>
            <Icon name={getMethodIcon(paymentMethod?.type)} size={20} className={getMethodColor(paymentMethod?.type)} />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="font-semibold text-foreground">
                {paymentMethod?.type === 'card' ? paymentMethod?.brand : paymentMethod?.name}
              </h3>
              {isDefault && (
                <span className="px-2 py-1 text-xs bg-primary text-primary-foreground rounded-full font-medium">
                  Par défaut
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              {paymentMethod?.type === 'card' 
                ? formatCardNumber(paymentMethod?.number)
                : paymentMethod?.description
              }
            </p>
            {paymentMethod?.type === 'card' && (
              <p className="text-xs text-muted-foreground mt-1">
                Expire: {formatExpiryDate(paymentMethod?.expiryMonth, paymentMethod?.expiryYear)}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          {paymentMethod?.verified && (
            <div className="w-6 h-6 bg-success/10 rounded-full flex items-center justify-center">
              <Icon name="ShieldCheck" size={14} className="text-success" />
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-8 h-8"
          >
            <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
          </Button>
        </div>
      </div>
      {/* Quick Status */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-3">
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Shield" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Sécurité</p>
          <p className="text-sm font-medium text-foreground">
            {paymentMethod?.verified ? 'Vérifiée' : 'En attente'}
          </p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Calendar" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Ajoutée</p>
          <p className="text-sm font-medium text-foreground">
            {new Date(paymentMethod.addedAt)?.toLocaleDateString('fr-FR')}
          </p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Activity" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Utilisations</p>
          <p className="text-sm font-medium text-foreground">{paymentMethod?.usageCount}</p>
        </div>
      </div>
      {/* Expanded Details */}
      {isExpanded && (
        <div className="border-t border-border pt-3 mt-3 animate-slide-down">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Method Details */}
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Info" size={16} className="mr-2" />
                Détails de la méthode
              </h4>
              <div className="space-y-2 text-sm">
                {paymentMethod?.type === 'card' && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Type de carte:</span>
                      <span className="text-foreground">{paymentMethod?.cardType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Pays d'émission:</span>
                      <span className="text-foreground">{paymentMethod?.country}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Nom du titulaire:</span>
                      <span className="text-foreground">{paymentMethod?.holderName}</span>
                    </div>
                  </>
                )}
                {paymentMethod?.type === 'bank' && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">IBAN:</span>
                      <span className="text-foreground font-mono">
                        {paymentMethod?.iban?.replace(/(.{4})/g, '$1 ')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Banque:</span>
                      <span className="text-foreground">{paymentMethod?.bankName}</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Security Info */}
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Shield" size={16} className="mr-2" />
                Sécurité
              </h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <Icon 
                    name={paymentMethod?.verified ? 'CheckCircle' : 'Clock'} 
                    size={14} 
                    className={paymentMethod?.verified ? 'text-success' : 'text-warning'} 
                  />
                  <span className="text-foreground">
                    {paymentMethod?.verified ? 'Méthode vérifiée' : 'Vérification en cours'}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Icon name="Lock" size={14} className="text-success" />
                  <span className="text-foreground">Chiffrement PCI DSS</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Icon name="Shield" size={14} className="text-success" />
                  <span className="text-foreground">Protection 3D Secure</span>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Transactions */}
          {paymentMethod?.recentTransactions && paymentMethod?.recentTransactions?.length > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="History" size={16} className="mr-2" />
                Transactions récentes
              </h4>
              <div className="space-y-2">
                {paymentMethod?.recentTransactions?.slice(0, 3)?.map((transaction, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted/30 rounded-md">
                    <div className="flex items-center space-x-2">
                      <Icon name="ArrowUpRight" size={14} className="text-muted-foreground" />
                      <span className="text-sm text-foreground">
                        Réservation #{transaction?.reference}
                      </span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-foreground">
                        {new Intl.NumberFormat('fr-FR', {
                          style: 'currency',
                          currency: 'EUR'
                        })?.format(transaction?.amount)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(transaction.date)?.toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      {/* Actions */}
      <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
        <div className="flex items-center space-x-2">
          {!isDefault && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onSetDefault?.(paymentMethod?.id)}
            >
              <Icon name="Star" size={16} className="mr-1" />
              Définir par défaut
            </Button>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit?.(paymentMethod?.id)}
          >
            <Icon name="Edit" size={16} className="mr-1" />
            Modifier
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDelete?.(paymentMethod?.id)}
            className="text-error hover:bg-error/10"
          >
            <Icon name="Trash2" size={16} className="mr-1" />
            Supprimer
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethodCard;