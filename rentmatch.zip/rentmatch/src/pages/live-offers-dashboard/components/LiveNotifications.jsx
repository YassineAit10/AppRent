import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LiveNotifications = ({ 
  notifications = [], 
  onDismiss, 
  onViewOffer,
  soundEnabled = true 
}) => {
  const [visibleNotifications, setVisibleNotifications] = useState([]);

  useEffect(() => {
    // Add new notifications with animation
    notifications?.forEach(notification => {
      if (!visibleNotifications?.find(n => n?.id === notification?.id)) {
        setVisibleNotifications(prev => [...prev, { ...notification, isNew: true }]);
        
        // Play notification sound
        if (soundEnabled && notification?.type === 'new_offer') {
          try {
            const audio = new Audio('/assets/sounds/notification.mp3');
            audio.volume = 0.3;
            audio?.play()?.catch(() => {
              // Ignore audio play errors (user interaction required)
            });
          } catch (error) {
            // Ignore audio errors
          }
        }

        // Remove 'new' status after animation
        setTimeout(() => {
          setVisibleNotifications(prev => 
            prev?.map(n => n?.id === notification?.id ? { ...n, isNew: false } : n)
          );
        }, 500);
      }
    });
  }, [notifications, visibleNotifications, soundEnabled]);

  const handleDismiss = (notificationId) => {
    setVisibleNotifications(prev => prev?.filter(n => n?.id !== notificationId));
    if (onDismiss) onDismiss(notificationId);
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'new_offer': return 'Home';
      case 'offer_update': return 'RefreshCw';
      case 'offer_expiring': return 'Clock';
      case 'offer_expired': return 'XCircle';
      default: return 'Bell';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'new_offer': return 'border-success bg-success/10 text-success';
      case 'offer_update': return 'border-primary bg-primary/10 text-primary';
      case 'offer_expiring': return 'border-warning bg-warning/10 text-warning';
      case 'offer_expired': return 'border-error bg-error/10 text-error';
      default: return 'border-border bg-muted text-muted-foreground';
    }
  };

  if (visibleNotifications?.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-20 right-4 z-notification space-y-2 max-w-sm">
      {visibleNotifications?.map((notification) => (
        <div
          key={notification?.id}
          className={`border rounded-lg shadow-elevation-3 p-4 backdrop-blur-sm transition-all duration-500 ${
            getNotificationColor(notification?.type)
          } ${notification?.isNew ? 'animate-slide-in-right scale-105' : 'animate-fade-in'}`}
        >
          <div className="flex items-start space-x-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              notification?.type === 'new_offer' ? 'bg-success text-success-foreground' :
              notification?.type === 'offer_update' ? 'bg-primary text-primary-foreground' :
              notification?.type === 'offer_expiring' ? 'bg-warning text-warning-foreground' :
              'bg-error text-error-foreground'
            }`}>
              <Icon name={getNotificationIcon(notification?.type)} size={16} />
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">
                {notification?.title}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {notification?.message}
              </p>
              
              {notification?.offerDetails && (
                <div className="mt-2 p-2 bg-surface/50 rounded-md">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium">{notification?.offerDetails?.agency}</span>
                    <span className="font-bold">{notification?.offerDetails?.price}€/jour</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {notification?.offerDetails?.vehicle}
                  </p>
                </div>
              )}

              <div className="flex items-center space-x-2 mt-3">
                {notification?.type === 'new_offer' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onViewOffer && onViewOffer(notification?.offerId)}
                    className="h-6 px-2 text-xs"
                  >
                    Voir l'offre
                    <Icon name="ArrowRight" size={12} className="ml-1" />
                  </Button>
                )}
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDismiss(notification?.id)}
                  className="h-6 px-2 text-xs ml-auto"
                >
                  <Icon name="X" size={12} />
                </Button>
              </div>
            </div>
          </div>

          {/* Progress bar for expiring offers */}
          {notification?.type === 'offer_expiring' && notification?.timeRemaining && (
            <div className="mt-3">
              <div className="w-full bg-muted rounded-full h-1">
                <div 
                  className="bg-warning h-1 rounded-full transition-all duration-1000"
                  style={{ 
                    width: `${(notification?.timeRemaining / notification?.totalTime) * 100}%` 
                  }}
                ></div>
              </div>
              <p className="text-xs text-muted-foreground mt-1 text-center">
                {Math.floor(notification?.timeRemaining / 60)}m restantes
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default LiveNotifications;