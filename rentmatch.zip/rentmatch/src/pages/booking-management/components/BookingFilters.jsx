import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const BookingFilters = ({ 
  filters, 
  onFiltersChange, 
  userRole = 'client',
  bookingCounts = {} 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const statusOptions = [
    { value: 'all', label: 'Tous les statuts' },
    { value: 'confirmed', label: 'Confirmé' },
    { value: 'prepared', label: 'Véhicule préparé' },
    { value: 'active', label: 'En cours' },
    { value: 'completed', label: 'Terminé' },
    { value: 'cancelled', label: 'Annulé' }
  ];

  const timeRangeOptions = [
    { value: 'all', label: 'Toutes les dates' },
    { value: 'upcoming', label: 'À venir' },
    { value: 'current', label: 'En cours' },
    { value: 'past', label: 'Passées' },
    { value: 'this_week', label: 'Cette semaine' },
    { value: 'this_month', label: 'Ce mois' },
    { value: 'last_month', label: 'Mois dernier' }
  ];

  const sortOptions = [
    { value: 'pickup_date_asc', label: 'Date de prise en charge (croissant)' },
    { value: 'pickup_date_desc', label: 'Date de prise en charge (décroissant)' },
    { value: 'created_date_desc', label: 'Plus récentes' },
    { value: 'price_asc', label: 'Prix (croissant)' },
    { value: 'price_desc', label: 'Prix (décroissant)' }
  ];

  const handleFilterChange = (key, value) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const clearFilters = () => {
    onFiltersChange({
      search: '',
      status: 'all',
      timeRange: 'all',
      sortBy: 'pickup_date_asc'
    });
  };

  const hasActiveFilters = filters?.search || filters?.status !== 'all' || filters?.timeRange !== 'all';

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Quick Status Filters */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-foreground flex items-center">
            <Icon name="Filter" size={16} className="mr-2" />
            Filtres
          </h3>
          <div className="flex items-center space-x-2">
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="text-muted-foreground hover:text-foreground"
              >
                <Icon name="X" size={14} />
                Effacer
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
            </Button>
          </div>
        </div>

        {/* Status Quick Filters */}
        <div className="flex flex-wrap gap-2">
          {[
            { key: 'all', label: 'Toutes', count: bookingCounts?.total || 0 },
            { key: 'confirmed', label: 'Confirmées', count: bookingCounts?.confirmed || 0 },
            { key: 'active', label: 'En cours', count: bookingCounts?.active || 0 },
            { key: 'upcoming', label: 'À venir', count: bookingCounts?.upcoming || 0 }
          ]?.map(({ key, label, count }) => (
            <button
              key={key}
              onClick={() => handleFilterChange('status', key)}
              className={`px-3 py-1.5 text-sm rounded-md transition-colors ${
                (key === 'all' ? filters?.status === 'all' : filters?.status === key)
                  ? 'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80'
              }`}
            >
              {label}
              {count > 0 && (
                <span className="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-background/20">
                  {count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>
      {/* Expanded Filters */}
      {isExpanded && (
        <div className="p-4 space-y-4 animate-slide-down">
          {/* Search */}
          <div>
            <Input
              type="search"
              placeholder="Rechercher par véhicule, lieu, référence..."
              value={filters?.search}
              onChange={(e) => handleFilterChange('search', e?.target?.value)}
              className="w-full"
            />
          </div>

          {/* Filter Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select
              label="Statut"
              options={statusOptions}
              value={filters?.status}
              onChange={(value) => handleFilterChange('status', value)}
            />

            <Select
              label="Période"
              options={timeRangeOptions}
              value={filters?.timeRange}
              onChange={(value) => handleFilterChange('timeRange', value)}
            />

            <Select
              label="Trier par"
              options={sortOptions}
              value={filters?.sortBy}
              onChange={(value) => handleFilterChange('sortBy', value)}
            />
          </div>

          {/* Date Range Picker */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              type="date"
              label="Date de début"
              value={filters?.startDate || ''}
              onChange={(e) => handleFilterChange('startDate', e?.target?.value)}
            />
            <Input
              type="date"
              label="Date de fin"
              value={filters?.endDate || ''}
              onChange={(e) => handleFilterChange('endDate', e?.target?.value)}
            />
          </div>

          {/* Agency-specific filters */}
          {userRole === 'agency' && (
            <div className="pt-4 border-t border-border">
              <h4 className="font-medium text-foreground mb-3">Filtres agence</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Type de paiement"
                  options={[
                    { value: 'all', label: 'Tous les paiements' },
                    { value: 'escrow', label: 'Paiement sécurisé' },
                    { value: 'on_location', label: 'Paiement sur place' }
                  ]}
                  value={filters?.paymentType || 'all'}
                  onChange={(value) => handleFilterChange('paymentType', value)}
                />

                <Select
                  label="Urgence SLA"
                  options={[
                    { value: 'all', label: 'Toutes les réservations' },
                    { value: 'urgent', label: 'Confirmation urgente (< 2h)' },
                    { value: 'normal', label: 'Délai normal' }
                  ]}
                  value={filters?.urgency || 'all'}
                  onChange={(value) => handleFilterChange('urgency', value)}
                />
              </div>
            </div>
          )}

          {/* Applied Filters Summary */}
          {hasActiveFilters && (
            <div className="pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Filtres actifs: {[
                    filters?.search && 'Recherche',
                    filters?.status !== 'all' && 'Statut',
                    filters?.timeRange !== 'all' && 'Période',
                    filters?.startDate && 'Date personnalisée'
                  ]?.filter(Boolean)?.join(', ')}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearFilters}
                >
                  <Icon name="RotateCcw" size={14} />
                  Réinitialiser
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BookingFilters;