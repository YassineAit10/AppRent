import React, { useState } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const StatusIndicatorBar = ({ 
  bookingStatus = null,
  paymentStatus = null,
  verificationStatus = null,
  onStatusClick,
  onActionClick,
  className = ""
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Don't render if no active status
  if (!bookingStatus && !paymentStatus && !verificationStatus) {
    return null;
  }

  const getStatusConfig = (type, status) => {
    const configs = {
      booking: {
        pending: {
          color: 'warning',
          icon: 'Clock',
          bgClass: 'bg-warning/10 border-warning/20',
          textClass: 'text-warning',
          label: 'Réservation en attente',
          description: 'Confirmation de l\'agence requise'
        },
        confirmed: {
          color: 'success',
          icon: 'CheckCircle',
          bgClass: 'bg-success/10 border-success/20',
          textClass: 'text-success',
          label: 'Réservation confirmée',
          description: 'Votre réservation a été acceptée'
        },
        active: {
          color: 'primary',
          icon: 'Calendar',
          bgClass: 'bg-primary/10 border-primary/20',
          textClass: 'text-primary',
          label: 'Réservation active',
          description: 'Séjour en cours'
        },
        cancelled: {
          color: 'error',
          icon: 'XCircle',
          bgClass: 'bg-error/10 border-error/20',
          textClass: 'text-error',
          label: 'Réservation annulée',
          description: 'Remboursement en cours'
        }
      },
      payment: {
        pending: {
          color: 'warning',
          icon: 'Clock',
          bgClass: 'bg-warning/10 border-warning/20',
          textClass: 'text-warning',
          label: 'Paiement en attente',
          description: 'Traitement en cours'
        },
        secured: {
          color: 'success',
          icon: 'Shield',
          bgClass: 'bg-success/10 border-success/20',
          textClass: 'text-success',
          label: 'Paiement sécurisé',
          description: 'Fonds bloqués en séquestre'
        },
        released: {
          color: 'primary',
          icon: 'CheckCircle',
          bgClass: 'bg-primary/10 border-primary/20',
          textClass: 'text-primary',
          label: 'Paiement libéré',
          description: 'Transaction terminée'
        },
        refunded: {
          color: 'secondary',
          icon: 'RotateCcw',
          bgClass: 'bg-secondary/10 border-secondary/20',
          textClass: 'text-secondary',
          label: 'Paiement remboursé',
          description: 'Fonds retournés'
        }
      },
      verification: {
        pending: {
          color: 'warning',
          icon: 'Clock',
          bgClass: 'bg-warning/10 border-warning/20',
          textClass: 'text-warning',
          label: 'Vérification en cours',
          description: 'Documents en cours d\'examen'
        },
        verified: {
          color: 'success',
          icon: 'ShieldCheck',
          bgClass: 'bg-success/10 border-success/20',
          textClass: 'text-success',
          label: 'Compte vérifié',
          description: 'Vérification complète'
        },
        rejected: {
          color: 'error',
          icon: 'ShieldX',
          bgClass: 'bg-error/10 border-error/20',
          textClass: 'text-error',
          label: 'Vérification échouée',
          description: 'Documents à revoir'
        }
      }
    };

    return configs?.[type]?.[status] || null;
  };

  // Get primary status to display
  const primaryStatus = bookingStatus || paymentStatus || verificationStatus;
  const primaryType = bookingStatus ? 'booking' : paymentStatus ? 'payment' : 'verification';
  const primaryConfig = getStatusConfig(primaryType, primaryStatus);

  if (!primaryConfig) return null;

  const allStatuses = [
    bookingStatus && { type: 'booking', status: bookingStatus, config: getStatusConfig('booking', bookingStatus) },
    paymentStatus && { type: 'payment', status: paymentStatus, config: getStatusConfig('payment', paymentStatus) },
    verificationStatus && { type: 'verification', status: verificationStatus, config: getStatusConfig('verification', verificationStatus) }
  ]?.filter(Boolean);

  const getActionButton = () => {
    if (bookingStatus === 'pending') {
      return { label: 'Voir détails', action: 'view-booking' };
    }
    if (paymentStatus === 'pending') {
      return { label: 'Finaliser paiement', action: 'complete-payment' };
    }
    if (verificationStatus === 'pending') {
      return { label: 'Compléter vérification', action: 'complete-verification' };
    }
    if (verificationStatus === 'rejected') {
      return { label: 'Soumettre documents', action: 'resubmit-documents' };
    }
    return { label: 'Voir détails', action: 'view-details' };
  };

  const actionButton = getActionButton();

  return (
    <div className={`border-b ${primaryConfig?.bgClass} ${className}`}>
      <div className="px-4 lg:px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {/* Status Indicator */}
            <div className={`w-3 h-3 rounded-full ${primaryConfig?.textClass?.replace('text-', 'bg-')} animate-pulse-gentle`}></div>
            
            {/* Status Info */}
            <div className="flex items-center space-x-2">
              <Icon name={primaryConfig?.icon} size={16} className={primaryConfig?.textClass} />
              <span className={`font-medium text-sm ${primaryConfig?.textClass}`}>
                {primaryConfig?.label}
              </span>
              <span className="text-sm text-muted-foreground hidden sm:inline">
                • {primaryConfig?.description}
              </span>
            </div>

            {/* Multiple Status Indicator */}
            {allStatuses?.length > 1 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                className="h-6 px-2 text-xs"
              >
                +{allStatuses?.length - 1} statut{allStatuses?.length > 2 ? 's' : ''}
                <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={12} className="ml-1" />
              </Button>
            )}
          </div>

          {/* Action Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onActionClick?.(actionButton?.action)}
            className={`${primaryConfig?.textClass} hover:${primaryConfig?.bgClass}`}
          >
            {actionButton?.label}
            <Icon name="ArrowRight" size={14} className="ml-1" />
          </Button>
        </div>

        {/* Expanded Status Details */}
        {isExpanded && allStatuses?.length > 1 && (
          <div className="mt-3 pt-3 border-t border-border/50 animate-slide-down">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {allStatuses?.map(({ type, status, config }) => (
                <div
                  key={type}
                  onClick={() => onStatusClick?.(type, status)}
                  className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                >
                  <Icon name={config?.icon} size={14} className={config?.textClass} />
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs font-medium ${config?.textClass}`}>
                      {config?.label}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {config?.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Progress Timeline (for booking status) */}
        {bookingStatus && !isExpanded && (
          <div className="mt-3 pt-3 border-t border-border/50">
            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${
                  ['confirmed', 'active']?.includes(bookingStatus) ? 'bg-success' : 'bg-muted'
                }`}></div>
                <span>Demande</span>
              </div>
              <div className="w-4 h-px bg-border"></div>
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${
                  bookingStatus === 'active' ? 'bg-success' : 
                  bookingStatus === 'confirmed' ? 'bg-warning animate-pulse-gentle' : 'bg-muted'
                }`}></div>
                <span>Confirmation</span>
              </div>
              <div className="w-4 h-px bg-border"></div>
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${
                  bookingStatus === 'active' ? 'bg-primary animate-pulse-gentle' : 'bg-muted'
                }`}></div>
                <span>Séjour</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StatusIndicatorBar;