import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const OfferFilters = ({ 
  filters, 
  onFiltersChange, 
  onResetFilters,
  isOpen = false,
  onToggle 
}) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const vehicleTypeOptions = [
    { value: 'all', label: 'Tous les véhicules' },
    { value: 'compact', label: 'Citadine' },
    { value: 'sedan', label: 'Berline' },
    { value: 'suv', label: 'SUV' },
    { value: 'van', label: 'Utilitaire' },
    { value: 'luxury', label: 'Luxe' }
  ];

  const sortOptions = [
    { value: 'price_asc', label: 'Prix croissant' },
    { value: 'price_desc', label: 'Prix décroissant' },
    { value: 'rating', label: 'Note agence' },
    { value: 'distance', label: 'Distance' },
    { value: 'time_remaining', label: 'Temps restant' },
    { value: 'newest', label: 'Plus récent' }
  ];

  const agencyRatingOptions = [
    { value: 'all', label: 'Toutes les notes' },
    { value: '4.5', label: '4.5+ étoiles' },
    { value: '4.0', label: '4.0+ étoiles' },
    { value: '3.5', label: '3.5+ étoiles' }
  ];

  const handleFilterChange = (key, value) => {
    const updatedFilters = { ...localFilters, [key]: value };
    setLocalFilters(updatedFilters);
    onFiltersChange(updatedFilters);
  };

  const handleReset = () => {
    const resetFilters = {
      priceMin: '',
      priceMax: '',
      vehicleType: 'all',
      agencyRating: 'all',
      maxDistance: '',
      sortBy: 'newest',
      showExpired: false,
      verifiedOnly: false,
      instantBooking: false
    };
    setLocalFilters(resetFilters);
    onFiltersChange(resetFilters);
    onResetFilters();
  };

  const activeFiltersCount = Object.values(localFilters)?.filter(value => 
    value !== '' && value !== 'all' && value !== false && value !== 'newest'
  )?.length;

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Filter Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-foreground" />
          <h3 className="font-semibold text-foreground">Filtres</h3>
          {activeFiltersCount > 0 && (
            <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full font-medium">
              {activeFiltersCount}
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {activeFiltersCount > 0 && (
            <Button variant="ghost" size="sm" onClick={handleReset}>
              <Icon name="X" size={14} />
              <span className="ml-1">Reset</span>
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="lg:hidden"
          >
            <Icon name={isOpen ? "ChevronUp" : "ChevronDown"} size={16} />
          </Button>
        </div>
      </div>
      {/* Filter Content */}
      <div className={`${isOpen ? 'block' : 'hidden'} lg:block`}>
        <div className="p-4 space-y-4">
          {/* Sort By */}
          <div>
            <Select
              label="Trier par"
              options={sortOptions}
              value={localFilters?.sortBy}
              onChange={(value) => handleFilterChange('sortBy', value)}
            />
          </div>

          {/* Price Range */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Prix par jour
            </label>
            <div className="grid grid-cols-2 gap-2">
              <Input
                type="number"
                placeholder="Min"
                value={localFilters?.priceMin}
                onChange={(e) => handleFilterChange('priceMin', e?.target?.value)}
              />
              <Input
                type="number"
                placeholder="Max"
                value={localFilters?.priceMax}
                onChange={(e) => handleFilterChange('priceMax', e?.target?.value)}
              />
            </div>
          </div>

          {/* Vehicle Type */}
          <div>
            <Select
              label="Type de véhicule"
              options={vehicleTypeOptions}
              value={localFilters?.vehicleType}
              onChange={(value) => handleFilterChange('vehicleType', value)}
            />
          </div>

          {/* Agency Rating */}
          <div>
            <Select
              label="Note agence"
              options={agencyRatingOptions}
              value={localFilters?.agencyRating}
              onChange={(value) => handleFilterChange('agencyRating', value)}
            />
          </div>

          {/* Max Distance */}
          <div>
            <Input
              label="Distance max (km)"
              type="number"
              placeholder="Ex: 50"
              value={localFilters?.maxDistance}
              onChange={(e) => handleFilterChange('maxDistance', e?.target?.value)}
            />
          </div>

          {/* Checkboxes */}
          <div className="space-y-3 pt-2 border-t border-border">
            <Checkbox
              label="Agences vérifiées uniquement"
              checked={localFilters?.verifiedOnly}
              onChange={(e) => handleFilterChange('verifiedOnly', e?.target?.checked)}
            />
            
            <Checkbox
              label="Réservation instantanée"
              checked={localFilters?.instantBooking}
              onChange={(e) => handleFilterChange('instantBooking', e?.target?.checked)}
            />
            
            <Checkbox
              label="Inclure les offres expirées"
              checked={localFilters?.showExpired}
              onChange={(e) => handleFilterChange('showExpired', e?.target?.checked)}
            />
          </div>

          {/* Quick Filters */}
          <div className="pt-2 border-t border-border">
            <label className="text-sm font-medium text-foreground mb-2 block">
              Filtres rapides
            </label>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  handleFilterChange('priceMax', '50');
                  handleFilterChange('sortBy', 'price_asc');
                }}
              >
                <Icon name="DollarSign" size={14} />
                <span className="ml-1">Économique</span>
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  handleFilterChange('agencyRating', '4.5');
                  handleFilterChange('verifiedOnly', true);
                }}
              >
                <Icon name="Star" size={14} />
                <span className="ml-1">Premium</span>
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  handleFilterChange('maxDistance', '10');
                  handleFilterChange('sortBy', 'distance');
                }}
              >
                <Icon name="MapPin" size={14} />
                <span className="ml-1">Proche</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfferFilters;