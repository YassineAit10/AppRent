import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const CreateOfferModal = ({ isOpen, onClose, demand, availableVehicles, onSubmitOffer }) => {
  const [formData, setFormData] = useState({
    vehicleId: '',
    pricePerDay: '',
    totalPrice: '',
    currency: 'EUR',
    features: [],
    terms: '',
    validUntil: '',
    responseTime: '2h',
    paymentMethod: 'escrow',
    specialConditions: '',
    pickupLocation: '',
    dropoffLocation: '',
    fuelPolicy: 'full-full',
    mileageLimit: 'unlimited',
    insuranceLevel: 'basic',
    additionalDrivers: false,
    cancellationPolicy: 'standard'
  });

  const [profitMargin, setProfitMargin] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Calculate duration and total price
  useEffect(() => {
    if (demand && formData?.pricePerDay) {
      const startDate = new Date(demand.startDate);
      const endDate = new Date(demand.endDate);
      const duration = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
      const total = parseFloat(formData?.pricePerDay) * duration;
      
      setFormData(prev => ({
        ...prev,
        totalPrice: total?.toFixed(2)
      }));

      // Calculate profit margin based on demand budget
      if (demand?.budgetPerDay) {
        const margin = ((parseFloat(formData?.pricePerDay) - demand?.budgetPerDay) / demand?.budgetPerDay) * 100;
        setProfitMargin(margin);
      }
    }
  }, [formData?.pricePerDay, demand]);

  // Set default values when modal opens
  useEffect(() => {
    if (isOpen && demand) {
      const defaultValidUntil = new Date();
      defaultValidUntil?.setHours(defaultValidUntil?.getHours() + 24);
      
      setFormData(prev => ({
        ...prev,
        pricePerDay: demand?.budgetPerDay?.toString() || '',
        pickupLocation: demand?.location || '',
        dropoffLocation: demand?.location || '',
        validUntil: defaultValidUntil?.toISOString()?.slice(0, 16)
      }));
    }
  }, [isOpen, demand]);

  const vehicleOptions = availableVehicles?.map(vehicle => ({
    value: vehicle?.id,
    label: `${vehicle?.brand} ${vehicle?.model} (${vehicle?.category})`,
    description: `${vehicle?.year} • ${vehicle?.fuelType} • ${vehicle?.transmission}`
  })) || [];

  const featureOptions = [
    { value: 'gps', label: 'GPS inclus' },
    { value: 'bluetooth', label: 'Bluetooth' },
    { value: 'ac', label: 'Climatisation' },
    { value: 'cruise', label: 'Régulateur de vitesse' },
    { value: 'parking', label: 'Capteurs de stationnement' },
    { value: 'camera', label: 'Caméra de recul' },
    { value: 'sunroof', label: 'Toit ouvrant' },
    { value: 'leather', label: 'Sièges cuir' },
    { value: 'heated', label: 'Sièges chauffants' },
    { value: 'premium', label: 'Audio premium' }
  ];

  const insuranceLevelOptions = [
    { value: 'basic', label: 'Assurance de base' },
    { value: 'comprehensive', label: 'Tous risques' },
    { value: 'premium', label: 'Premium sans franchise' }
  ];

  const fuelPolicyOptions = [
    { value: 'full-full', label: 'Plein/Plein' },
    { value: 'full-empty', label: 'Plein/Vide' },
    { value: 'same-same', label: 'Même niveau' }
  ];

  const mileageLimitOptions = [
    { value: 'unlimited', label: 'Kilométrage illimité' },
    { value: '200', label: '200 km/jour' },
    { value: '300', label: '300 km/jour' },
    { value: '500', label: '500 km/jour' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleFeatureToggle = (feature, checked) => {
    setFormData(prev => ({
      ...prev,
      features: checked 
        ? [...prev?.features, feature]
        : prev?.features?.filter(f => f !== feature)
    }));
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    setIsSubmitting(true);

    try {
      const offerData = {
        ...formData,
        demandId: demand?.id,
        agencyId: 'current-agency-id', // Would come from auth context
        createdAt: new Date()?.toISOString(),
        status: 'pending'
      };

      await onSubmitOffer?.(offerData);
      onClose();
    } catch (error) {
      console.error('Error submitting offer:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getDurationInDays = () => {
    if (!demand) return 0;
    const start = new Date(demand.startDate);
    const end = new Date(demand.endDate);
    return Math.ceil((end - start) / (1000 * 60 * 60 * 24));
  };

  const getProfitMarginColor = () => {
    if (profitMargin > 20) return 'text-success';
    if (profitMargin > 0) return 'text-warning';
    return 'text-error';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal p-4">
      <div className="bg-popover border border-border rounded-lg shadow-elevation-4 w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <Icon name="Plus" size={24} className="text-primary" />
            <div>
              <h2 className="text-xl font-semibold text-foreground">Créer une offre</h2>
              <p className="text-sm text-muted-foreground">
                Répondre à la demande de {demand?.client?.name}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Demand Summary */}
            <div className="bg-muted/30 rounded-lg p-4">
              <h3 className="font-medium text-foreground mb-2">Résumé de la demande</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Période:</span>
                  <p className="font-medium text-foreground">
                    {getDurationInDays()} jour(s)
                  </p>
                </div>
                <div>
                  <span className="text-muted-foreground">Budget:</span>
                  <p className="font-medium text-foreground">
                    {demand?.budgetPerDay}€/jour
                  </p>
                </div>
                <div>
                  <span className="text-muted-foreground">Lieu:</span>
                  <p className="font-medium text-foreground">{demand?.location}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Véhicule:</span>
                  <p className="font-medium text-foreground">
                    {demand?.vehiclePreferences?.join(', ')}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-4">
                <h3 className="font-medium text-foreground">Détails du véhicule</h3>
                
                <Select
                  label="Véhicule disponible"
                  options={vehicleOptions}
                  value={formData?.vehicleId}
                  onChange={(value) => handleInputChange('vehicleId', value)}
                  required
                  searchable
                />

                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Prix par jour (€)"
                    type="number"
                    value={formData?.pricePerDay}
                    onChange={(e) => handleInputChange('pricePerDay', e?.target?.value)}
                    required
                    min="0"
                    step="0.01"
                  />
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Prix total
                    </label>
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-semibold text-foreground">
                        {formData?.totalPrice}€
                      </span>
                      {profitMargin !== 0 && (
                        <span className={`text-sm font-medium ${getProfitMarginColor()}`}>
                          ({profitMargin > 0 ? '+' : ''}{profitMargin?.toFixed(1)}%)
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Lieu de prise en charge"
                    type="text"
                    value={formData?.pickupLocation}
                    onChange={(e) => handleInputChange('pickupLocation', e?.target?.value)}
                    required
                  />
                  <Input
                    label="Lieu de restitution"
                    type="text"
                    value={formData?.dropoffLocation}
                    onChange={(e) => handleInputChange('dropoffLocation', e?.target?.value)}
                    required
                  />
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-4">
                <h3 className="font-medium text-foreground">Conditions et services</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <Select
                    label="Niveau d'assurance"
                    options={insuranceLevelOptions}
                    value={formData?.insuranceLevel}
                    onChange={(value) => handleInputChange('insuranceLevel', value)}
                  />
                  <Select
                    label="Politique carburant"
                    options={fuelPolicyOptions}
                    value={formData?.fuelPolicy}
                    onChange={(value) => handleInputChange('fuelPolicy', value)}
                  />
                </div>

                <Select
                  label="Limite kilométrage"
                  options={mileageLimitOptions}
                  value={formData?.mileageLimit}
                  onChange={(value) => handleInputChange('mileageLimit', value)}
                />

                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Valide jusqu'au"
                    type="datetime-local"
                    value={formData?.validUntil}
                    onChange={(e) => handleInputChange('validUntil', e?.target?.value)}
                    required
                  />
                  <Select
                    label="Temps de réponse"
                    options={[
                      { value: '30min', label: '30 minutes' },
                      { value: '1h', label: '1 heure' },
                      { value: '2h', label: '2 heures' },
                      { value: '4h', label: '4 heures' }
                    ]}
                    value={formData?.responseTime}
                    onChange={(value) => handleInputChange('responseTime', value)}
                  />
                </div>

                <Checkbox
                  label="Conducteurs additionnels autorisés"
                  checked={formData?.additionalDrivers}
                  onChange={(e) => handleInputChange('additionalDrivers', e?.target?.checked)}
                />
              </div>
            </div>

            {/* Features */}
            <div>
              <h3 className="font-medium text-foreground mb-3">Équipements inclus</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
                {featureOptions?.map((feature) => (
                  <Checkbox
                    key={feature?.value}
                    label={feature?.label}
                    checked={formData?.features?.includes(feature?.value)}
                    onChange={(e) => handleFeatureToggle(feature?.value, e?.target?.checked)}
                  />
                ))}
              </div>
            </div>

            {/* Terms and Conditions */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Conditions particulières
              </label>
              <textarea
                value={formData?.specialConditions}
                onChange={(e) => handleInputChange('specialConditions', e?.target?.value)}
                placeholder="Ajoutez des conditions spécifiques à cette offre..."
                className="w-full h-24 px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 resize-none"
              />
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-border bg-muted/30">
          <div className="text-sm text-muted-foreground">
            Cette offre sera visible par le client pendant {formData?.responseTime}
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              onClick={handleSubmit}
              loading={isSubmitting}
              disabled={!formData?.vehicleId || !formData?.pricePerDay}
            >
              <Icon name="Send" size={16} />
              Envoyer l'offre
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateOfferModal;