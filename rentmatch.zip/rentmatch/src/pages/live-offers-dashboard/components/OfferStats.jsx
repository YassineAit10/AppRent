import React from 'react';
import Icon from '../../../components/AppIcon';

const OfferStats = ({ 
  totalOffers = 0,
  newOffers = 0,
  expiringOffers = 0,
  averagePrice = 0,
  bestPrice = 0,
  responseRate = 0 
}) => {
  const stats = [
    {
      label: 'Offres reçues',
      value: totalOffers,
      icon: 'Home',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      label: 'Nouvelles',
      value: newOffers,
      icon: 'Plus',
      color: 'text-success',
      bgColor: 'bg-success/10',
      pulse: newOffers > 0
    },
    {
      label: 'Expirent bientôt',
      value: expiringOffers,
      icon: 'Clock',
      color: 'text-warning',
      bgColor: 'bg-warning/10',
      pulse: expiringOffers > 0
    },
    {
      label: 'Prix moyen',
      value: `${averagePrice}€`,
      icon: 'TrendingUp',
      color: 'text-secondary',
      bgColor: 'bg-secondary/10'
    },
    {
      label: 'Meilleur prix',
      value: `${bestPrice}€`,
      icon: 'Star',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      label: 'Taux de réponse',
      value: `${responseRate}%`,
      icon: 'BarChart3',
      color: 'text-muted-foreground',
      bgColor: 'bg-muted'
    }
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
      {stats?.map((stat, index) => (
        <div
          key={index}
          className={`bg-card border border-border rounded-lg p-4 hover:shadow-elevation-2 transition-all duration-200 ${
            stat?.pulse ? 'animate-pulse-gentle' : ''
          }`}
        >
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${stat?.bgColor}`}>
              <Icon name={stat?.icon} size={18} className={stat?.color} />
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="text-lg font-bold text-foreground truncate">
                {stat?.value}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {stat?.label}
              </p>
            </div>
          </div>

          {/* Trend indicator for price stats */}
          {(stat?.label?.includes('Prix') || stat?.label?.includes('Taux')) && (
            <div className="mt-2 flex items-center space-x-1">
              <Icon 
                name={stat?.label?.includes('moyen') ? 'TrendingUp' : 'TrendingDown'} 
                size={12} 
                className={stat?.label?.includes('moyen') ? 'text-error' : 'text-success'} 
              />
              <span className={`text-xs ${
                stat?.label?.includes('moyen') ? 'text-error' : 'text-success'
              }`}>
                {stat?.label?.includes('moyen') ? '+5%' : '-12%'}
              </span>
              <span className="text-xs text-muted-foreground">vs hier</span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default OfferStats;