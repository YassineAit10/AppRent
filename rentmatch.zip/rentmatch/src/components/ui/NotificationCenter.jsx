import React, { useState, useRef, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const NotificationCenter = ({ 
  notifications = [], 
  unreadCount = 0, 
  onMarkAsRead, 
  onMarkAllAsRead,
  onNotificationClick 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [filter, setFilter] = useState('all');
  const dropdownRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'offer': return 'Home';
      case 'booking': return 'Calendar';
      case 'payment': return 'CreditCard';
      case 'message': return 'MessageCircle';
      case 'verification': return 'Shield';
      case 'reminder': return 'Clock';
      default: return 'Bell';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'offer': return 'text-primary bg-primary/10';
      case 'booking': return 'text-success bg-success/10';
      case 'payment': return 'text-warning bg-warning/10';
      case 'message': return 'text-accent bg-accent/10';
      case 'verification': return 'text-secondary bg-secondary/10';
      case 'reminder': return 'text-muted-foreground bg-muted';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const filteredNotifications = notifications?.filter(notification => {
    if (filter === 'unread') return notification?.unread;
    if (filter === 'offers') return notification?.type === 'offer';
    if (filter === 'bookings') return notification?.type === 'booking';
    if (filter === 'payments') return notification?.type === 'payment';
    return true;
  });

  const handleNotificationClick = (notification) => {
    if (notification?.unread && onMarkAsRead) {
      onMarkAsRead(notification?.id);
    }
    if (onNotificationClick) {
      onNotificationClick(notification);
    }
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const notificationTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now - notificationTime) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'À l\'instant';
    if (diffInMinutes < 60) return `${diffInMinutes} min`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h`;
    return `${Math.floor(diffInMinutes / 1440)}j`;
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="relative focus-ring"
      >
        <Icon name="Bell" size={20} />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-error text-error-foreground text-xs rounded-full flex items-center justify-center animate-pulse-gentle font-medium">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </Button>
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-96 bg-popover border border-border rounded-lg shadow-elevation-3 animate-slide-down z-dropdown">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center space-x-2">
              <Icon name="Bell" size={20} className="text-foreground" />
              <h3 className="font-semibold text-foreground">Notifications</h3>
              {unreadCount > 0 && (
                <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full font-medium">
                  {unreadCount}
                </span>
              )}
            </div>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onMarkAllAsRead}
                className="text-xs"
              >
                Tout marquer lu
              </Button>
            )}
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-1 p-3 border-b border-border bg-muted/30">
            {[
              { key: 'all', label: 'Toutes', count: notifications?.length },
              { key: 'unread', label: 'Non lues', count: unreadCount },
              { key: 'offers', label: 'Offres', count: notifications?.filter(n => n?.type === 'offer')?.length },
              { key: 'bookings', label: 'Réservations', count: notifications?.filter(n => n?.type === 'booking')?.length }
            ]?.map(({ key, label, count }) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
                  filter === key
                    ? 'bg-primary text-primary-foreground font-medium'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                {label} {count > 0 && `(${count})`}
              </button>
            ))}
          </div>

          {/* Notifications List */}
          <div className="max-h-96 overflow-y-auto">
            {filteredNotifications?.length === 0 ? (
              <div className="p-8 text-center">
                <Icon name="Bell" size={32} className="text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  {filter === 'unread' ? 'Aucune notification non lue' : 'Aucune notification'}
                </p>
              </div>
            ) : (
              filteredNotifications?.map((notification) => (
                <div
                  key={notification?.id}
                  onClick={() => handleNotificationClick(notification)}
                  className={`p-4 border-b border-border hover:bg-muted/50 cursor-pointer transition-colors ${
                    notification?.unread ? 'bg-accent/5 border-l-4 border-l-primary' : ''
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      getNotificationColor(notification?.type)
                    }`}>
                      <Icon name={getNotificationIcon(notification?.type)} size={16} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <p className={`text-sm font-medium ${
                          notification?.unread ? 'text-foreground' : 'text-muted-foreground'
                        }`}>
                          {notification?.title}
                        </p>
                        <div className="flex items-center space-x-2 flex-shrink-0 ml-2">
                          <span className="text-xs text-muted-foreground">
                            {formatTime(notification?.timestamp)}
                          </span>
                          {notification?.unread && (
                            <div className="w-2 h-2 bg-primary rounded-full"></div>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {notification?.message}
                      </p>
                      
                      {notification?.actionLabel && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="mt-2 h-7 px-2 text-xs"
                          onClick={(e) => {
                            e?.stopPropagation();
                            if (notification?.onAction) notification?.onAction();
                          }}
                        >
                          {notification?.actionLabel}
                          <Icon name="ArrowRight" size={12} className="ml-1" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          {filteredNotifications?.length > 0 && (
            <div className="p-3 border-t border-border bg-muted/30">
              <Button variant="ghost" size="sm" fullWidth className="text-sm">
                Voir toutes les notifications
                <Icon name="ExternalLink" size={14} className="ml-2" />
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;