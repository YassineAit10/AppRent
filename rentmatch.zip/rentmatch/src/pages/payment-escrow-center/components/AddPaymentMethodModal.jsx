import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const AddPaymentMethodModal = ({ isOpen, onClose, onAdd }) => {
  const [selectedType, setSelectedType] = useState('card');
  const [formData, setFormData] = useState({
    // Card fields
    cardNumber: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    holderName: '',
    // Bank fields
    iban: '',
    bankName: '',
    accountHolderName: '',
    // Common fields
    nickname: '',
    setAsDefault: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const paymentTypes = [
    { value: 'card', label: 'Carte bancaire', icon: 'CreditCard' },
    { value: 'bank', label: 'Compte bancaire', icon: 'Building2' },
    { value: 'paypal', label: 'PayPal', icon: 'Wallet' }
  ];

  const months = Array.from({ length: 12 }, (_, i) => ({
    value: (i + 1)?.toString()?.padStart(2, '0'),
    label: (i + 1)?.toString()?.padStart(2, '0')
  }));

  const currentYear = new Date()?.getFullYear();
  const years = Array.from({ length: 20 }, (_, i) => ({
    value: (currentYear + i)?.toString(),
    label: (currentYear + i)?.toString()
  }));

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (selectedType === 'card') {
      if (!formData?.cardNumber || formData?.cardNumber?.length < 16) {
        newErrors.cardNumber = 'Numéro de carte invalide';
      }
      if (!formData?.expiryMonth) {
        newErrors.expiryMonth = 'Mois d\'expiration requis';
      }
      if (!formData?.expiryYear) {
        newErrors.expiryYear = 'Année d\'expiration requise';
      }
      if (!formData?.cvv || formData?.cvv?.length < 3) {
        newErrors.cvv = 'CVV invalide';
      }
      if (!formData?.holderName?.trim()) {
        newErrors.holderName = 'Nom du titulaire requis';
      }
    } else if (selectedType === 'bank') {
      if (!formData?.iban || formData?.iban?.length < 15) {
        newErrors.iban = 'IBAN invalide';
      }
      if (!formData?.bankName?.trim()) {
        newErrors.bankName = 'Nom de la banque requis';
      }
      if (!formData?.accountHolderName?.trim()) {
        newErrors.accountHolderName = 'Nom du titulaire requis';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const paymentMethod = {
        id: Date.now()?.toString(),
        type: selectedType,
        nickname: formData?.nickname || `${paymentTypes?.find(t => t?.value === selectedType)?.label} ${Date.now()}`,
        isDefault: formData?.setAsDefault,
        verified: false,
        addedAt: new Date()?.toISOString(),
        ...formData
      };

      onAdd?.(paymentMethod);
      onClose();
      
      // Reset form
      setFormData({
        cardNumber: '',
        expiryMonth: '',
        expiryYear: '',
        cvv: '',
        holderName: '',
        iban: '',
        bankName: '',
        accountHolderName: '',
        nickname: '',
        setAsDefault: false
      });
      setSelectedType('card');
      setErrors({});
    } catch (error) {
      console.error('Error adding payment method:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCardNumber = (value) => {
    const v = value?.replace(/\s+/g, '')?.replace(/[^0-9]/gi, '');
    const matches = v?.match(/\d{4,16}/g);
    const match = matches && matches?.[0] || '';
    const parts = [];
    for (let i = 0, len = match?.length; i < len; i += 4) {
      parts?.push(match?.substring(i, i + 4));
    }
    if (parts?.length) {
      return parts?.join(' ');
    } else {
      return v;
    }
  };

  const formatIBAN = (value) => {
    return value?.replace(/\s+/g, '')?.replace(/(.{4})/g, '$1 ')?.trim()?.toUpperCase();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal p-4">
      <div className="bg-popover border border-border rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-bold text-foreground">
              Ajouter une méthode de paiement
            </h2>
            <p className="text-sm text-muted-foreground">
              Sécurisée avec chiffrement PCI DSS
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="w-8 h-8"
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Payment Type Selection */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Type de méthode de paiement
            </label>
            <div className="grid grid-cols-1 gap-2">
              {paymentTypes?.map((type) => (
                <button
                  key={type?.value}
                  type="button"
                  onClick={() => setSelectedType(type?.value)}
                  className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
                    selectedType === type?.value
                      ? 'border-primary bg-primary/10 text-primary' :'border-border hover:bg-muted'
                  }`}
                >
                  <Icon name={type?.icon} size={20} />
                  <span className="font-medium">{type?.label}</span>
                  {selectedType === type?.value && (
                    <Icon name="Check" size={16} className="ml-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Card Fields */}
          {selectedType === 'card' && (
            <>
              <Input
                label="Numéro de carte"
                type="text"
                placeholder="1234 5678 9012 3456"
                value={formData?.cardNumber}
                onChange={(e) => handleInputChange('cardNumber', formatCardNumber(e?.target?.value))}
                error={errors?.cardNumber}
                maxLength={19}
                required
              />

              <div className="grid grid-cols-2 gap-3">
                <Select
                  label="Mois d'expiration"
                  options={months}
                  value={formData?.expiryMonth}
                  onChange={(value) => handleInputChange('expiryMonth', value)}
                  error={errors?.expiryMonth}
                  placeholder="MM"
                  required
                />
                <Select
                  label="Année d'expiration"
                  options={years}
                  value={formData?.expiryYear}
                  onChange={(value) => handleInputChange('expiryYear', value)}
                  error={errors?.expiryYear}
                  placeholder="YYYY"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="CVV"
                  type="text"
                  placeholder="123"
                  value={formData?.cvv}
                  onChange={(e) => handleInputChange('cvv', e?.target?.value?.replace(/\D/g, ''))}
                  error={errors?.cvv}
                  maxLength={4}
                  required
                />
                <div></div>
              </div>

              <Input
                label="Nom du titulaire"
                type="text"
                placeholder="Jean Dupont"
                value={formData?.holderName}
                onChange={(e) => handleInputChange('holderName', e?.target?.value)}
                error={errors?.holderName}
                required
              />
            </>
          )}

          {/* Bank Fields */}
          {selectedType === 'bank' && (
            <>
              <Input
                label="IBAN"
                type="text"
                placeholder="FR14 2004 1010 0505 0001 3M02 606"
                value={formData?.iban}
                onChange={(e) => handleInputChange('iban', formatIBAN(e?.target?.value))}
                error={errors?.iban}
                maxLength={34}
                required
              />

              <Input
                label="Nom de la banque"
                type="text"
                placeholder="Banque Populaire"
                value={formData?.bankName}
                onChange={(e) => handleInputChange('bankName', e?.target?.value)}
                error={errors?.bankName}
                required
              />

              <Input
                label="Nom du titulaire du compte"
                type="text"
                placeholder="Jean Dupont"
                value={formData?.accountHolderName}
                onChange={(e) => handleInputChange('accountHolderName', e?.target?.value)}
                error={errors?.accountHolderName}
                required
              />
            </>
          )}

          {/* PayPal Fields */}
          {selectedType === 'paypal' && (
            <div className="text-center py-8">
              <Icon name="Wallet" size={48} className="text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">
                Connexion PayPal
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                Vous serez redirigé vers PayPal pour autoriser la connexion
              </p>
              <Button type="button" variant="outline" className="w-full">
                <Icon name="ExternalLink" size={16} className="mr-2" />
                Se connecter à PayPal
              </Button>
            </div>
          )}

          {/* Common Fields */}
          {selectedType !== 'paypal' && (
            <>
              <Input
                label="Nom personnalisé (optionnel)"
                type="text"
                placeholder="Ma carte principale"
                value={formData?.nickname}
                onChange={(e) => handleInputChange('nickname', e?.target?.value)}
                description="Pour identifier facilement cette méthode"
              />

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="setAsDefault"
                  checked={formData?.setAsDefault}
                  onChange={(e) => handleInputChange('setAsDefault', e?.target?.checked)}
                  className="w-4 h-4 text-primary border-border rounded focus:ring-primary"
                />
                <label htmlFor="setAsDefault" className="text-sm text-foreground">
                  Définir comme méthode par défaut
                </label>
              </div>
            </>
          )}

          {/* Security Notice */}
          <div className="bg-success/5 border border-success/20 rounded-md p-3">
            <div className="flex items-start space-x-2">
              <Icon name="Shield" size={16} className="text-success mt-0.5" />
              <div>
                <p className="text-sm font-medium text-success">
                  Sécurité garantie
                </p>
                <p className="text-xs text-muted-foreground">
                  Vos données sont chiffrées et conformes aux standards PCI DSS. 
                  Nous ne stockons jamais vos informations sensibles.
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isLoading}
            >
              Annuler
            </Button>
            <Button
              type="submit"
              variant="default"
              className="flex-1"
              loading={isLoading}
              disabled={selectedType === 'paypal'}
            >
              {isLoading ? 'Ajout en cours...' : 'Ajouter la méthode'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPaymentMethodModal;