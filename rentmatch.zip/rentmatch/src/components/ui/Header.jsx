import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ userRole = 'client', notificationCount = 0, hasActiveBooking = false }) => {
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('fr');
  const [selectedCurrency, setSelectedCurrency] = useState('EUR');
  
  const location = useLocation();
  const notificationRef = useRef(null);
  const profileRef = useRef(null);
  const languageRef = useRef(null);

  // Navigation items based on user role
  const navigationItems = [
    {
      label: 'Demandes',
      path: userRole === 'client' ? '/create-rental-demand' : '/live-offers-dashboard',
      icon: 'Search',
      roleAccess: 'both',
      tooltip: userRole === 'client' ? 'Créer et gérer vos demandes' : 'Voir les demandes actives'
    },
    {
      label: 'Réservations',
      path: '/booking-management',
      icon: 'Calendar',
      roleAccess: 'both',
      tooltip: 'Gérer vos réservations'
    },
    {
      label: 'Paiements',
      path: '/payment-escrow-center',
      icon: 'CreditCard',
      roleAccess: 'both',
      tooltip: 'Centre de paiement sécurisé'
    },
    {
      label: 'Tableau de bord',
      path: userRole === 'agency' ? '/agency-dashboard' : '/live-offers-dashboard',
      icon: 'BarChart3',
      roleAccess: userRole === 'agency' ? 'agency' : 'client',
      tooltip: userRole === 'agency' ? 'Tableau de bord agence' : 'Offres en direct'
    }
  ];

  const mockNotifications = [
    {
      id: 1,
      type: 'offer',
      title: 'Nouvelle offre reçue',
      message: 'Appartement 2 pièces disponible pour vos dates',
      time: '2 min',
      unread: true
    },
    {
      id: 2,
      type: 'booking',
      title: 'Réservation confirmée',
      message: 'Votre réservation a été acceptée',
      time: '1h',
      unread: true
    },
    {
      id: 3,
      type: 'payment',
      title: 'Paiement traité',
      message: 'Votre paiement de 850€ a été sécurisé',
      time: '3h',
      unread: false
    }
  ];

  const languages = [
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'en', label: 'English', flag: '🇬🇧' }
  ];

  const currencies = [
    { code: 'EUR', symbol: '€', label: 'Euro' },
    { code: 'USD', symbol: '$', label: 'Dollar US' }
  ];

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationRef?.current && !notificationRef?.current?.contains(event?.target)) {
        setIsNotificationOpen(false);
      }
      if (profileRef?.current && !profileRef?.current?.contains(event?.target)) {
        setIsProfileOpen(false);
      }
      if (languageRef?.current && !languageRef?.current?.contains(event?.target)) {
        setIsLanguageOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isActiveRoute = (path) => {
    return location?.pathname === path;
  };

  const handleLanguageChange = (langCode, currCode) => {
    setSelectedLanguage(langCode);
    setSelectedCurrency(currCode);
    setIsLanguageOpen(false);
    // Here you would typically update global context/localStorage
  };

  const handleLogout = () => {
    // Handle logout logic
    console.log('Logout clicked');
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'offer': return 'Home';
      case 'booking': return 'Calendar';
      case 'payment': return 'CreditCard';
      default: return 'Bell';
    }
  };

  return (
    <header className="sticky top-0 z-navigation bg-surface border-b border-border shadow-elevation-1">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Logo Section */}
        <div className="flex items-center space-x-8">
          <Link to="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
              <Icon name="Home" size={20} color="white" />
            </div>
            <span className="text-xl font-semibold text-foreground">RentMatch</span>
          </Link>

          {/* Language/Currency Selector */}
          <div className="relative" ref={languageRef}>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsLanguageOpen(!isLanguageOpen)}
              className="flex items-center space-x-1 text-sm"
            >
              <span>{languages?.find(l => l?.code === selectedLanguage)?.flag}</span>
              <span className="hidden sm:inline">{selectedCurrency}</span>
              <Icon name="ChevronDown" size={16} />
            </Button>

            {isLanguageOpen && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-popover border border-border rounded-md shadow-elevation-3 py-1 animate-slide-down">
                {languages?.map((lang) => (
                  <button
                    key={lang?.code}
                    onClick={() => handleLanguageChange(lang?.code, lang?.code === 'fr' ? 'EUR' : 'USD')}
                    className="w-full px-3 py-2 text-left hover:bg-muted flex items-center space-x-2 text-sm"
                  >
                    <span>{lang?.flag}</span>
                    <span>{lang?.label}</span>
                    <span className="ml-auto text-muted-foreground">
                      {lang?.code === 'fr' ? 'EUR' : 'USD'}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {navigationItems?.slice(0, 3)?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                isActiveRoute(item?.path)
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
              title={item?.tooltip}
            >
              <div className="flex items-center space-x-2">
                <Icon name={item?.icon} size={16} />
                <span>{item?.label}</span>
              </div>
            </Link>
          ))}
        </nav>

        {/* Right Section */}
        <div className="flex items-center space-x-2">
          {/* Notifications */}
          <div className="relative" ref={notificationRef}>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsNotificationOpen(!isNotificationOpen)}
              className="relative"
            >
              <Icon name="Bell" size={20} />
              {notificationCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-error text-error-foreground text-xs rounded-full flex items-center justify-center animate-pulse-gentle">
                  {notificationCount > 9 ? '9+' : notificationCount}
                </span>
              )}
            </Button>

            {isNotificationOpen && (
              <div className="absolute top-full right-0 mt-1 w-80 bg-popover border border-border rounded-md shadow-elevation-3 animate-slide-down">
                <div className="p-4 border-b border-border">
                  <h3 className="font-medium text-foreground">Notifications</h3>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {mockNotifications?.map((notification) => (
                    <div
                      key={notification?.id}
                      className={`p-4 border-b border-border hover:bg-muted cursor-pointer ${
                        notification?.unread ? 'bg-accent/5' : ''
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          notification?.type === 'offer' ? 'bg-primary/10 text-primary' :
                          notification?.type === 'booking'? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                        }`}>
                          <Icon name={getNotificationIcon(notification?.type)} size={16} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground">{notification?.title}</p>
                          <p className="text-sm text-muted-foreground mt-1">{notification?.message}</p>
                          <p className="text-xs text-muted-foreground mt-2">{notification?.time}</p>
                        </div>
                        {notification?.unread && (
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 border-t border-border">
                  <Button variant="ghost" size="sm" fullWidth>
                    Voir toutes les notifications
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* User Profile */}
          <div className="relative" ref={profileRef}>
            <Button
              variant="ghost"
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center space-x-2 px-3"
            >
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="white" />
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-sm font-medium text-foreground">
                  {userRole === 'agency' ? 'Agence Pro' : 'Client'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {userRole === 'agency' ? 'Professionnel' : 'Particulier'}
                </p>
              </div>
              <Icon name="ChevronDown" size={16} />
            </Button>

            {isProfileOpen && (
              <div className="absolute top-full right-0 mt-1 w-56 bg-popover border border-border rounded-md shadow-elevation-3 py-1 animate-slide-down">
                <div className="px-3 py-2 border-b border-border">
                  <p className="text-sm font-medium text-foreground">Mon Compte</p>
                  <p className="text-xs text-muted-foreground">
                    {userRole === 'agency' ? 'Compte Professionnel' : 'Compte Personnel'}
                  </p>
                </div>
                
                <Link
                  to="/client-registration-login"
                  className="flex items-center space-x-2 px-3 py-2 text-sm hover:bg-muted"
                  onClick={() => setIsProfileOpen(false)}
                >
                  <Icon name="Settings" size={16} />
                  <span>Paramètres</span>
                </Link>
                
                <Link
                  to="/agency-dashboard"
                  className="flex items-center space-x-2 px-3 py-2 text-sm hover:bg-muted"
                  onClick={() => setIsProfileOpen(false)}
                >
                  <Icon name="BarChart3" size={16} />
                  <span>Tableau de bord</span>
                </Link>
                
                <div className="border-t border-border mt-1 pt-1">
                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-2 px-3 py-2 text-sm hover:bg-muted w-full text-left text-error"
                  >
                    <Icon name="LogOut" size={16} />
                    <span>Déconnexion</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
          >
            <Icon name="Menu" size={20} />
          </Button>
        </div>
      </div>
      {/* Status Indicator Bar */}
      {hasActiveBooking && (
        <div className="bg-success/10 border-b border-success/20 px-4 lg:px-6 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse-gentle"></div>
              <span className="text-sm font-medium text-success">Réservation active</span>
              <span className="text-sm text-muted-foreground">
                Paiement sécurisé • Confirmation en attente
              </span>
            </div>
            <Button variant="ghost" size="sm" className="text-success hover:bg-success/10">
              Voir détails
              <Icon name="ArrowRight" size={16} className="ml-1" />
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;