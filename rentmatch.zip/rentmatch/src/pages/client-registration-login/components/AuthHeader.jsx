import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import LanguageCurrencySelector from '../../../components/ui/LanguageCurrencySelector';

const AuthHeader = () => {
  return (
    <header className="sticky top-0 z-navigation bg-surface/95 backdrop-blur-sm border-b border-border">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Icon name="Home" size={20} color="white" />
          </div>
          <span className="text-xl font-semibold text-foreground">RentMatch</span>
        </Link>

        {/* Language Selector */}
        <LanguageCurrencySelector 
          compact 
          onLanguageChange={() => {}} 
          onCurrencyChange={() => {}} 
        />
      </div>
    </header>
  );
};

export default AuthHeader;