import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthHeader from './components/AuthHeader';
import AuthTabs from './components/AuthTabs';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import SocialLogin from './components/SocialLogin';
import OnboardingTooltip from './components/OnboardingTooltip';
import Image from '../../components/AppImage';

const ClientRegistrationLogin = () => {
  const [activeTab, setActiveTab] = useState('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const navigate = useNavigate();

  // Mock credentials for demonstration
  const mockCredentials = {
    email: 'client@rentmatch.fr',
    password: 'password123',
    phone: '+33 6 12 34 56 78'
  };

  useEffect(() => {
    // Show onboarding tooltip for new users
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (!hasSeenOnboarding) {
      const timer = setTimeout(() => {
        setShowOnboarding(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleLogin = async (formData) => {
    setLoading(true);
    setError('');

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Mock validation
      const isValidEmail = formData?.emailOrPhone === mockCredentials?.email;
      const isValidPhone = formData?.emailOrPhone === mockCredentials?.phone;
      const isValidPassword = formData?.password === mockCredentials?.password;

      if ((isValidEmail || isValidPhone) && isValidPassword) {
        // Store auth token
        localStorage.setItem('authToken', 'mock-jwt-token');
        localStorage.setItem('userRole', 'client');
        localStorage.setItem('userName', 'Jean Dupont');
        
        // Redirect to dashboard or demand creation
        const hasActiveDemands = Math.random() > 0.5;
        navigate(hasActiveDemands ? '/live-offers-dashboard' : '/create-rental-demand');
      } else {
        setError('Email/téléphone ou mot de passe incorrect. Utilisez client@rentmatch.fr et password123');
      }
    } catch (err) {
      setError('Erreur de connexion. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (formData) => {
    setLoading(true);
    setError('');

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mock successful registration
      localStorage.setItem('authToken', 'mock-jwt-token');
      localStorage.setItem('userRole', 'client');
      localStorage.setItem('userName', `${formData?.firstName} ${formData?.lastName}`);
      
      // Redirect to onboarding or demand creation
      navigate('/create-rental-demand');
    } catch (err) {
      setError('Erreur lors de l\'inscription. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  const handleSocialLogin = async (provider) => {
    setLoading(true);
    setError('');

    try {
      // Simulate social login
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      localStorage.setItem('authToken', 'mock-social-jwt-token');
      localStorage.setItem('userRole', 'client');
      localStorage.setItem('userName', provider === 'google' ? 'Utilisateur Google' : 'Utilisateur Facebook');
      
      navigate('/create-rental-demand');
    } catch (err) {
      setError(`Erreur de connexion ${provider}. Veuillez réessayer.`);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseOnboarding = () => {
    setShowOnboarding(false);
    localStorage.setItem('hasSeenOnboarding', 'true');
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthHeader />
      
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5"></div>
      
      {/* Main Content */}
      <div className="relative flex items-center justify-center min-h-[calc(100vh-4rem)] px-4 py-8">
        <div className="w-full max-w-md">
          {/* Welcome Section */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-elevation-2">
              <Image
                src="https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=64&h=64&fit=crop&crop=center"
                alt="RentMatch"
                className="w-10 h-10 rounded-lg object-cover"
              />
            </div>
            <h1 className="text-2xl font-semibold text-foreground mb-2">
              {activeTab === 'login' ? 'Bon retour !' : 'Rejoignez RentMatch'}
            </h1>
            <p className="text-muted-foreground">
              {activeTab === 'login' ?'Connectez-vous pour accéder à vos demandes de location' :'Créez votre compte et trouvez le véhicule parfait'
              }
            </p>
          </div>

          {/* Auth Form Container */}
          <div className="bg-card border border-border rounded-lg shadow-elevation-2 p-6">
            <AuthTabs activeTab={activeTab} onTabChange={setActiveTab} />

            {activeTab === 'login' ? (
              <LoginForm
                onSubmit={handleLogin}
                loading={loading}
                error={error}
              />
            ) : (
              <RegisterForm
                onSubmit={handleRegister}
                loading={loading}
                error={error}
              />
            )}

            <div className="mt-6">
              <SocialLogin
                onSocialLogin={handleSocialLogin}
                loading={loading}
              />
            </div>
          </div>

          {/* Footer Links */}
          <div className="text-center mt-6 space-y-2">
            <p className="text-sm text-muted-foreground">
              {activeTab === 'login' ? "Pas encore de compte ?" : "Déjà inscrit ?"}
              <button
                onClick={() => setActiveTab(activeTab === 'login' ? 'register' : 'login')}
                className="ml-1 text-primary hover:underline font-medium"
              >
                {activeTab === 'login' ? 'Créer un compte' : 'Se connecter'}
              </button>
            </p>
            
            <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">
                Aide
              </a>
              <span>•</span>
              <a href="#" className="hover:text-foreground transition-colors">
                Confidentialité
              </a>
              <span>•</span>
              <a href="#" className="hover:text-foreground transition-colors">
                Conditions
              </a>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="mt-8 p-4 bg-muted/30 rounded-lg border border-border">
            <div className="flex items-center justify-center space-x-6 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span>Paiements sécurisés</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>Données protégées</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span>Support 24/7</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Onboarding Tooltip */}
      <OnboardingTooltip
        isVisible={showOnboarding}
        onClose={handleCloseOnboarding}
      />
    </div>
  );
};

export default ClientRegistrationLogin;