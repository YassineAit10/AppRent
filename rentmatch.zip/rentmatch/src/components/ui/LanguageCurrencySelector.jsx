import React, { useState, useRef, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const LanguageCurrencySelector = ({ 
  selectedLanguage = 'fr',
  selectedCurrency = 'EUR',
  onLanguageChange,
  onCurrencyChange,
  compact = false 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const languages = [
    { 
      code: 'fr', 
      label: 'Français', 
      flag: '🇫🇷',
      defaultCurrency: 'EUR'
    },
    { 
      code: 'en', 
      label: 'English', 
      flag: '🇬🇧',
      defaultCurrency: 'GBP'
    },
    { 
      code: 'es', 
      label: 'Español', 
      flag: '🇪🇸',
      defaultCurrency: 'EUR'
    },
    { 
      code: 'de', 
      label: 'Deutsch', 
      flag: '🇩🇪',
      defaultCurrency: 'EUR'
    }
  ];

  const currencies = [
    { 
      code: 'EUR', 
      symbol: '€', 
      label: 'Euro',
      flag: '🇪🇺'
    },
    { 
      code: 'USD', 
      symbol: '$', 
      label: 'US Dollar',
      flag: '🇺🇸'
    },
    { 
      code: 'GBP', 
      symbol: '£', 
      label: 'British Pound',
      flag: '🇬🇧'
    },
    { 
      code: 'CHF', 
      symbol: 'CHF', 
      label: 'Swiss Franc',
      flag: '🇨🇭'
    }
  ];

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentLanguage = languages?.find(lang => lang?.code === selectedLanguage);
  const currentCurrency = currencies?.find(curr => curr?.code === selectedCurrency);

  const handleLanguageSelect = (languageCode) => {
    const language = languages?.find(lang => lang?.code === languageCode);
    if (onLanguageChange) {
      onLanguageChange(languageCode);
    }
    
    // Auto-switch currency to default for the language if no explicit currency handler
    if (!onCurrencyChange && language?.defaultCurrency !== selectedCurrency) {
      // This would typically update global state
      console.log(`Auto-switching currency to ${language?.defaultCurrency}`);
    }
    
    setIsOpen(false);
  };

  const handleCurrencySelect = (currencyCode) => {
    if (onCurrencyChange) {
      onCurrencyChange(currencyCode);
    }
    setIsOpen(false);
  };

  if (compact) {
    return (
      <div className="relative" ref={dropdownRef}>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center space-x-1 px-2 focus-ring"
        >
          <span className="text-base">{currentLanguage?.flag}</span>
          <span className="text-xs font-mono">{selectedCurrency}</span>
          <Icon name="ChevronDown" size={12} />
        </Button>
        {isOpen && (
          <div className="absolute top-full left-0 mt-1 w-48 bg-popover border border-border rounded-md shadow-elevation-3 py-1 animate-slide-down z-dropdown">
            {languages?.map((language) => (
              <button
                key={language?.code}
                onClick={() => handleLanguageSelect(language?.code)}
                className={`w-full flex items-center justify-between px-3 py-2 text-sm hover:bg-muted transition-colors ${
                  language?.code === selectedLanguage ? 'bg-primary/10 text-primary' : ''
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span>{language?.flag}</span>
                  <span>{language?.label}</span>
                </div>
                <span className="text-xs font-mono text-muted-foreground">
                  {language?.defaultCurrency}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 focus-ring"
      >
        <span className="text-base">{currentLanguage?.flag}</span>
        <div className="hidden sm:block text-left">
          <div className="text-xs text-muted-foreground">
            {currentLanguage?.label}
          </div>
          <div className="text-xs font-mono">
            {currentCurrency?.symbol} {selectedCurrency}
          </div>
        </div>
        <div className="sm:hidden text-xs font-mono">
          {selectedCurrency}
        </div>
        <Icon name="ChevronDown" size={14} />
      </Button>
      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-72 bg-popover border border-border rounded-lg shadow-elevation-3 animate-slide-down z-dropdown">
          {/* Language Section */}
          <div className="p-3 border-b border-border">
            <h4 className="text-sm font-semibold text-foreground mb-2 flex items-center">
              <Icon name="Globe" size={16} className="mr-2" />
              Langue
            </h4>
            <div className="grid grid-cols-2 gap-1">
              {languages?.map((language) => (
                <button
                  key={language?.code}
                  onClick={() => handleLanguageSelect(language?.code)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm transition-colors ${
                    language?.code === selectedLanguage
                      ? 'bg-primary text-primary-foreground'
                      : 'hover:bg-muted'
                  }`}
                >
                  <span>{language?.flag}</span>
                  <span className="truncate">{language?.label}</span>
                  {language?.code === selectedLanguage && (
                    <Icon name="Check" size={14} className="ml-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Currency Section */}
          <div className="p-3">
            <h4 className="text-sm font-semibold text-foreground mb-2 flex items-center">
              <Icon name="DollarSign" size={16} className="mr-2" />
              Devise
            </h4>
            <div className="space-y-1">
              {currencies?.map((currency) => (
                <button
                  key={currency?.code}
                  onClick={() => handleCurrencySelect(currency?.code)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors ${
                    currency?.code === selectedCurrency
                      ? 'bg-primary text-primary-foreground'
                      : 'hover:bg-muted'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span>{currency?.flag}</span>
                    <span>{currency?.label}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-xs">
                      {currency?.symbol} {currency?.code}
                    </span>
                    {currency?.code === selectedCurrency && (
                      <Icon name="Check" size={14} />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Footer Info */}
          <div className="px-3 py-2 border-t border-border bg-muted/30">
            <p className="text-xs text-muted-foreground flex items-center">
              <Icon name="Info" size={12} className="mr-1" />
              Les prix seront convertis automatiquement
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageCurrencySelector;