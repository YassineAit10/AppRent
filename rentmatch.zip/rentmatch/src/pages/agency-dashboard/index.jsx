import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Header from '../../components/ui/Header';
import DemandFilters from './components/DemandFilters';
import DemandCard from './components/DemandCard';
import QuickStats from './components/QuickStats';
import CalendarOverview from './components/CalendarOverview';
import OfferTemplates from './components/OfferTemplates';
import CreateOfferModal from './components/CreateOfferModal';

const AgencyDashboard = () => {
  const [filters, setFilters] = useState({});
  const [selectedDemand, setSelectedDemand] = useState(null);
  const [isCreateOfferModalOpen, setIsCreateOfferModalOpen] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [sortBy, setSortBy] = useState('deadline');
  const [viewMode, setViewMode] = useState('cards');

  // Mock data for agency dashboard
  const mockStats = {
    activeDemands: 24,
    pendingOffers: 8,
    confirmedBookings: 12,
    responseRate: 94,
    avgResponseTime: '1h 23m',
    monthlyRevenue: 15750,
    demandsChange: 12,
    offersChange: -3,
    bookingsChange: 8,
    responseRateChange: 2,
    responseTimeChange: -15,
    revenueChange: 23,
    reliabilityScore: 96,
    conversionRate: 68,
    customerSatisfaction: 4.7
  };

  const mockDemands = [
    {
      id: 'DEM-2024-001',
      client: {
        name: 'Marie Dubois',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
        rating: 4.8,
        totalBookings: 15,
        memberSince: '2023',
        verified: true
      },
      location: 'Aéroport Charles de Gaulle, Paris',
      startDate: '2024-08-20',
      endDate: '2024-08-27',
      vehiclePreferences: ['Compacte', 'Économique'],
      budgetPerDay: 45,
      paymentMethod: 'escrow',
      specialRequirements: ['GPS inclus', 'Transmission automatique'],
      responseDeadline: new Date(Date.now() + 4 * 60 * 60 * 1000)?.toISOString(),
      matchScore: 92,
      timeAgo: '2h',
      responseCount: 3
    },
    {
      id: 'DEM-2024-002',
      client: {
        name: 'Jean-Pierre Martin',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
        rating: 4.2,
        totalBookings: 8,
        memberSince: '2024',
        verified: false
      },
      location: 'Gare de Lyon, Paris',
      startDate: '2024-08-18',
      endDate: '2024-08-22',
      vehiclePreferences: ['SUV', 'Grande taille'],
      budgetPerDay: 85,
      paymentMethod: 'location',
      specialRequirements: ['Sièges enfant', '7 places minimum'],
      responseDeadline: new Date(Date.now() + 1.5 * 60 * 60 * 1000)?.toISOString(),
      matchScore: 78,
      timeAgo: '45min',
      responseCount: 1
    },
    {
      id: 'DEM-2024-003',
      client: {
        name: 'Sophie Laurent',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
        rating: 4.9,
        totalBookings: 32,
        memberSince: '2022',
        verified: true
      },
      location: 'Centre-ville Nice',
      startDate: '2024-08-25',
      endDate: '2024-09-01',
      vehiclePreferences: ['Premium', 'Luxe'],
      budgetPerDay: 120,
      paymentMethod: 'escrow',
      specialRequirements: ['Décapotable préférée', 'Assurance tous risques'],
      responseDeadline: new Date(Date.now() + 18 * 60 * 60 * 1000)?.toISOString(),
      matchScore: 95,
      timeAgo: '30min',
      responseCount: 0
    },
    {
      id: 'DEM-2024-004',
      client: {
        name: 'Thomas Rousseau',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        rating: 3.8,
        totalBookings: 5,
        memberSince: '2024',
        verified: true
      },
      location: 'Aéroport de Marseille',
      startDate: '2024-08-19',
      endDate: '2024-08-21',
      vehiclePreferences: ['Économique', 'Compacte'],
      budgetPerDay: 35,
      paymentMethod: 'location',
      specialRequirements: [],
      responseDeadline: new Date(Date.now() + 6 * 60 * 60 * 1000)?.toISOString(),
      matchScore: 65,
      timeAgo: '1h',
      responseCount: 2
    },
    {
      id: 'DEM-2024-005',
      client: {
        name: 'Isabelle Moreau',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
        rating: 4.6,
        totalBookings: 19,
        memberSince: '2023',
        verified: true
      },
      location: 'Gare TGV Avignon',
      startDate: '2024-08-23',
      endDate: '2024-08-30',
      vehiclePreferences: ['Berline', 'Standard'],
      budgetPerDay: 65,
      paymentMethod: 'escrow',
      specialRequirements: ['Climatisation', 'Bluetooth'],
      responseDeadline: new Date(Date.now() + 12 * 60 * 60 * 1000)?.toISOString(),
      matchScore: 88,
      timeAgo: '3h',
      responseCount: 1
    }
  ];

  const mockAvailableVehicles = [
    {
      id: 'VEH-001',
      brand: 'Peugeot',
      model: '208',
      category: 'Économique',
      year: 2023,
      fuelType: 'Essence',
      transmission: 'Manuelle'
    },
    {
      id: 'VEH-002',
      brand: 'Renault',
      model: 'Clio',
      category: 'Compacte',
      year: 2024,
      fuelType: 'Hybride',
      transmission: 'Automatique'
    },
    {
      id: 'VEH-003',
      brand: 'BMW',
      model: 'X3',
      category: 'SUV',
      year: 2023,
      fuelType: 'Diesel',
      transmission: 'Automatique'
    }
  ];

  const mockAvailabilityData = [
    { date: '2024-08-16', status: 'available', availableVehicles: 8 },
    { date: '2024-08-17', status: 'available', availableVehicles: 6 },
    { date: '2024-08-18', status: 'booked', availableVehicles: 3 },
    { date: '2024-08-19', status: 'booked', availableVehicles: 2 },
    { date: '2024-08-20', status: 'available', availableVehicles: 7 },
    { date: '2024-08-21', status: 'blocked', availableVehicles: 0 },
    { date: '2024-08-22', status: 'maintenance', availableVehicles: 0 }
  ];

  // Filter and sort demands
  const filteredDemands = mockDemands?.filter(demand => {
    if (filters?.location && !demand?.location?.toLowerCase()?.includes(filters?.location?.toLowerCase())) {
      return false;
    }
    if (filters?.vehicleTypes?.length > 0) {
      const hasMatchingType = demand?.vehiclePreferences?.some(pref => 
        filters?.vehicleTypes?.some(type => pref?.toLowerCase()?.includes(type))
      );
      if (!hasMatchingType) return false;
    }
    if (filters?.budgetRange?.min && demand?.budgetPerDay < parseFloat(filters?.budgetRange?.min)) {
      return false;
    }
    if (filters?.budgetRange?.max && demand?.budgetPerDay > parseFloat(filters?.budgetRange?.max)) {
      return false;
    }
    if (filters?.clientRating && demand?.client?.rating < parseFloat(filters?.clientRating)) {
      return false;
    }
    return true;
  });

  const sortedDemands = [...filteredDemands]?.sort((a, b) => {
    switch (sortBy) {
      case 'deadline':
        return new Date(a.responseDeadline) - new Date(b.responseDeadline);
      case 'budget':
        return b?.budgetPerDay - a?.budgetPerDay;
      case 'match':
        return b?.matchScore - a?.matchScore;
      case 'recent':
        return new Date(b.createdAt || Date.now()) - new Date(a.createdAt || Date.now());
      default:
        return 0;
    }
  });

  const handleCreateOffer = (demand) => {
    setSelectedDemand(demand);
    setIsCreateOfferModalOpen(true);
  };

  const handleSubmitOffer = async (offerData) => {
    console.log('Submitting offer:', offerData);
    // Here you would typically send the offer to your backend
    setRefreshTrigger(prev => prev + 1);
  };

  const handleViewDetails = (demand) => {
    console.log('Viewing demand details:', demand);
    // Navigate to detailed view or open modal
  };

  const handleUseTemplate = (template) => {
    console.log('Using template:', template);
    // Pre-fill offer form with template data
  };

  // Auto-refresh demands every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTrigger(prev => prev + 1);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="agency" notificationCount={5} hasActiveBooking={true} />
      <div className="container mx-auto px-4 lg:px-6 py-6">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Tableau de bord Agence</h1>
            <p className="text-muted-foreground">
              Gérez vos demandes et créez des offres compétitives
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm">
              <Icon name="Download" size={16} />
              Exporter
            </Button>
            <Button variant="outline" size="sm">
              <Icon name="Settings" size={16} />
              Paramètres
            </Button>
            <Link to="/booking-management">
              <Button variant="default" size="sm">
                <Icon name="Calendar" size={16} />
                Réservations
              </Button>
            </Link>
          </div>
        </div>

        {/* Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar - Filters */}
          <div className="lg:col-span-3">
            <div className="space-y-6">
              <DemandFilters 
                onFiltersChange={setFilters}
                activeFilters={filters}
              />
              <QuickStats stats={mockStats} />
            </div>
          </div>

          {/* Center - Demand Feed */}
          <div className="lg:col-span-6">
            <div className="bg-card border border-border rounded-lg shadow-elevation-1">
              {/* Feed Header */}
              <div className="flex items-center justify-between p-4 border-b border-border">
                <div className="flex items-center space-x-3">
                  <Icon name="Search" size={20} className="text-primary" />
                  <div>
                    <h2 className="font-semibold text-foreground">Demandes actives</h2>
                    <p className="text-sm text-muted-foreground">
                      {sortedDemands?.length} demande(s) correspondante(s)
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e?.target?.value)}
                    className="px-3 py-1 border border-border rounded-md text-sm bg-input text-foreground"
                  >
                    <option value="deadline">Par échéance</option>
                    <option value="budget">Par budget</option>
                    <option value="match">Par compatibilité</option>
                    <option value="recent">Plus récentes</option>
                  </select>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setRefreshTrigger(prev => prev + 1)}
                  >
                    <Icon name="RefreshCw" size={16} />
                  </Button>
                </div>
              </div>

              {/* Demand Cards */}
              <div className="max-h-[800px] overflow-y-auto">
                {sortedDemands?.length === 0 ? (
                  <div className="p-8 text-center">
                    <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-medium text-foreground mb-2">Aucune demande trouvée</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Ajustez vos filtres pour voir plus de demandes
                    </p>
                    <Button variant="outline" onClick={() => setFilters({})}>
                      Effacer les filtres
                    </Button>
                  </div>
                ) : (
                  <div className="p-4 space-y-4">
                    {sortedDemands?.map((demand) => (
                      <DemandCard
                        key={demand?.id}
                        demand={demand}
                        onCreateOffer={handleCreateOffer}
                        onViewDetails={handleViewDetails}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Sidebar - Calendar & Templates */}
          <div className="lg:col-span-3">
            <div className="space-y-6">
              <CalendarOverview 
                availabilityData={mockAvailabilityData}
                onDateClick={(date) => console.log('Date clicked:', date)}
                onBlockDate={() => console.log('Block date clicked')}
              />
              <OfferTemplates 
                templates={[]}
                onUseTemplate={handleUseTemplate}
                onCreateTemplate={() => console.log('Create template')}
                onEditTemplate={(template) => console.log('Edit template:', template)}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Create Offer Modal */}
      <CreateOfferModal
        isOpen={isCreateOfferModalOpen}
        onClose={() => setIsCreateOfferModalOpen(false)}
        demand={selectedDemand}
        availableVehicles={mockAvailableVehicles}
        onSubmitOffer={handleSubmitOffer}
      />
    </div>
  );
};

export default AgencyDashboard;