import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Input from '../../../components/ui/Input';

const AdvancedPreferences = ({ 
  preferences = {}, 
  onPreferencesChange,
  isExpanded = false,
  onToggleExpanded 
}) => {
  const [localPreferences, setLocalPreferences] = useState({
    transmission: 'any',
    fuelType: 'any',
    equipment: [],
    specialRequirements: '',
    driverAge: '',
    experienceYears: '',
    additionalDrivers: false,
    crossBorder: false,
    insurance: 'standard',
    mileage: 'unlimited',
    ...preferences
  });

  const transmissionOptions = [
    { value: 'any', label: 'Indifférent' },
    { value: 'manual', label: 'Manuelle' },
    { value: 'automatic', label: 'Automatique' }
  ];

  const fuelTypeOptions = [
    { value: 'any', label: 'Indifférent' },
    { value: 'petrol', label: 'Essence' },
    { value: 'diesel', label: 'Diesel' },
    { value: 'hybrid', label: 'Hybride' },
    { value: 'electric', label: 'Électrique' },
    { value: 'plugin-hybrid', label: 'Hybride rechargeable' }
  ];

  const equipmentOptions = [
    { id: 'gps', label: 'GPS / Navigation', icon: 'Navigation' },
    { id: 'bluetooth', label: 'Bluetooth', icon: 'Bluetooth' },
    { id: 'usb', label: 'Ports USB', icon: 'Usb' },
    { id: 'ac', label: 'Climatisation', icon: 'Snowflake' },
    { id: 'cruise', label: 'Régulateur de vitesse', icon: 'Gauge' },
    { id: 'parking', label: 'Aide au stationnement', icon: 'ParkingCircle' },
    { id: 'camera', label: 'Caméra de recul', icon: 'Camera' },
    { id: 'roof', label: 'Barres de toit', icon: 'Package' },
    { id: 'child-seat', label: 'Siège enfant', icon: 'Baby' },
    { id: 'wifi', label: 'WiFi embarqué', icon: 'Wifi' }
  ];

  const insuranceOptions = [
    { value: 'standard', label: 'Assurance standard', description: 'Couverture de base incluse' },
    { value: 'comprehensive', label: 'Tous risques', description: 'Couverture étendue recommandée' },
    { value: 'premium', label: 'Premium', description: 'Couverture maximale sans franchise' }
  ];

  const mileageOptions = [
    { value: 'unlimited', label: 'Kilométrage illimité' },
    { value: '200', label: '200 km/jour' },
    { value: '300', label: '300 km/jour' },
    { value: '500', label: '500 km/jour' },
    { value: '1000', label: '1000 km/jour' }
  ];

  const handlePreferenceChange = (key, value) => {
    const updated = { ...localPreferences, [key]: value };
    setLocalPreferences(updated);
    onPreferencesChange(updated);
  };

  const handleEquipmentToggle = (equipmentId) => {
    const currentEquipment = localPreferences?.equipment || [];
    const updated = currentEquipment?.includes(equipmentId)
      ? currentEquipment?.filter(id => id !== equipmentId)
      : [...currentEquipment, equipmentId];
    
    handlePreferenceChange('equipment', updated);
  };

  if (!isExpanded) {
    return (
      <div className="border border-border rounded-lg p-4">
        <button
          onClick={onToggleExpanded}
          className="w-full flex items-center justify-between text-left hover:bg-muted/50 transition-colors p-2 rounded-md"
        >
          <div className="flex items-center space-x-3">
            <Icon name="Settings" size={20} className="text-primary" />
            <div>
              <h3 className="text-lg font-semibold text-foreground">Préférences avancées</h3>
              <p className="text-sm text-muted-foreground">
                Transmission, carburant, équipements et options
              </p>
            </div>
          </div>
          <Icon name="ChevronDown" size={20} className="text-muted-foreground" />
        </button>
      </div>
    );
  }

  return (
    <div className="border border-border rounded-lg">
      {/* Header */}
      <div className="border-b border-border p-4">
        <button
          onClick={onToggleExpanded}
          className="w-full flex items-center justify-between text-left hover:bg-muted/50 transition-colors p-2 rounded-md"
        >
          <div className="flex items-center space-x-3">
            <Icon name="Settings" size={20} className="text-primary" />
            <div>
              <h3 className="text-lg font-semibold text-foreground">Préférences avancées</h3>
              <p className="text-sm text-muted-foreground">
                Personnalisez votre demande avec des critères spécifiques
              </p>
            </div>
          </div>
          <Icon name="ChevronUp" size={20} className="text-muted-foreground" />
        </button>
      </div>
      {/* Content */}
      <div className="p-6 space-y-8">
        {/* Vehicle Specifications */}
        <div className="space-y-6">
          <h4 className="text-md font-semibold text-foreground flex items-center">
            <Icon name="Car" size={18} className="mr-2 text-secondary" />
            Spécifications du véhicule
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Select
              label="Type de transmission"
              options={transmissionOptions}
              value={localPreferences?.transmission}
              onChange={(value) => handlePreferenceChange('transmission', value)}
              description="Votre préférence pour la boîte de vitesses"
            />
            
            <Select
              label="Type de carburant"
              options={fuelTypeOptions}
              value={localPreferences?.fuelType}
              onChange={(value) => handlePreferenceChange('fuelType', value)}
              description="Motorisation souhaitée"
            />
          </div>
        </div>

        {/* Equipment & Features */}
        <div className="space-y-6">
          <h4 className="text-md font-semibold text-foreground flex items-center">
            <Icon name="Package" size={18} className="mr-2 text-accent" />
            Équipements souhaités
          </h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {equipmentOptions?.map((equipment) => (
              <div key={equipment?.id} className="flex items-center space-x-3">
                <Checkbox
                  checked={localPreferences?.equipment?.includes(equipment?.id) || false}
                  onChange={() => handleEquipmentToggle(equipment?.id)}
                />
                <div className="flex items-center space-x-2">
                  <Icon name={equipment?.icon} size={16} className="text-muted-foreground" />
                  <label className="text-sm font-medium text-foreground cursor-pointer">
                    {equipment?.label}
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Driver Information */}
        <div className="space-y-6">
          <h4 className="text-md font-semibold text-foreground flex items-center">
            <Icon name="User" size={18} className="mr-2 text-warning" />
            Informations conducteur
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="Âge du conducteur principal"
              type="number"
              min="18"
              max="99"
              value={localPreferences?.driverAge}
              onChange={(e) => handlePreferenceChange('driverAge', e?.target?.value)}
              description="Requis pour l'assurance"
            />
            
            <Input
              label="Années d'expérience"
              type="number"
              min="0"
              max="50"
              value={localPreferences?.experienceYears}
              onChange={(e) => handlePreferenceChange('experienceYears', e?.target?.value)}
              description="Expérience de conduite"
            />
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Checkbox
                checked={localPreferences?.additionalDrivers}
                onChange={(e) => handlePreferenceChange('additionalDrivers', e?.target?.checked)}
              />
              <div>
                <label className="text-sm font-medium text-foreground">
                  Conducteurs supplémentaires
                </label>
                <p className="text-xs text-muted-foreground">
                  Autoriser d'autres personnes à conduire le véhicule
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Checkbox
                checked={localPreferences?.crossBorder}
                onChange={(e) => handlePreferenceChange('crossBorder', e?.target?.checked)}
              />
              <div>
                <label className="text-sm font-medium text-foreground">
                  Circulation transfrontalière
                </label>
                <p className="text-xs text-muted-foreground">
                  Possibilité de sortir du territoire français
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Insurance & Mileage */}
        <div className="space-y-6">
          <h4 className="text-md font-semibold text-foreground flex items-center">
            <Icon name="Shield" size={18} className="mr-2 text-success" />
            Assurance et kilométrage
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Select
              label="Type d'assurance"
              options={insuranceOptions}
              value={localPreferences?.insurance}
              onChange={(value) => handlePreferenceChange('insurance', value)}
              description="Niveau de couverture souhaité"
            />
            
            <Select
              label="Kilométrage"
              options={mileageOptions}
              value={localPreferences?.mileage}
              onChange={(value) => handlePreferenceChange('mileage', value)}
              description="Limite de kilométrage par jour"
            />
          </div>
        </div>

        {/* Special Requirements */}
        <div className="space-y-4">
          <h4 className="text-md font-semibold text-foreground flex items-center">
            <Icon name="MessageSquare" size={18} className="mr-2 text-primary" />
            Exigences particulières
          </h4>
          
          <Input
            label="Commentaires et demandes spéciales"
            type="textarea"
            rows={4}
            value={localPreferences?.specialRequirements}
            onChange={(e) => handlePreferenceChange('specialRequirements', e?.target?.value)}
            placeholder="Décrivez vos besoins spécifiques, contraintes particulières, ou toute information utile pour les agences..."
            description="Ces informations aideront les agences à personnaliser leurs offres"
          />
        </div>

        {/* Preferences Summary */}
        <div className="bg-muted/50 rounded-lg p-4">
          <h5 className="text-sm font-medium text-foreground mb-3 flex items-center">
            <Icon name="CheckCircle" size={16} className="mr-2 text-success" />
            Résumé de vos préférences
          </h5>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            {localPreferences?.transmission !== 'any' && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Transmission:</span>
                <span className="font-medium">
                  {transmissionOptions?.find(opt => opt?.value === localPreferences?.transmission)?.label}
                </span>
              </div>
            )}
            
            {localPreferences?.fuelType !== 'any' && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Carburant:</span>
                <span className="font-medium">
                  {fuelTypeOptions?.find(opt => opt?.value === localPreferences?.fuelType)?.label}
                </span>
              </div>
            )}
            
            {localPreferences?.equipment?.length > 0 && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Équipements:</span>
                <span className="font-medium">{localPreferences?.equipment?.length} sélectionné{localPreferences?.equipment?.length > 1 ? 's' : ''}</span>
              </div>
            )}
            
            <div className="flex justify-between">
              <span className="text-muted-foreground">Assurance:</span>
              <span className="font-medium">
                {insuranceOptions?.find(opt => opt?.value === localPreferences?.insurance)?.label}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedPreferences;