import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Header from '../../components/ui/Header';
import BookingCard from './components/BookingCard';
import BookingFilters from './components/BookingFilters';
import BookingStats from './components/BookingStats';
import PaymentStatusCard from './components/PaymentStatusCard';
import EmergencySupport from './components/EmergencySupport';

const BookingManagement = () => {
  const [userRole, setUserRole] = useState('client'); // 'client' or 'agency'
  const [bookings, setBookings] = useState([]);
  const [filteredBookings, setFilteredBookings] = useState([]);
  const [filters, setFilters] = useState({
    search: '',
    status: 'all',
    timeRange: 'all',
    sortBy: 'pickup_date_asc'
  });
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showPaymentDetails, setShowPaymentDetails] = useState(false);

  // Mock data
  const mockBookings = [
    {
      id: 'BK-2024-001',
      status: 'confirmed',
      paymentStatus: 'secured',
      paymentMethod: 'escrow',
      vehicle: {
        id: 'v1',
        name: 'Peugeot 308',
        category: 'Berline compacte',
        image: 'https://images.unsplash.com/photo-1549924231-f129b911e442?w=400',
        transmission: 'Manuelle',
        fuel: 'Essence',
        features: ['Climatisation', 'GPS', 'Bluetooth', 'Régulateur de vitesse']
      },
      pickupDate: '2024-08-18T10:00:00Z',
      returnDate: '2024-08-22T18:00:00Z',
      pickupLocation: 'Aéroport Charles de Gaulle',
      pickupAddress: 'Terminal 2E, 95700 Roissy-en-France',
      returnLocation: 'Aéroport Charles de Gaulle',
      returnAddress: 'Terminal 2E, 95700 Roissy-en-France',
      totalPrice: 280,
      depositAmount: 100,
      paymentDate: '2024-08-16T14:30:00Z',
      transactionId: 'TXN-2024-001',
      pricing: {
        basePrice: 200,
        extras: 30,
        insurance: 25,
        taxes: 20,
        serviceFee: 5
      },
      clientInfo: {
        name: 'Marie Dubois',
        phone: '+33 6 12 34 56 78',
        email: 'marie.dubois@email.com'
      },
      agencyInfo: {
        name: 'EuroRent Paris',
        phone: '+33 1 23 45 67 89',
        rating: 4.8,
        reviews: 156
      }
    },
    {
      id: 'BK-2024-002',
      status: 'prepared',
      paymentStatus: 'secured',
      paymentMethod: 'escrow',
      vehicle: {
        id: 'v2',
        name: 'Renault Clio',
        category: 'Citadine',
        image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400',
        transmission: 'Automatique',
        fuel: 'Diesel',
        features: ['Climatisation', 'Bluetooth', 'Aide au stationnement']
      },
      pickupDate: '2024-08-17T14:00:00Z',
      returnDate: '2024-08-19T12:00:00Z',
      pickupLocation: 'Gare du Nord',
      pickupAddress: '18 Rue de Dunkerque, 75010 Paris',
      returnLocation: 'Gare du Nord',
      returnAddress: '18 Rue de Dunkerque, 75010 Paris',
      totalPrice: 120,
      depositAmount: 50,
      paymentDate: '2024-08-15T09:15:00Z',
      transactionId: 'TXN-2024-002',
      pricing: {
        basePrice: 80,
        extras: 15,
        insurance: 15,
        taxes: 8,
        serviceFee: 2
      },
      clientInfo: {
        name: 'Pierre Martin',
        phone: '+33 6 98 76 54 32',
        email: 'pierre.martin@email.com'
      },
      agencyInfo: {
        name: 'CityRent Express',
        phone: '+33 1 98 76 54 32',
        rating: 4.5,
        reviews: 89
      }
    },
    {
      id: 'BK-2024-003',
      status: 'completed',
      paymentStatus: 'released',
      paymentMethod: 'escrow',
      vehicle: {
        id: 'v3',
        name: 'Volkswagen Golf',
        category: 'Berline compacte',
        image: 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=400',
        transmission: 'Manuelle',
        fuel: 'Essence',
        features: ['Climatisation', 'GPS', 'Bluetooth', 'Jantes alliage']
      },
      pickupDate: '2024-08-10T09:00:00Z',
      returnDate: '2024-08-14T17:00:00Z',
      pickupLocation: 'Centre-ville Lyon',
      pickupAddress: '25 Rue de la République, 69002 Lyon',
      returnLocation: 'Centre-ville Lyon',
      returnAddress: '25 Rue de la République, 69002 Lyon',
      totalPrice: 320,
      depositAmount: 120,
      paymentDate: '2024-08-08T16:45:00Z',
      transactionId: 'TXN-2024-003',
      pricing: {
        basePrice: 240,
        extras: 40,
        insurance: 20,
        taxes: 16,
        serviceFee: 4
      },
      clientInfo: {
        name: 'Sophie Leroy',
        phone: '+33 6 11 22 33 44',
        email: 'sophie.leroy@email.com'
      },
      agencyInfo: {
        name: 'Lyon Auto Location',
        phone: '+33 4 78 90 12 34',
        rating: 4.9,
        reviews: 203
      }
    }
  ];

  const mockStats = {
    activeBookings: 2,
    upcomingBookings: 1,
    completedBookings: 1,
    totalSpent: 720,
    // Agency stats
    pendingConfirmations: 3,
    urgentConfirmations: 1,
    monthlyRevenue: 15420,
    confirmationRate: 94,
    revenueChange: 12,
    confirmationRateChange: -2
  };

  // Initialize data
  useEffect(() => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setBookings(mockBookings);
      setFilteredBookings(mockBookings);
      setIsLoading(false);
    }, 1000);
  }, []);

  // Filter bookings
  useEffect(() => {
    let filtered = [...bookings];

    // Search filter
    if (filters?.search) {
      const searchTerm = filters?.search?.toLowerCase();
      filtered = filtered?.filter(booking =>
        booking?.vehicle?.name?.toLowerCase()?.includes(searchTerm) ||
        booking?.pickupLocation?.toLowerCase()?.includes(searchTerm) ||
        booking?.id?.toLowerCase()?.includes(searchTerm)
      );
    }

    // Status filter
    if (filters?.status !== 'all') {
      if (filters?.status === 'upcoming') {
        filtered = filtered?.filter(booking => 
          new Date(booking.pickupDate) > new Date() && 
          ['confirmed', 'prepared']?.includes(booking?.status)
        );
      } else {
        filtered = filtered?.filter(booking => booking?.status === filters?.status);
      }
    }

    // Time range filter
    if (filters?.timeRange !== 'all') {
      const now = new Date();
      const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

      filtered = filtered?.filter(booking => {
        const pickupDate = new Date(booking.pickupDate);
        switch (filters?.timeRange) {
          case 'upcoming':
            return pickupDate > new Date();
          case 'current':
            return booking?.status === 'active';
          case 'past':
            return pickupDate < new Date();
          case 'this_week':
            return pickupDate >= startOfWeek;
          case 'this_month':
            return pickupDate >= startOfMonth;
          case 'last_month':
            return pickupDate >= startOfLastMonth && pickupDate <= endOfLastMonth;
          default:
            return true;
        }
      });
    }

    // Sort bookings
    filtered?.sort((a, b) => {
      switch (filters?.sortBy) {
        case 'pickup_date_asc':
          return new Date(a.pickupDate) - new Date(b.pickupDate);
        case 'pickup_date_desc':
          return new Date(b.pickupDate) - new Date(a.pickupDate);
        case 'created_date_desc':
          return new Date(b.paymentDate) - new Date(a.paymentDate);
        case 'price_asc':
          return a?.totalPrice - b?.totalPrice;
        case 'price_desc':
          return b?.totalPrice - a?.totalPrice;
        default:
          return 0;
      }
    });

    setFilteredBookings(filtered);
  }, [bookings, filters]);

  const handleStatusUpdate = (bookingId, newStatus) => {
    setBookings(prev => prev?.map(booking =>
      booking?.id === bookingId
        ? { ...booking, status: newStatus }
        : booking
    ));
  };

  const handleMessageClick = (booking) => {
    const message = `Bonjour, concernant ma réservation ${booking?.id} pour le véhicule ${booking?.vehicle?.name}, je souhaiterais vous contacter.`;
    const whatsappUrl = `https://wa.me/33123456789?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleViewDetails = (booking) => {
    setSelectedBooking(booking);
    setShowPaymentDetails(true);
  };

  const handleModifyBooking = (booking) => {
    // Navigate to modification page or open modal
    console.log('Modify booking:', booking?.id);
  };

  const handleCancelBooking = (booking) => {
    // Open cancellation modal or process
    console.log('Cancel booking:', booking?.id);
  };

  const handlePaymentAction = (action, booking) => {
    console.log('Payment action:', action, booking?.id);
  };

  const handleViewReceipt = (booking) => {
    console.log('View receipt for:', booking?.id);
  };

  const handleRequestRefund = (booking) => {
    console.log('Request refund for:', booking?.id);
  };

  const handleContactSupport = (booking) => {
    console.log('Contact support for:', booking?.id);
  };

  const handleReportIssue = (bookingId, issueType) => {
    console.log('Report issue:', issueType, 'for booking:', bookingId);
  };

  const getBookingCounts = () => {
    return {
      total: bookings?.length,
      confirmed: bookings?.filter(b => b?.status === 'confirmed')?.length,
      active: bookings?.filter(b => b?.status === 'active')?.length,
      upcoming: bookings?.filter(b => 
        new Date(b.pickupDate) > new Date() && 
        ['confirmed', 'prepared']?.includes(b?.status)
      )?.length
    };
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={userRole} />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Chargement de vos réservations...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header 
        userRole={userRole} 
        notificationCount={3}
        hasActiveBooking={bookings?.some(b => ['confirmed', 'prepared', 'active']?.includes(b?.status))}
      />
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Page Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Gestion des réservations</h1>
              <p className="text-muted-foreground">
                {userRole === 'agency' ?'Gérez vos confirmations et suivez vos réservations clients' :'Suivez et gérez toutes vos réservations de véhicules'
                }
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setUserRole(userRole === 'client' ? 'agency' : 'client')}
                className="text-muted-foreground"
              >
                <Icon name="RefreshCw" size={16} />
                Vue {userRole === 'client' ? 'Agence' : 'Client'}
              </Button>
              
              <Link to="/create-rental-demand">
                <Button variant="default">
                  <Icon name="Plus" size={16} />
                  Nouvelle demande
                </Button>
              </Link>
            </div>
          </div>

          {/* Breadcrumb */}
          <nav className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Accueil</Link>
            <Icon name="ChevronRight" size={14} />
            <span className="text-foreground">Réservations</span>
          </nav>
        </div>

        {/* Stats */}
        <div className="mb-6">
          <BookingStats stats={mockStats} userRole={userRole} />
        </div>

        {/* Filters */}
        <div className="mb-6">
          <BookingFilters
            filters={filters}
            onFiltersChange={setFilters}
            userRole={userRole}
            bookingCounts={getBookingCounts()}
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Bookings List */}
          <div className="lg:col-span-2 space-y-4">
            {filteredBookings?.length === 0 ? (
              <div className="bg-card border border-border rounded-lg p-8 text-center">
                <Icon name="Calendar" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Aucune réservation trouvée</h3>
                <p className="text-muted-foreground mb-4">
                  {filters?.search || filters?.status !== 'all' || filters?.timeRange !== 'all' ?'Aucune réservation ne correspond à vos critères de recherche.' :'Vous n\'avez pas encore de réservation.'
                  }
                </p>
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  {(filters?.search || filters?.status !== 'all' || filters?.timeRange !== 'all') && (
                    <Button
                      variant="outline"
                      onClick={() => setFilters({
                        search: '',
                        status: 'all',
                        timeRange: 'all',
                        sortBy: 'pickup_date_asc'
                      })}
                    >
                      <Icon name="RotateCcw" size={16} />
                      Effacer les filtres
                    </Button>
                  )}
                  <Link to="/create-rental-demand">
                    <Button variant="default">
                      <Icon name="Plus" size={16} />
                      Créer une demande
                    </Button>
                  </Link>
                </div>
              </div>
            ) : (
              filteredBookings?.map((booking) => (
                <BookingCard
                  key={booking?.id}
                  booking={booking}
                  userRole={userRole}
                  onStatusUpdate={handleStatusUpdate}
                  onMessageClick={handleMessageClick}
                  onViewDetails={handleViewDetails}
                  onModifyBooking={handleModifyBooking}
                  onCancelBooking={handleCancelBooking}
                />
              ))
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Payment Details */}
            {selectedBooking && showPaymentDetails && (
              <PaymentStatusCard
                booking={selectedBooking}
                onPaymentAction={handlePaymentAction}
                onViewReceipt={handleViewReceipt}
                onRequestRefund={handleRequestRefund}
              />
            )}

            {/* Emergency Support */}
            {filteredBookings?.some(b => ['confirmed', 'prepared', 'active']?.includes(b?.status)) && (
              <EmergencySupport
                booking={filteredBookings?.find(b => ['confirmed', 'prepared', 'active']?.includes(b?.status))}
                onContactSupport={handleContactSupport}
                onReportIssue={handleReportIssue}
              />
            )}

            {/* Quick Actions */}
            <div className="bg-card border border-border rounded-lg p-4 shadow-elevation-1">
              <h3 className="font-semibold text-foreground mb-3 flex items-center">
                <Icon name="Zap" size={16} className="mr-2" />
                Actions rapides
              </h3>
              <div className="space-y-2">
                <Link to="/create-rental-demand" className="block">
                  <Button variant="ghost" size="sm" fullWidth className="justify-start">
                    <Icon name="Plus" size={16} />
                    Nouvelle demande
                  </Button>
                </Link>
                <Link to="/payment-escrow-center" className="block">
                  <Button variant="ghost" size="sm" fullWidth className="justify-start">
                    <Icon name="CreditCard" size={16} />
                    Centre de paiement
                  </Button>
                </Link>
                <Link to="/live-offers-dashboard" className="block">
                  <Button variant="ghost" size="sm" fullWidth className="justify-start">
                    <Icon name="Eye" size={16} />
                    Voir les offres
                  </Button>
                </Link>
                {userRole === 'agency' && (
                  <Link to="/agency-dashboard" className="block">
                    <Button variant="ghost" size="sm" fullWidth className="justify-start">
                      <Icon name="BarChart3" size={16} />
                      Tableau de bord
                    </Button>
                  </Link>
                )}
              </div>
            </div>

            {/* Help & Support */}
            <div className="bg-card border border-border rounded-lg p-4 shadow-elevation-1">
              <h3 className="font-semibold text-foreground mb-3 flex items-center">
                <Icon name="HelpCircle" size={16} className="mr-2" />
                Aide & Support
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-2">
                  <Icon name="Phone" size={14} className="text-primary" />
                  <span className="text-muted-foreground">Support:</span>
                  <span className="font-medium text-foreground">+33 1 23 45 67 89</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="MessageCircle" size={14} className="text-success" />
                  <span className="text-muted-foreground">WhatsApp:</span>
                  <span className="font-medium text-foreground">24h/24</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Mail" size={14} className="text-secondary" />
                  <span className="text-muted-foreground">Email:</span>
                  <span className="font-medium text-foreground">support@rentmatch.fr</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingManagement;