import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CalendarOverview = ({ availabilityData, onDateClick, onBlockDate }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  const monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ];

  const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];

  const getDaysInMonth = (date) => {
    const year = date?.getFullYear();
    const month = date?.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay?.getDate();
    const startingDayOfWeek = firstDay?.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days?.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days?.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getDateStatus = (date) => {
    if (!date) return null;
    
    const dateStr = date?.toISOString()?.split('T')?.[0];
    const availability = availabilityData?.find(item => item?.date === dateStr);
    
    if (!availability) return 'available';
    
    return availability?.status; // 'available', 'booked', 'blocked', 'maintenance'
  };

  const getDateStatusColor = (status) => {
    switch (status) {
      case 'available':
        return 'bg-success/20 text-success hover:bg-success/30';
      case 'booked':
        return 'bg-primary/20 text-primary hover:bg-primary/30';
      case 'blocked':
        return 'bg-error/20 text-error hover:bg-error/30';
      case 'maintenance':
        return 'bg-warning/20 text-warning hover:bg-warning/30';
      default:
        return 'hover:bg-muted';
    }
  };

  const getAvailableVehicleCount = (date) => {
    if (!date) return 0;
    const dateStr = date?.toISOString()?.split('T')?.[0];
    const availability = availabilityData?.find(item => item?.date === dateStr);
    return availability?.availableVehicles || 0;
  };

  const navigateMonth = (direction) => {
    const newMonth = new Date(currentMonth);
    newMonth?.setMonth(currentMonth?.getMonth() + direction);
    setCurrentMonth(newMonth);
  };

  const handleDateClick = (date) => {
    if (!date) return;
    setSelectedDate(date);
    onDateClick?.(date);
  };

  const isToday = (date) => {
    if (!date) return false;
    const today = new Date();
    return date?.toDateString() === today?.toDateString();
  };

  const isPastDate = (date) => {
    if (!date) return false;
    const today = new Date();
    today?.setHours(0, 0, 0, 0);
    return date < today;
  };

  const days = getDaysInMonth(currentMonth);

  // Quick stats for the current month
  const monthStats = {
    totalDays: days?.filter(d => d)?.length,
    availableDays: days?.filter(d => d && getDateStatus(d) === 'available')?.length,
    bookedDays: days?.filter(d => d && getDateStatus(d) === 'booked')?.length,
    blockedDays: days?.filter(d => d && ['blocked', 'maintenance']?.includes(getDateStatus(d)))?.length
  };

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Calendar" size={20} className="text-primary" />
          <h3 className="font-semibold text-foreground">Disponibilités</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onBlockDate?.()}
          className="text-xs"
        >
          <Icon name="Plus" size={14} />
          Bloquer
        </Button>
      </div>
      {/* Calendar Navigation */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateMonth(-1)}
        >
          <Icon name="ChevronLeft" size={16} />
        </Button>
        <h4 className="font-medium text-foreground">
          {monthNames?.[currentMonth?.getMonth()]} {currentMonth?.getFullYear()}
        </h4>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateMonth(1)}
        >
          <Icon name="ChevronRight" size={16} />
        </Button>
      </div>
      {/* Calendar Grid */}
      <div className="p-4">
        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {dayNames?.map((day) => (
            <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-1">
          {days?.map((date, index) => {
            const status = getDateStatus(date);
            const availableCount = getAvailableVehicleCount(date);
            const isSelected = selectedDate && date && selectedDate?.toDateString() === date?.toDateString();
            
            return (
              <button
                key={index}
                onClick={() => handleDateClick(date)}
                disabled={!date || isPastDate(date)}
                className={`
                  relative aspect-square p-1 text-xs rounded-md transition-colors
                  ${date ? 'cursor-pointer' : 'cursor-default'}
                  ${isPastDate(date) ? 'opacity-40 cursor-not-allowed' : ''}
                  ${isSelected ? 'ring-2 ring-primary' : ''}
                  ${isToday(date) ? 'font-bold' : ''}
                  ${date ? getDateStatusColor(status) : ''}
                `}
              >
                {date && (
                  <>
                    <div className="text-center">{date?.getDate()}</div>
                    {status !== 'available' && availableCount > 0 && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-foreground text-background text-xs rounded-full flex items-center justify-center">
                        {availableCount}
                      </div>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </div>
      </div>
      {/* Legend */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-success/20 rounded"></div>
            <span className="text-muted-foreground">Disponible ({monthStats?.availableDays})</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary/20 rounded"></div>
            <span className="text-muted-foreground">Réservé ({monthStats?.bookedDays})</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-error/20 rounded"></div>
            <span className="text-muted-foreground">Bloqué ({monthStats?.blockedDays})</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-warning/20 rounded"></div>
            <span className="text-muted-foreground">Maintenance</span>
          </div>
        </div>
      </div>
      {/* Selected Date Info */}
      {selectedDate && (
        <div className="p-4 border-t border-border">
          <div className="text-sm">
            <p className="font-medium text-foreground mb-1">
              {selectedDate?.toLocaleDateString('fr-FR', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
            <p className="text-muted-foreground">
              {getAvailableVehicleCount(selectedDate)} véhicule(s) disponible(s)
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarOverview;