import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const EmergencySupport = ({ booking, onContactSupport, onReportIssue }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedIssueType, setSelectedIssueType] = useState('');

  const emergencyContacts = [
    {
      type: 'general',
      label: 'Support général',
      phone: '+33 1 23 45 67 89',
      available: '24h/24, 7j/7',
      icon: 'Headphones',
      color: 'text-primary'
    },
    {
      type: 'emergency',
      label: 'Urgence véhicule',
      phone: '+33 1 23 45 67 90',
      available: '24h/24',
      icon: 'AlertTriangle',
      color: 'text-error'
    },
    {
      type: 'breakdown',
      label: 'Assistance panne',
      phone: '+33 1 23 45 67 91',
      available: '24h/24',
      icon: 'Wrench',
      color: 'text-warning'
    }
  ];

  const commonIssues = [
    {
      type: 'vehicle_not_available',
      label: 'Véhicule non disponible',
      description: 'Le véhicule réservé n\'est pas disponible à l\'heure prévue',
      urgent: true
    },
    {
      type: 'vehicle_condition',
      label: 'Problème d\'état du véhicule',
      description: 'Le véhicule présente des dommages ou problèmes techniques',
      urgent: true
    },
    {
      type: 'location_issue',
      label: 'Problème de lieu de prise en charge',
      description: 'Impossible de trouver le lieu ou l\'agence',
      urgent: false
    },
    {
      type: 'payment_issue',
      label: 'Problème de paiement',
      description: 'Difficulté avec le paiement ou la facturation',
      urgent: false
    },
    {
      type: 'documentation',
      label: 'Problème de documents',
      description: 'Documents manquants ou non acceptés',
      urgent: false
    },
    {
      type: 'other',
      label: 'Autre problème',
      description: 'Un problème non listé ci-dessus',
      urgent: false
    }
  ];

  const handleQuickCall = (contact) => {
    // In a real app, this would initiate a call or open the phone app
    window.open(`tel:${contact?.phone}`);
  };

  const handleWhatsAppContact = () => {
    const message = `Bonjour, j'ai besoin d'aide pour ma réservation ${booking?.id}. Véhicule: ${booking?.vehicle?.name}, Date: ${new Date(booking.pickupDate)?.toLocaleDateString('fr-FR')}`;
    const whatsappUrl = `https://wa.me/33123456789?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleReportIssue = (issueType) => {
    setSelectedIssueType(issueType);
    if (onReportIssue) {
      onReportIssue(booking?.id, issueType);
    }
  };

  const isBookingActive = ['confirmed', 'prepared', 'active']?.includes(booking?.status);
  const isUpcoming = new Date(booking.pickupDate) > new Date();
  const hoursUntilPickup = Math.ceil((new Date(booking.pickupDate) - new Date()) / (1000 * 60 * 60));

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-error/10 rounded-lg flex items-center justify-center">
              <Icon name="LifeBuoy" size={20} className="text-error" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Support & Assistance</h3>
              <p className="text-sm text-muted-foreground">
                Aide disponible 24h/24 pour votre réservation
              </p>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
          </Button>
        </div>

        {/* Urgent Alert */}
        {isBookingActive && isUpcoming && hoursUntilPickup <= 24 && (
          <div className="mt-3 p-3 bg-warning/10 border border-warning/20 rounded-md">
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} className="text-warning" />
              <span className="text-sm font-medium text-warning">
                Prise en charge dans {hoursUntilPickup}h - Support prioritaire disponible
              </span>
            </div>
          </div>
        )}
      </div>
      {/* Quick Actions */}
      <div className="p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Button
            variant="outline"
            onClick={handleWhatsAppContact}
            className="justify-start h-auto p-3"
          >
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                <Icon name="MessageCircle" size={16} className="text-success" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground">WhatsApp</p>
                <p className="text-xs text-muted-foreground">Réponse rapide</p>
              </div>
            </div>
          </Button>

          <Button
            variant="outline"
            onClick={() => handleQuickCall(emergencyContacts?.[0])}
            className="justify-start h-auto p-3"
          >
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name="Phone" size={16} className="text-primary" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground">Appel direct</p>
                <p className="text-xs text-muted-foreground">24h/24</p>
              </div>
            </div>
          </Button>
        </div>
      </div>
      {/* Expanded Support Options */}
      {isExpanded && (
        <div className="border-t border-border animate-slide-down">
          {/* Emergency Contacts */}
          <div className="p-4 border-b border-border">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="Phone" size={16} className="mr-2" />
              Contacts d'urgence
            </h4>
            <div className="space-y-3">
              {emergencyContacts?.map((contact) => (
                <div
                  key={contact?.type}
                  className="flex items-center justify-between p-3 bg-muted/30 rounded-md"
                >
                  <div className="flex items-center space-x-3">
                    <Icon name={contact?.icon} size={16} className={contact?.color} />
                    <div>
                      <p className="font-medium text-foreground">{contact?.label}</p>
                      <p className="text-xs text-muted-foreground">{contact?.available}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleQuickCall(contact)}
                    className={`${contact?.color} hover:bg-current/10`}
                  >
                    <Icon name="Phone" size={14} />
                    {contact?.phone}
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Common Issues */}
          <div className="p-4 border-b border-border">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="AlertCircle" size={16} className="mr-2" />
              Signaler un problème
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {commonIssues?.map((issue) => (
                <button
                  key={issue?.type}
                  onClick={() => handleReportIssue(issue?.type)}
                  className={`p-3 text-left rounded-md border transition-colors hover:bg-muted/50 ${
                    issue?.urgent 
                      ? 'border-error/20 bg-error/5 hover:bg-error/10' :'border-border bg-background hover:bg-muted/30'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className={`font-medium text-sm ${
                        issue?.urgent ? 'text-error' : 'text-foreground'
                      }`}>
                        {issue?.label}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {issue?.description}
                      </p>
                    </div>
                    {issue?.urgent && (
                      <Icon name="AlertTriangle" size={14} className="text-error ml-2 flex-shrink-0" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* FAQ Quick Links */}
          <div className="p-4">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="HelpCircle" size={16} className="mr-2" />
              Aide rapide
            </h4>
            <div className="space-y-2">
              {[
                { label: 'Comment modifier ma réservation ?', link: '/help/modify-booking' },
                { label: 'Que faire en cas de panne ?', link: '/help/breakdown' },
                { label: 'Politique d\'annulation', link: '/help/cancellation' },
                { label: 'Documents requis', link: '/help/documents' }
              ]?.map((faq, index) => (
                <button
                  key={index}
                  className="w-full text-left p-2 text-sm text-primary hover:bg-primary/10 rounded-md transition-colors"
                >
                  {faq?.label}
                  <Icon name="ExternalLink" size={12} className="inline ml-1" />
                </button>
              ))}
            </div>
          </div>

          {/* Emergency Information */}
          <div className="p-4 bg-error/5 border-t border-error/20">
            <div className="flex items-start space-x-2">
              <Icon name="AlertTriangle" size={16} className="text-error mt-0.5" />
              <div>
                <p className="text-sm font-medium text-error">En cas d'urgence</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Pour les urgences médicales ou de sécurité, contactez immédiatement les services d'urgence (15, 17, 18) 
                  avant de nous contacter.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmergencySupport;