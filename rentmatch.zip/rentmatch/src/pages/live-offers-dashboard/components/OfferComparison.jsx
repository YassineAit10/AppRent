import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const OfferComparison = ({ 
  comparedOffers = [], 
  onRemoveFromComparison, 
  onAcceptOffer,
  onClose 
}) => {
  if (comparedOffers?.length === 0) {
    return null;
  }

  const getComparisonValue = (offer, field) => {
    switch (field) {
      case 'price':
        return offer?.pricing?.dailyRate;
      case 'rating':
        return offer?.agency?.rating;
      case 'distance':
        return offer?.agency?.distance;
      case 'reliability':
        return offer?.agency?.reliabilityScore;
      default:
        return 0;
    }
  };

  const getBestValue = (field) => {
    const values = comparedOffers?.map(offer => getComparisonValue(offer, field));
    switch (field) {
      case 'price': case'distance':
        return Math.min(...values);
      case 'rating': case'reliability':
        return Math.max(...values);
      default:
        return values?.[0];
    }
  };

  const isBestValue = (offer, field) => {
    return getComparisonValue(offer, field) === getBestValue(field);
  };

  const comparisonFields = [
    { key: 'price', label: 'Prix/jour', format: (value) => `${value}€` },
    { key: 'rating', label: 'Note', format: (value) => `${value}/5` },
    { key: 'distance', label: 'Distance', format: (value) => `${value}km` },
    { key: 'reliability', label: 'Fiabilité', format: (value) => `${value}%` }
  ];

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-modal flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-lg shadow-elevation-4 w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-2">
            <Icon name="BarChart3" size={20} className="text-primary" />
            <h2 className="text-lg font-semibold text-foreground">
              Comparaison des offres
            </h2>
            <span className="px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
              {comparedOffers?.length} offre{comparedOffers?.length > 1 ? 's' : ''}
            </span>
          </div>
          
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Comparison Content */}
        <div className="overflow-x-auto">
          <div className="min-w-full">
            {/* Offers Header */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border-b border-border">
              {comparedOffers?.map((offer) => (
                <div key={offer?.id} className="relative">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">{offer?.agency?.name}</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveFromComparison(offer?.id)}
                    >
                      <Icon name="X" size={14} />
                    </Button>
                  </div>
                  
                  {/* Vehicle Image */}
                  <div className="w-full h-32 rounded-md overflow-hidden mb-3">
                    <Image
                      src={offer?.vehicle?.images?.[0]}
                      alt={`${offer?.vehicle?.brand} ${offer?.vehicle?.model}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <p className="text-sm font-medium text-foreground">
                    {offer?.vehicle?.brand} {offer?.vehicle?.model}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {offer?.vehicle?.year} • {offer?.vehicle?.transmission}
                  </p>
                </div>
              ))}
            </div>

            {/* Comparison Metrics */}
            <div className="p-4 space-y-4">
              {comparisonFields?.map((field) => (
                <div key={field?.key} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-3 mb-2">
                    <h4 className="text-sm font-medium text-foreground">{field?.label}</h4>
                  </div>
                  
                  {comparedOffers?.map((offer) => {
                    const value = getComparisonValue(offer, field?.key);
                    const isBest = isBestValue(offer, field?.key);
                    
                    return (
                      <div
                        key={offer?.id}
                        className={`p-3 rounded-md border ${
                          isBest 
                            ? 'border-success bg-success/5 ring-1 ring-success/20' :'border-border bg-muted/30'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`font-medium ${
                            isBest ? 'text-success' : 'text-foreground'
                          }`}>
                            {field?.format(value)}
                          </span>
                          {isBest && (
                            <Icon name="Crown" size={16} className="text-success" />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}

              {/* Features Comparison */}
              <div className="pt-4 border-t border-border">
                <h4 className="text-sm font-medium text-foreground mb-3">Fonctionnalités incluses</h4>
                
                {/* Get all unique features */}
                {Array.from(new Set(comparedOffers.flatMap(offer => offer.features)))?.map((feature) => (
                  <div key={feature} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-2">
                    <div className="md:col-span-3 mb-1">
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </div>
                    
                    {comparedOffers?.map((offer) => (
                      <div key={offer?.id} className="flex items-center justify-center p-2">
                        {offer?.features?.includes(feature) ? (
                          <Icon name="Check" size={16} className="text-success" />
                        ) : (
                          <Icon name="X" size={16} className="text-error" />
                        )}
                      </div>
                    ))}
                  </div>
                ))}
              </div>

              {/* Total Cost Comparison */}
              <div className="pt-4 border-t border-border">
                <h4 className="text-sm font-medium text-foreground mb-3">Coût total</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {comparedOffers?.map((offer) => {
                    const isBestPrice = isBestValue(offer, 'price');
                    
                    return (
                      <div
                        key={offer?.id}
                        className={`p-4 rounded-lg border ${
                          isBestPrice 
                            ? 'border-success bg-success/5' :'border-border bg-muted/30'
                        }`}
                      >
                        <div className="text-center">
                          <p className={`text-2xl font-bold ${
                            isBestPrice ? 'text-success' : 'text-foreground'
                          }`}>
                            {offer?.pricing?.totalAmount}€
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {offer?.pricing?.duration} jours
                          </p>
                          {isBestPrice && (
                            <p className="text-xs text-success font-medium mt-1">
                              Meilleur prix
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="p-4 border-t border-border bg-muted/30">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {comparedOffers?.map((offer) => (
                  <div key={offer?.id} className="space-y-2">
                    <Button
                      variant="default"
                      fullWidth
                      onClick={() => onAcceptOffer(offer, 'escrow')}
                    >
                      <Icon name="Shield" size={16} />
                      <span className="ml-2">Séquestre</span>
                    </Button>
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={() => onAcceptOffer(offer, 'location')}
                    >
                      <Icon name="MapPin" size={16} />
                      <span className="ml-2">Sur place</span>
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfferComparison;