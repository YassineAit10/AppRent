import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const VehicleCategorySelector = ({ 
  selectedCategories = [], 
  onCategoryChange,
  error 
}) => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'

  const vehicleCategories = [
    {
      id: 'economy',
      name: 'Économique',
      description: 'Véhicules compacts et économiques',
      icon: 'Car',
      image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['Renault Clio', 'Peugeot 208', 'Citroën C3'],
      features: ['5 places', 'Climatisation', 'Direction assistée'],
      priceRange: '25-45€/jour',
      popular: true,
      color: 'success'
    },
    {
      id: 'compact',
      name: 'Compacte',
      description: 'Parfait équilibre confort/économie',
      icon: 'Car',
      image: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['Volkswagen Golf', 'Ford Focus', 'Opel Astra'],
      features: ['5 places', 'Coffre spacieux', 'Bluetooth'],
      priceRange: '35-55€/jour',
      popular: true,
      color: 'primary'
    },
    {
      id: 'intermediate',
      name: 'Intermédiaire',
      description: 'Confort et espace supplémentaires',
      icon: 'Car',
      image: 'https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['BMW Série 3', 'Audi A4', 'Mercedes Classe C'],
      features: ['5 places', 'GPS intégré', 'Sièges cuir'],
      priceRange: '55-85€/jour',
      popular: false,
      color: 'secondary'
    },
    {
      id: 'luxury',
      name: 'Luxe',
      description: 'Véhicules haut de gamme',
      icon: 'Crown',
      image: 'https://images.pexels.com/photos/3802508/pexels-photo-3802508.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['BMW Série 5', 'Mercedes Classe E', 'Audi A6'],
      features: ['Cuir premium', 'Navigation', 'Système audio'],
      priceRange: '85-150€/jour',
      popular: false,
      color: 'warning'
    },
    {
      id: 'suv',
      name: 'SUV',
      description: 'Véhicules tout-terrain spacieux',
      icon: 'Truck',
      image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['Peugeot 3008', 'Nissan Qashqai', 'BMW X3'],
      features: ['7 places', '4x4', 'Coffre XXL'],
      priceRange: '65-120€/jour',
      popular: true,
      color: 'accent'
    },
    {
      id: 'van',
      name: 'Utilitaire',
      description: 'Fourgons et véhicules utilitaires',
      icon: 'Truck',
      image: 'https://images.pexels.com/photos/1335077/pexels-photo-1335077.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['Renault Master', 'Ford Transit', 'Mercedes Sprinter'],
      features: ['Volume cargo', 'Hayon', 'Sangles'],
      priceRange: '45-90€/jour',
      popular: false,
      color: 'secondary'
    },
    {
      id: 'convertible',
      name: 'Cabriolet',
      description: 'Véhicules décapotables',
      icon: 'Sun',
      image: 'https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['BMW Z4', 'Audi TT', 'Mercedes SLK'],
      features: ['Toit ouvrant', 'Sport', '2-4 places'],
      priceRange: '75-180€/jour',
      popular: false,
      color: 'warning'
    },
    {
      id: 'electric',
      name: 'Électrique',
      description: 'Véhicules 100% électriques',
      icon: 'Zap',
      image: 'https://images.pexels.com/photos/110844/pexels-photo-110844.jpeg?auto=compress&cs=tinysrgb&w=400',
      examples: ['Tesla Model 3', 'Renault Zoe', 'Nissan Leaf'],
      features: ['0 émission', 'Silencieux', 'Recharge rapide'],
      priceRange: '55-120€/jour',
      popular: true,
      color: 'success'
    }
  ];

  const handleCategoryToggle = (categoryId) => {
    const isSelected = selectedCategories?.includes(categoryId);
    let newSelection;
    
    if (isSelected) {
      newSelection = selectedCategories?.filter(id => id !== categoryId);
    } else {
      newSelection = [...selectedCategories, categoryId];
    }
    
    onCategoryChange(newSelection);
  };

  const getColorClasses = (color, isSelected) => {
    const colorMap = {
      primary: isSelected ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50',
      success: isSelected ? 'border-success bg-success/10 text-success' : 'border-border hover:border-success/50',
      warning: isSelected ? 'border-warning bg-warning/10 text-warning' : 'border-border hover:border-warning/50',
      secondary: isSelected ? 'border-secondary bg-secondary/10 text-secondary' : 'border-border hover:border-secondary/50',
      accent: isSelected ? 'border-accent bg-accent/10 text-accent' : 'border-border hover:border-accent/50'
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  const popularCategories = vehicleCategories?.filter(cat => cat?.popular);

  return (
    <div className="space-y-6">
      {/* Header with View Toggle */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Type de véhicule</h3>
          <p className="text-sm text-muted-foreground">
            Sélectionnez une ou plusieurs catégories
          </p>
        </div>
        
        <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md transition-colors ${
              viewMode === 'grid' ? 'bg-background shadow-sm' : 'hover:bg-background/50'
            }`}
          >
            <Icon name="Grid3X3" size={16} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-md transition-colors ${
              viewMode === 'list' ? 'bg-background shadow-sm' : 'hover:bg-background/50'
            }`}
          >
            <Icon name="List" size={16} />
          </button>
        </div>
      </div>
      {/* Error Message */}
      {error && (
        <div className="text-sm text-error bg-error/10 border border-error/20 rounded-md p-3">
          {error}
        </div>
      )}
      {/* Popular Categories Quick Select */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground flex items-center">
          <Icon name="Star" size={16} className="mr-2 text-warning" />
          Catégories populaires
        </h4>
        <div className="flex flex-wrap gap-2">
          {popularCategories?.map((category) => {
            const isSelected = selectedCategories?.includes(category?.id);
            return (
              <button
                key={category?.id}
                onClick={() => handleCategoryToggle(category?.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg border transition-all ${
                  getColorClasses(category?.color, isSelected)
                }`}
              >
                <Icon name={category?.icon} size={16} />
                <span className="text-sm font-medium">{category?.name}</span>
                {isSelected && <Icon name="Check" size={14} />}
              </button>
            );
          })}
        </div>
      </div>
      {/* All Categories */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground">Toutes les catégories</h4>
        
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {vehicleCategories?.map((category) => {
              const isSelected = selectedCategories?.includes(category?.id);
              return (
                <div
                  key={category?.id}
                  onClick={() => handleCategoryToggle(category?.id)}
                  className={`relative cursor-pointer rounded-lg border-2 transition-all hover:shadow-md ${
                    getColorClasses(category?.color, isSelected)
                  }`}
                >
                  {/* Image */}
                  <div className="aspect-video rounded-t-lg overflow-hidden">
                    <Image
                      src={category?.image}
                      alt={category?.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {/* Content */}
                  <div className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Icon name={category?.icon} size={20} />
                        <h5 className="font-semibold">{category?.name}</h5>
                      </div>
                      {isSelected && (
                        <div className="w-6 h-6 rounded-full bg-current flex items-center justify-center">
                          <Icon name="Check" size={14} color="white" />
                        </div>
                      )}
                    </div>
                    
                    <p className="text-sm text-muted-foreground">
                      {category?.description}
                    </p>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">Prix indicatif</span>
                        <span className="text-muted-foreground">{category?.priceRange}</span>
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {category?.features?.slice(0, 2)?.map((feature) => (
                          <span
                            key={feature}
                            className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md"
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  {category?.popular && (
                    <div className="absolute top-2 right-2 bg-warning text-warning-foreground px-2 py-1 rounded-full text-xs font-medium">
                      Populaire
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-2">
            {vehicleCategories?.map((category) => {
              const isSelected = selectedCategories?.includes(category?.id);
              return (
                <div
                  key={category?.id}
                  onClick={() => handleCategoryToggle(category?.id)}
                  className={`flex items-center space-x-4 p-4 rounded-lg border cursor-pointer transition-all ${
                    getColorClasses(category?.color, isSelected)
                  }`}
                >
                  <div className="w-16 h-12 rounded-md overflow-hidden flex-shrink-0">
                    <Image
                      src={category?.image}
                      alt={category?.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <Icon name={category?.icon} size={16} />
                      <h5 className="font-semibold">{category?.name}</h5>
                      {category?.popular && (
                        <span className="px-2 py-0.5 bg-warning/20 text-warning text-xs rounded-full">
                          Populaire
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {category?.description}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{category?.priceRange}</span>
                      <div className="flex space-x-2">
                        {category?.features?.slice(0, 3)?.map((feature) => (
                          <span
                            key={feature}
                            className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md"
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex-shrink-0">
                    {isSelected ? (
                      <div className="w-6 h-6 rounded-full bg-current flex items-center justify-center">
                        <Icon name="Check" size={14} color="white" />
                      </div>
                    ) : (
                      <div className="w-6 h-6 rounded-full border-2 border-muted"></div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {/* Selection Summary */}
      {selectedCategories?.length > 0 && (
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="CheckCircle" size={16} className="text-primary" />
              <span className="text-sm font-medium text-primary">
                {selectedCategories?.length} catégorie{selectedCategories?.length > 1 ? 's' : ''} sélectionnée{selectedCategories?.length > 1 ? 's' : ''}
              </span>
            </div>
            <button
              onClick={() => onCategoryChange([])}
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              Tout désélectionner
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default VehicleCategorySelector;