import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Header from '../../components/ui/Header';
import EscrowTransactionCard from './components/EscrowTransactionCard';
import PaymentMethodCard from './components/PaymentMethodCard';
import RefundRequestCard from './components/RefundRequestCard';
import FinancialSummaryCard from './components/FinancialSummaryCard';
import AddPaymentMethodModal from './components/AddPaymentMethodModal';

const PaymentEscrowCenter = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [isAddPaymentModalOpen, setIsAddPaymentModalOpen] = useState(false);
  const [currentBalance, setCurrentBalance] = useState(2450.75);

  // Mock data for escrow transactions
  const mockEscrowTransactions = [
    {
      id: 'ESC001',
      bookingReference: 'BK2024001',
      status: 'active',
      totalAmount: 850.00,
      depositAmount: 200.00,
      baseAmount: 650.00,
      optionsAmount: 120.00,
      taxAmount: 65.00,
      serviceAmount: 15.00,
      vehicleType: 'Citroën C3',
      location: 'Paris 15ème',
      agencyName: 'AutoRent Pro',
      paymentMethod: 'Visa •••• 4532',
      startDate: '2024-08-20T10:00:00Z',
      endDate: '2024-08-25T18:00:00Z',
      createdAt: '2024-08-16T08:30:00Z',
      releaseDate: null,
      releaseConditions: [
        'Confirmation de prise en charge par l\'agence',
        'Vérification de l\'état du véhicule',
        'Validation des documents de location'
      ],
      timeline: [
        { label: 'Paiement reçu', completed: true, date: '2024-08-16T08:30:00Z' },
        { label: 'Fonds sécurisés', completed: true, date: '2024-08-16T08:31:00Z' },
        { label: 'Confirmation agence', completed: false, date: null },
        { label: 'Libération des fonds', completed: false, date: null }
      ]
    },
    {
      id: 'ESC002',
      bookingReference: 'BK2024002',
      status: 'released',
      totalAmount: 1200.00,
      depositAmount: 300.00,
      baseAmount: 900.00,
      optionsAmount: 200.00,
      taxAmount: 85.00,
      serviceAmount: 15.00,
      vehicleType: 'Peugeot 308',
      location: 'Lyon Centre',
      agencyName: 'Lyon Mobility',
      paymentMethod: 'Mastercard •••• 8765',
      startDate: '2024-08-10T09:00:00Z',
      endDate: '2024-08-15T17:00:00Z',
      createdAt: '2024-08-08T14:20:00Z',
      releaseDate: '2024-08-15T18:30:00Z',
      releaseConditions: [],
      timeline: [
        { label: 'Paiement reçu', completed: true, date: '2024-08-08T14:20:00Z' },
        { label: 'Fonds sécurisés', completed: true, date: '2024-08-08T14:21:00Z' },
        { label: 'Confirmation agence', completed: true, date: '2024-08-10T08:45:00Z' },
        { label: 'Libération des fonds', completed: true, date: '2024-08-15T18:30:00Z' }
      ]
    }
  ];

  // Mock data for payment methods
  const mockPaymentMethods = [
    {
      id: 'PM001',
      type: 'card',
      brand: 'Visa',
      number: '4532123456789012',
      expiryMonth: 12,
      expiryYear: 2027,
      holderName: 'Jean Dupont',
      cardType: 'Crédit',
      country: 'France',
      verified: true,
      addedAt: '2024-01-15T10:00:00Z',
      usageCount: 12,
      recentTransactions: [
        { reference: 'BK2024001', amount: 850.00, date: '2024-08-16T08:30:00Z' },
        { reference: 'BK2024002', amount: 1200.00, date: '2024-08-08T14:20:00Z' }
      ]
    },
    {
      id: 'PM002',
      type: 'bank',
      name: 'Compte Courant',
      description: 'Banque Populaire',
      iban: 'FR1420041010050500013M02606',
      bankName: 'Banque Populaire',
      verified: true,
      addedAt: '2024-02-20T15:30:00Z',
      usageCount: 5,
      recentTransactions: []
    }
  ];

  // Mock data for refund requests
  const mockRefundRequests = [
    {
      requestId: 'REF001',
      bookingReference: 'BK2024003',
      status: 'pending',
      amount: 450.00,
      originalAmount: 500.00,
      feesRetained: 50.00,
      reason: 'Annulation agence',
      description: 'L\'agence a annulé la réservation en raison d\'un problème technique sur le véhicule.',
      paymentMethod: 'card',
      requestedAt: '2024-08-15T16:45:00Z',
      processedBy: null,
      canUploadDocuments: true,
      documents: [],
      timeline: [
        { label: 'Demande soumise', completed: true, date: '2024-08-15T16:45:00Z' },
        { label: 'Vérification en cours', completed: false, date: null },
        { label: 'Approbation', completed: false, date: null },
        { label: 'Remboursement', completed: false, date: null }
      ]
    }
  ];

  // Mock financial summary data
  const mockFinancialSummary = {
    month: {
      totalBalance: 2450.75,
      balanceChange: 12.5,
      escrowHoldings: 850.00,
      activeEscrows: 1,
      totalSpent: 3200.00,
      spentChange: -8.2,
      totalRefunds: 450.00,
      refundCount: 1,
      paymentMethodsUsage: [
        { name: 'Visa •••• 4532', amount: 2050.00, percentage: 64, count: 8, color: '#1E40AF' },
        { name: 'Mastercard •••• 8765', amount: 1200.00, percentage: 36, count: 4, color: '#DC2626' }
      ],
      recentActivity: [
        {
          type: 'escrow',
          description: 'Fonds sécurisés - Réservation #BK2024001',
          amount: 850.00,
          date: '2024-08-16T08:30:00Z'
        },
        {
          type: 'payment',
          description: 'Paiement - Citroën C3',
          amount: 850.00,
          date: '2024-08-16T08:30:00Z'
        },
        {
          type: 'refund',
          description: 'Remboursement approuvé - #REF001',
          amount: 450.00,
          date: '2024-08-15T16:45:00Z'
        }
      ]
    }
  };

  const tabs = [
    { key: 'overview', label: 'Vue d\'ensemble', icon: 'BarChart3', count: null },
    { key: 'escrow', label: 'Séquestre', icon: 'Shield', count: mockEscrowTransactions?.filter(t => t?.status === 'active')?.length },
    { key: 'transactions', label: 'Transactions', icon: 'CreditCard', count: mockEscrowTransactions?.length },
    { key: 'methods', label: 'Méthodes', icon: 'Wallet', count: mockPaymentMethods?.length },
    { key: 'refunds', label: 'Remboursements', icon: 'RotateCcw', count: mockRefundRequests?.length }
  ];

  const statusOptions = [
    { value: 'all', label: 'Tous les statuts' },
    { value: 'active', label: 'Actifs' },
    { value: 'pending', label: 'En attente' },
    { value: 'released', label: 'Libérés' },
    { value: 'refunded', label: 'Remboursés' }
  ];

  const filteredTransactions = mockEscrowTransactions?.filter(transaction => {
    const matchesSearch = transaction?.bookingReference?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         transaction?.vehicleType?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         transaction?.agencyName?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesStatus = filterStatus === 'all' || transaction?.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleAddPaymentMethod = (paymentMethod) => {
    console.log('Adding payment method:', paymentMethod);
    // Here you would typically update the payment methods list
  };

  const handleExportReport = (period) => {
    console.log('Exporting report for period:', period);
    // Here you would typically trigger a report export
  };

  const handleViewTransactions = (type) => {
    console.log('Viewing transactions of type:', type);
    // Here you would typically navigate to a detailed transactions view
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        userRole="client" 
        notificationCount={3}
        hasActiveBooking={true}
      />
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Page Header */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
            <Link to="/" className="hover:text-foreground">Accueil</Link>
            <Icon name="ChevronRight" size={16} />
            <span className="text-foreground">Centre de paiement</span>
          </div>
          
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Centre de paiement & séquestre</h1>
              <p className="text-muted-foreground">
                Gérez vos transactions, méthodes de paiement et remboursements en toute sécurité
              </p>
            </div>
            
            {/* Balance Display */}
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-1">
                <Icon name="Wallet" size={20} className="text-primary" />
                <span className="text-sm font-medium text-primary">SOLDE DISPONIBLE</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                {new Intl.NumberFormat('fr-FR', {
                  style: 'currency',
                  currency: 'EUR'
                })?.format(currentBalance)}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-border mb-6">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs?.map((tab) => (
              <button
                key={tab?.key}
                onClick={() => setActiveTab(tab?.key)}
                className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium rounded-t-lg transition-colors whitespace-nowrap ${
                  activeTab === tab?.key
                    ? 'bg-primary text-primary-foreground border-b-2 border-primary'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon name={tab?.icon} size={16} />
                <span>{tab?.label}</span>
                {tab?.count !== null && tab?.count > 0 && (
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    activeTab === tab?.key
                      ? 'bg-primary-foreground text-primary'
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    {tab?.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <FinancialSummaryCard
              summary={mockFinancialSummary}
              onExportReport={handleExportReport}
              onViewTransactions={handleViewTransactions}
            />

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                onClick={() => setActiveTab('escrow')}
              >
                <Icon name="Shield" size={24} className="text-primary" />
                <span>Séquestres actifs</span>
              </Button>
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                onClick={() => setIsAddPaymentModalOpen(true)}
              >
                <Icon name="Plus" size={24} className="text-success" />
                <span>Ajouter méthode</span>
              </Button>
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                onClick={() => setActiveTab('refunds')}
              >
                <Icon name="RotateCcw" size={24} className="text-warning" />
                <span>Demander remboursement</span>
              </Button>
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                onClick={() => handleExportReport('month')}
              >
                <Icon name="Download" size={24} className="text-secondary" />
                <span>Exporter rapport</span>
              </Button>
            </div>

            {/* Recent Transactions Preview */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-foreground">Transactions récentes</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setActiveTab('transactions')}
                >
                  Voir tout
                  <Icon name="ArrowRight" size={16} className="ml-1" />
                </Button>
              </div>
              <div className="space-y-4">
                {mockEscrowTransactions?.slice(0, 2)?.map((transaction) => (
                  <EscrowTransactionCard
                    key={transaction?.id}
                    transaction={transaction}
                    onViewDetails={(id) => console.log('View details:', id)}
                    onDispute={(id) => console.log('Dispute:', id)}
                    onDownloadReceipt={(id) => console.log('Download receipt:', id)}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Escrow Tab */}
        {activeTab === 'escrow' && (
          <div className="space-y-6">
            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <Input
                  type="search"
                  placeholder="Rechercher par référence, véhicule ou agence..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e?.target?.value)}
                />
              </div>
              <Select
                options={statusOptions}
                value={filterStatus}
                onChange={setFilterStatus}
                className="sm:w-48"
              />
            </div>

            {/* Active Escrow Summary */}
            <div className="bg-warning/5 border border-warning/20 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Icon name="Shield" size={24} className="text-warning" />
                  <div>
                    <h3 className="font-semibold text-foreground">Fonds en séquestre</h3>
                    <p className="text-sm text-muted-foreground">
                      {mockEscrowTransactions?.filter(t => t?.status === 'active')?.length} transaction(s) active(s)
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-foreground">
                    {new Intl.NumberFormat('fr-FR', {
                      style: 'currency',
                      currency: 'EUR'
                    })?.format(
                      mockEscrowTransactions?.filter(t => t?.status === 'active')?.reduce((sum, t) => sum + t?.totalAmount, 0)
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">Total sécurisé</p>
                </div>
              </div>
            </div>

            {/* Transactions List */}
            <div className="space-y-4">
              {filteredTransactions?.length === 0 ? (
                <div className="text-center py-12">
                  <Icon name="Shield" size={48} className="text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Aucune transaction trouvée
                  </h3>
                  <p className="text-muted-foreground">
                    {searchTerm || filterStatus !== 'all' ?'Essayez de modifier vos filtres de recherche' :'Vos transactions en séquestre apparaîtront ici'
                    }
                  </p>
                </div>
              ) : (
                filteredTransactions?.map((transaction) => (
                  <EscrowTransactionCard
                    key={transaction?.id}
                    transaction={transaction}
                    onViewDetails={(id) => console.log('View details:', id)}
                    onDispute={(id) => console.log('Dispute:', id)}
                    onDownloadReceipt={(id) => console.log('Download receipt:', id)}
                  />
                ))
              )}
            </div>
          </div>
        )}

        {/* Transactions Tab */}
        {activeTab === 'transactions' && (
          <div className="space-y-6">
            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <Input
                  type="search"
                  placeholder="Rechercher par référence, véhicule ou agence..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e?.target?.value)}
                />
              </div>
              <Select
                options={statusOptions}
                value={filterStatus}
                onChange={setFilterStatus}
                className="sm:w-48"
              />
            </div>

            {/* Transactions List */}
            <div className="space-y-4">
              {filteredTransactions?.map((transaction) => (
                <EscrowTransactionCard
                  key={transaction?.id}
                  transaction={transaction}
                  onViewDetails={(id) => console.log('View details:', id)}
                  onDispute={(id) => console.log('Dispute:', id)}
                  onDownloadReceipt={(id) => console.log('Download receipt:', id)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Payment Methods Tab */}
        {activeTab === 'methods' && (
          <div className="space-y-6">
            {/* Header Actions */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-foreground">Méthodes de paiement</h2>
                <p className="text-sm text-muted-foreground">
                  Gérez vos cartes bancaires et comptes de paiement
                </p>
              </div>
              <Button
                variant="default"
                onClick={() => setIsAddPaymentModalOpen(true)}
              >
                <Icon name="Plus" size={16} className="mr-2" />
                Ajouter une méthode
              </Button>
            </div>

            {/* Payment Methods List */}
            <div className="space-y-4">
              {mockPaymentMethods?.map((method, index) => (
                <PaymentMethodCard
                  key={method?.id}
                  paymentMethod={method}
                  isDefault={index === 0}
                  onSetDefault={(id) => console.log('Set default:', id)}
                  onEdit={(id) => console.log('Edit:', id)}
                  onDelete={(id) => console.log('Delete:', id)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Refunds Tab */}
        {activeTab === 'refunds' && (
          <div className="space-y-6">
            {/* Header Actions */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-foreground">Demandes de remboursement</h2>
                <p className="text-sm text-muted-foreground">
                  Suivez vos demandes de remboursement et leur statut
                </p>
              </div>
              <Button variant="default">
                <Icon name="Plus" size={16} className="mr-2" />
                Nouvelle demande
              </Button>
            </div>

            {/* Refunds List */}
            <div className="space-y-4">
              {mockRefundRequests?.map((refund) => (
                <RefundRequestCard
                  key={refund?.requestId}
                  refund={refund}
                  onViewDetails={(id) => console.log('View refund details:', id)}
                  onCancelRequest={(id) => console.log('Cancel refund:', id)}
                  onUploadDocument={(id) => console.log('Upload document:', id)}
                />
              ))}
            </div>
          </div>
        )}
      </div>
      {/* Add Payment Method Modal */}
      <AddPaymentMethodModal
        isOpen={isAddPaymentModalOpen}
        onClose={() => setIsAddPaymentModalOpen(false)}
        onAdd={handleAddPaymentMethod}
      />
    </div>
  );
};

export default PaymentEscrowCenter;