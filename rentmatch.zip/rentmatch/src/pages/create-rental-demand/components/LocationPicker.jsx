import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const LocationPicker = ({ 
  selectedLocation, 
  onLocationChange, 
  error,
  showMap = true 
}) => {
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searchQuery, setSearchQuery] = useState(selectedLocation?.address || '');
  const searchRef = useRef(null);

  const mockLocations = [
    {
      id: 1,
      address: "Aéroport Charles de Gaulle, Roissy-en-France",
      city: "Paris",
      type: "Aéroport",
      lat: 49.0097,
      lng: 2.5479,
      popular: true
    },
    {
      id: 2,
      address: "Gare du Nord, Paris",
      city: "Paris", 
      type: "Gare",
      lat: 48.8809,
      lng: 2.3553,
      popular: true
    },
    {
      id: 3,
      address: "Centre-ville Lyon",
      city: "Lyon",
      type: "Centre-ville",
      lat: 45.7640,
      lng: 4.8357,
      popular: false
    },
    {
      id: 4,
      address: "Aéroport Nice Côte d\'Azur",
      city: "Nice",
      type: "Aéroport", 
      lat: 43.6584,
      lng: 7.2159,
      popular: true
    },
    {
      id: 5,
      address: "Gare de Marseille Saint-Charles",
      city: "Marseille",
      type: "Gare",
      lat: 43.3032,
      lng: 5.3811,
      popular: false
    }
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef?.current && !searchRef?.current?.contains(event?.target)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (query) => {
    setSearchQuery(query);
    setIsSearching(true);
    
    // Simulate API search
    setTimeout(() => {
      const filtered = mockLocations?.filter(location =>
        location?.address?.toLowerCase()?.includes(query?.toLowerCase()) ||
        location?.city?.toLowerCase()?.includes(query?.toLowerCase())
      );
      setSearchResults(filtered);
      setShowSuggestions(query?.length > 0);
      setIsSearching(false);
    }, 300);
  };

  const handleLocationSelect = (location) => {
    setSearchQuery(location?.address);
    setShowSuggestions(false);
    onLocationChange(location);
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation?.getCurrentPosition(
        (position) => {
          const location = {
            id: 'current',
            address: "Position actuelle",
            lat: position?.coords?.latitude,
            lng: position?.coords?.longitude,
            type: "GPS"
          };
          handleLocationSelect(location);
        },
        (error) => {
          console.error('Erreur de géolocalisation:', error);
        }
      );
    }
  };

  const popularLocations = mockLocations?.filter(loc => loc?.popular);

  return (
    <div className="space-y-4">
      {/* Search Input */}
      <div className="relative" ref={searchRef}>
        <Input
          label="Lieu de prise en charge"
          placeholder="Rechercher une adresse, aéroport, gare..."
          value={searchQuery}
          onChange={(e) => handleSearch(e?.target?.value)}
          error={error}
          required
          className="pr-20"
        />
        
        {/* Current Location Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={getCurrentLocation}
          className="absolute right-2 top-8 h-8 px-2"
          title="Utiliser ma position actuelle"
        >
          <Icon name="MapPin" size={16} />
        </Button>

        {/* Search Results Dropdown */}
        {showSuggestions && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-popover border border-border rounded-lg shadow-elevation-3 z-dropdown max-h-64 overflow-y-auto">
            {isSearching ? (
              <div className="p-4 text-center">
                <Icon name="Loader2" size={20} className="animate-spin mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Recherche en cours...</p>
              </div>
            ) : searchResults?.length > 0 ? (
              <div className="py-2">
                {searchResults?.map((location) => (
                  <button
                    key={location?.id}
                    onClick={() => handleLocationSelect(location)}
                    className="w-full flex items-center space-x-3 px-4 py-3 hover:bg-muted transition-colors text-left"
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      location?.type === 'Aéroport' ? 'bg-primary/10 text-primary' :
                      location?.type === 'Gare'? 'bg-success/10 text-success' : 'bg-secondary/10 text-secondary'
                    }`}>
                      <Icon 
                        name={
                          location?.type === 'Aéroport' ? 'Plane' :
                          location?.type === 'Gare'? 'Train' : 'MapPin'
                        } 
                        size={16} 
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {location?.address}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {location?.type} • {location?.city}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center">
                <Icon name="Search" size={20} className="mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Aucun résultat trouvé</p>
              </div>
            )}
          </div>
        )}
      </div>
      {/* Popular Locations */}
      {!showSuggestions && searchQuery?.length === 0 && (
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground flex items-center">
            <Icon name="Star" size={16} className="mr-2 text-warning" />
            Lieux populaires
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {popularLocations?.map((location) => (
              <button
                key={location?.id}
                onClick={() => handleLocationSelect(location)}
                className="flex items-center space-x-3 p-3 border border-border rounded-lg hover:bg-muted transition-colors text-left"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  location?.type === 'Aéroport' ? 'bg-primary/10 text-primary' : 'bg-success/10 text-success'
                }`}>
                  <Icon 
                    name={location?.type === 'Aéroport' ? 'Plane' : 'Train'} 
                    size={16} 
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {location?.address}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {location?.type}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Map Preview */}
      {showMap && selectedLocation && (
        <div className="h-48 rounded-lg overflow-hidden border border-border">
          <iframe
            width="100%"
            height="100%"
            loading="lazy"
            title={selectedLocation?.address}
            referrerPolicy="no-referrer-when-downgrade"
            src={`https://www.google.com/maps?q=${selectedLocation?.lat},${selectedLocation?.lng}&z=14&output=embed`}
            className="w-full h-full"
          />
        </div>
      )}
    </div>
  );
};

export default LocationPicker;