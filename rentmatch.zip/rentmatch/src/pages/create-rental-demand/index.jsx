import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Header from '../../components/ui/Header';

// Import all components
import LocationPicker from './components/LocationPicker';
import DateTimeSelector from './components/DateTimeSelector';
import VehicleCategorySelector from './components/VehicleCategorySelector';
import BudgetRangeSlider from './components/BudgetRangeSlider';
import AdvancedPreferences from './components/AdvancedPreferences';
import DemandVisibilityToggle from './components/DemandVisibilityToggle';
import PhotoUpload from './components/PhotoUpload';
import FormValidation from './components/FormValidation';

const CreateRentalDemand = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [formValid, setFormValid] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  // Form data state
  const [formData, setFormData] = useState({
    location: null,
    pickupDate: '',
    pickupTime: '10:00',
    returnDate: '',
    returnTime: '10:00',
    categories: [],
    minBudget: 50,
    maxBudget: 150,
    preferences: {},
    visibility: 'open',
    photos: [],
    specialRequirements: ''
  });

  const steps = [
    { id: 1, title: 'Lieu', icon: 'MapPin', description: 'Où souhaitez-vous récupérer le véhicule ?' },
    { id: 2, title: 'Dates', icon: 'Calendar', description: 'Quand avez-vous besoin du véhicule ?' },
    { id: 3, title: 'Véhicule', icon: 'Car', description: 'Quel type de véhicule recherchez-vous ?' },
    { id: 4, title: 'Budget', icon: 'DollarSign', description: 'Quel est votre budget ?' },
    { id: 5, title: 'Options', icon: 'Settings', description: 'Préférences et options avancées' },
    { id: 6, title: 'Finaliser', icon: 'Check', description: 'Vérification et publication' }
  ];

  // Auto-save to localStorage
  useEffect(() => {
    const savedData = localStorage.getItem('rental-demand-draft');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        setFormData(parsed);
      } catch (error) {
        console.error('Error loading saved data:', error);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('rental-demand-draft', JSON.stringify(formData));
  }, [formData]);

  const updateFormData = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleValidationChange = (isValid, errors) => {
    setFormValid(isValid);
    setValidationErrors(errors);
  };

  const handleNextStep = () => {
    if (currentStep < steps?.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleStepClick = (stepId) => {
    setCurrentStep(stepId);
  };

  const handleSubmit = async () => {
    if (!formValid) return;

    setIsSubmitting(true);
    
    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Clear draft
      localStorage.removeItem('rental-demand-draft');
      
      // Navigate to offers dashboard
      navigate('/live-offers-dashboard', { 
        state: { 
          newDemand: true,
          demandData: formData 
        }
      });
    } catch (error) {
      console.error('Error submitting demand:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const calculateProgress = () => {
    const requiredFields = [
      formData?.location,
      formData?.pickupDate,
      formData?.returnDate,
      formData?.categories?.length > 0,
      formData?.minBudget && formData?.maxBudget
    ];
    
    const completed = requiredFields?.filter(Boolean)?.length;
    return (completed / requiredFields?.length) * 100;
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <LocationPicker
            selectedLocation={formData?.location}
            onLocationChange={(location) => updateFormData('location', location)}
            error={validationErrors?.location}
            showMap={true}
          />
        );
      
      case 2:
        return (
          <DateTimeSelector
            pickupDate={formData?.pickupDate}
            pickupTime={formData?.pickupTime}
            returnDate={formData?.returnDate}
            returnTime={formData?.returnTime}
            onPickupDateChange={(date) => updateFormData('pickupDate', date)}
            onPickupTimeChange={(time) => updateFormData('pickupTime', time)}
            onReturnDateChange={(date) => updateFormData('returnDate', date)}
            onReturnTimeChange={(time) => updateFormData('returnTime', time)}
            errors={validationErrors}
          />
        );
      
      case 3:
        return (
          <VehicleCategorySelector
            selectedCategories={formData?.categories}
            onCategoryChange={(categories) => updateFormData('categories', categories)}
            error={validationErrors?.categories}
          />
        );
      
      case 4:
        return (
          <BudgetRangeSlider
            minBudget={formData?.minBudget}
            maxBudget={formData?.maxBudget}
            onBudgetChange={(range) => {
              updateFormData('minBudget', range?.[0]);
              updateFormData('maxBudget', range?.[1]);
            }}
            currency="EUR"
            error={validationErrors?.budget}
          />
        );
      
      case 5:
        return (
          <div className="space-y-8">
            <AdvancedPreferences
              preferences={formData?.preferences}
              onPreferencesChange={(prefs) => updateFormData('preferences', prefs)}
              isExpanded={showAdvanced}
              onToggleExpanded={() => setShowAdvanced(!showAdvanced)}
            />
            {showAdvanced && (
              <>
                <DemandVisibilityToggle
                  visibility={formData?.visibility}
                  onVisibilityChange={(visibility) => updateFormData('visibility', visibility)}
                />
                
                <PhotoUpload
                  photos={formData?.photos}
                  onPhotosChange={(photos) => updateFormData('photos', photos)}
                  maxPhotos={5}
                  error={validationErrors?.photos}
                />
              </>
            )}
          </div>
        );
      
      case 6:
        return (
          <div className="space-y-8">
            <FormValidation
              formData={formData}
              errors={validationErrors}
              onValidationChange={handleValidationChange}
            />
            {/* Demand Summary */}
            <div className="bg-muted/50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="FileText" size={20} className="mr-2 text-primary" />
                Résumé de votre demande
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-foreground">Lieu de prise en charge</p>
                    <p className="text-sm text-muted-foreground">
                      {formData?.location?.address || 'Non défini'}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-foreground">Période de location</p>
                    <p className="text-sm text-muted-foreground">
                      Du {formData?.pickupDate} à {formData?.pickupTime} au {formData?.returnDate} à {formData?.returnTime}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-foreground">Types de véhicules</p>
                    <p className="text-sm text-muted-foreground">
                      {formData?.categories?.length} catégorie{formData?.categories?.length > 1 ? 's' : ''} sélectionnée{formData?.categories?.length > 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-foreground">Budget par jour</p>
                    <p className="text-sm text-muted-foreground">
                      {formData?.minBudget}€ - {formData?.maxBudget}€
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-foreground">Visibilité</p>
                    <p className="text-sm text-muted-foreground">
                      {formData?.visibility === 'open' ? 'Marché ouvert' :
                       formData?.visibility === 'verified' ? 'Agences vérifiées' :
                       'Agences premium'}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-foreground">Photos ajoutées</p>
                    <p className="text-sm text-muted-foreground">
                      {formData?.photos?.length} photo{formData?.photos?.length > 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="client" notificationCount={3} />
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Progress Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Créer une demande de location</h1>
              <p className="text-muted-foreground mt-2">
                Décrivez vos besoins et recevez des offres personnalisées d'agences vérifiées
              </p>
            </div>
            
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">Progression</p>
                <p className="text-xs text-muted-foreground">{Math.round(calculateProgress())}% complété</p>
              </div>
              <div className="w-24 h-2 bg-border rounded-full">
                <div 
                  className="h-2 bg-primary rounded-full transition-all duration-300"
                  style={{ width: `${calculateProgress()}%` }}
                />
              </div>
            </div>
          </div>

          {/* Step Navigation */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-2">
            {steps?.map((step, index) => (
              <React.Fragment key={step?.id}>
                <button
                  onClick={() => handleStepClick(step?.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                    currentStep === step?.id
                      ? 'bg-primary text-primary-foreground'
                      : currentStep > step?.id
                      ? 'bg-success/10 text-success hover:bg-success/20' :'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
                >
                  <Icon 
                    name={currentStep > step?.id ? 'Check' : step?.icon} 
                    size={16} 
                  />
                  <span className="hidden sm:inline">{step?.title}</span>
                </button>
                
                {index < steps?.length - 1 && (
                  <div className={`w-8 h-px ${
                    currentStep > step?.id ? 'bg-success' : 'bg-border'
                  }`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Form Content */}
          <div className="lg:col-span-3">
            <div className="bg-card rounded-lg border border-border p-6">
              {/* Step Header */}
              <div className="mb-8">
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <Icon name={steps?.[currentStep - 1]?.icon} size={20} color="white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">
                      Étape {currentStep}: {steps?.[currentStep - 1]?.title}
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      {steps?.[currentStep - 1]?.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Step Content */}
              <div className="mb-8">
                {renderStepContent()}
              </div>

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between pt-6 border-t border-border">
                <Button
                  variant="outline"
                  onClick={handlePrevStep}
                  disabled={currentStep === 1}
                >
                  <Icon name="ChevronLeft" size={16} className="mr-2" />
                  Précédent
                </Button>

                <div className="flex items-center space-x-3">
                  {currentStep < steps?.length ? (
                    <Button
                      onClick={handleNextStep}
                      disabled={currentStep === 1 && !formData?.location}
                    >
                      Suivant
                      <Icon name="ChevronRight" size={16} className="ml-2" />
                    </Button>
                  ) : (
                    <Button
                      onClick={handleSubmit}
                      disabled={!formValid || isSubmitting}
                      loading={isSubmitting}
                      variant="default"
                      size="lg"
                    >
                      {isSubmitting ? 'Publication...' : 'Publier ma demande'}
                      <Icon name="Send" size={16} className="ml-2" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              {/* Quick Stats */}
              <div className="bg-card rounded-lg border border-border p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3">Statistiques</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Temps moyen de réponse</span>
                    <span className="text-xs font-medium text-foreground">2-4h</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Offres moyennes reçues</span>
                    <span className="text-xs font-medium text-foreground">5-8</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Taux de réservation</span>
                    <span className="text-xs font-medium text-success">94%</span>
                  </div>
                </div>
              </div>

              {/* Tips */}
              <div className="bg-card rounded-lg border border-border p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center">
                  <Icon name="Lightbulb" size={16} className="mr-2 text-warning" />
                  Conseils
                </h3>
                <ul className="space-y-2 text-xs text-muted-foreground">
                  <li>• Soyez précis dans vos critères pour recevoir des offres pertinentes</li>
                  <li>• Les demandes avec photos reçoivent 40% d'offres en plus</li>
                  <li>• Répondez rapidement aux offres pour sécuriser les meilleurs prix</li>
                </ul>
              </div>

              {/* Support */}
              <div className="bg-card rounded-lg border border-border p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3">Besoin d'aide ?</h3>
                <Button variant="outline" size="sm" fullWidth>
                  <Icon name="MessageCircle" size={16} className="mr-2" />
                  Contacter le support
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateRentalDemand;