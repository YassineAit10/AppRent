import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const RegisterForm = ({ onSubmit, loading, error }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    profilePhoto: null,
    acceptTerms: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [photoPreview, setPhotoPreview] = useState(null);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handlePhotoChange = (e) => {
    const file = e?.target?.files?.[0];
    if (file) {
      if (file?.size > 5 * 1024 * 1024) {
        setErrors(prev => ({ ...prev, profilePhoto: 'La photo doit faire moins de 5MB' }));
        return;
      }
      
      setFormData(prev => ({ ...prev, profilePhoto: file }));
      
      const reader = new FileReader();
      reader.onload = (e) => setPhotoPreview(e?.target?.result);
      reader?.readAsDataURL(file);
      
      if (errors?.profilePhoto) {
        setErrors(prev => ({ ...prev, profilePhoto: '' }));
      }
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData?.firstName?.trim()) {
      newErrors.firstName = 'Prénom requis';
    }
    
    if (!formData?.lastName?.trim()) {
      newErrors.lastName = 'Nom requis';
    }
    
    if (!formData?.email?.trim()) {
      newErrors.email = 'Email requis';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/?.test(formData?.email)) {
      newErrors.email = 'Format email invalide';
    }
    
    if (!formData?.phone?.trim()) {
      newErrors.phone = 'Téléphone requis';
    } else if (!/^(\+33|0)[1-9](\d{8})$/?.test(formData?.phone?.replace(/\s/g, ''))) {
      newErrors.phone = 'Format téléphone invalide';
    }
    
    if (!formData?.password) {
      newErrors.password = 'Mot de passe requis';
    } else if (formData?.password?.length < 8) {
      newErrors.password = 'Minimum 8 caractères';
    }
    
    if (formData?.password !== formData?.confirmPassword) {
      newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
    }
    
    if (!formData?.acceptTerms) {
      newErrors.acceptTerms = 'Vous devez accepter les conditions';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-error/10 border border-error/20 rounded-md">
          <p className="text-sm text-error flex items-center">
            <Icon name="AlertCircle" size={16} className="mr-2" />
            {error}
          </p>
        </div>
      )}
      {/* Profile Photo Upload */}
      <div className="flex flex-col items-center space-y-3">
        <div className="relative">
          {photoPreview ? (
            <Image
              src={photoPreview}
              alt="Photo de profil"
              className="w-20 h-20 rounded-full object-cover border-2 border-border"
            />
          ) : (
            <div className="w-20 h-20 rounded-full bg-muted border-2 border-dashed border-border flex items-center justify-center">
              <Icon name="User" size={24} className="text-muted-foreground" />
            </div>
          )}
          <label className="absolute -bottom-1 -right-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center cursor-pointer hover:bg-primary/80 transition-colors">
            <Icon name="Camera" size={12} color="white" />
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoChange}
              className="hidden"
            />
          </label>
        </div>
        <p className="text-xs text-muted-foreground">Photo de profil (optionnel)</p>
        {errors?.profilePhoto && (
          <p className="text-xs text-error">{errors?.profilePhoto}</p>
        )}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="Prénom"
          type="text"
          placeholder="Jean"
          value={formData?.firstName}
          onChange={(e) => handleChange('firstName', e?.target?.value)}
          error={errors?.firstName}
          required
        />

        <Input
          label="Nom"
          type="text"
          placeholder="Dupont"
          value={formData?.lastName}
          onChange={(e) => handleChange('lastName', e?.target?.value)}
          error={errors?.lastName}
          required
        />
      </div>
      <Input
        label="Email"
        type="email"
        placeholder="jean.dupont@email.fr"
        value={formData?.email}
        onChange={(e) => handleChange('email', e?.target?.value)}
        error={errors?.email}
        required
      />
      <Input
        label="Téléphone"
        type="tel"
        placeholder="+33 6 12 34 56 78"
        value={formData?.phone}
        onChange={(e) => handleChange('phone', e?.target?.value)}
        error={errors?.phone}
        required
      />
      <div className="relative">
        <Input
          label="Mot de passe"
          type={showPassword ? 'text' : 'password'}
          placeholder="Minimum 8 caractères"
          value={formData?.password}
          onChange={(e) => handleChange('password', e?.target?.value)}
          error={errors?.password}
          required
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-8 text-muted-foreground hover:text-foreground"
        >
          <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={16} />
        </button>
      </div>
      <div className="relative">
        <Input
          label="Confirmer le mot de passe"
          type={showConfirmPassword ? 'text' : 'password'}
          placeholder="Répétez votre mot de passe"
          value={formData?.confirmPassword}
          onChange={(e) => handleChange('confirmPassword', e?.target?.value)}
          error={errors?.confirmPassword}
          required
        />
        <button
          type="button"
          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
          className="absolute right-3 top-8 text-muted-foreground hover:text-foreground"
        >
          <Icon name={showConfirmPassword ? 'EyeOff' : 'Eye'} size={16} />
        </button>
      </div>
      <div className="space-y-3">
        <Checkbox
          label={
            <span className="text-sm">
              J'accepte les{' '}
              <Button variant="link" size="sm" className="p-0 h-auto text-sm">
                conditions d'utilisation
              </Button>
              {' '}et la{' '}
              <Button variant="link" size="sm" className="p-0 h-auto text-sm">
                politique de confidentialité
              </Button>
            </span>
          }
          checked={formData?.acceptTerms}
          onChange={(e) => handleChange('acceptTerms', e?.target?.checked)}
          error={errors?.acceptTerms}
          required
        />
      </div>
      <Button
        type="submit"
        variant="default"
        size="lg"
        fullWidth
        loading={loading}
        iconName="UserPlus"
        iconPosition="left"
      >
        Créer mon compte
      </Button>
    </form>
  );
};

export default RegisterForm;