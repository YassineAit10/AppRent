import React from 'react';
import Icon from '../../../components/AppIcon';

const BookingStats = ({ stats, userRole = 'client' }) => {
  const getStatsForRole = () => {
    if (userRole === 'agency') {
      return [
        {
          label: 'Réservations actives',
          value: stats?.activeBookings || 0,
          icon: 'Calendar',
          color: 'text-primary',
          bgColor: 'bg-primary/10',
          change: stats?.activeBookingsChange || 0
        },
        {
          label: 'Confirmations en attente',
          value: stats?.pendingConfirmations || 0,
          icon: 'Clock',
          color: 'text-warning',
          bgColor: 'bg-warning/10',
          urgent: stats?.urgentConfirmations || 0
        },
        {
          label: 'Revenus du mois',
          value: `${stats?.monthlyRevenue || 0}€`,
          icon: 'TrendingUp',
          color: 'text-success',
          bgColor: 'bg-success/10',
          change: stats?.revenueChange || 0
        },
        {
          label: 'Taux de confirmation',
          value: `${stats?.confirmationRate || 0}%`,
          icon: 'CheckCircle',
          color: 'text-secondary',
          bgColor: 'bg-secondary/10',
          change: stats?.confirmationRateChange || 0
        }
      ];
    } else {
      return [
        {
          label: 'Réservations actives',
          value: stats?.activeBookings || 0,
          icon: 'Calendar',
          color: 'text-primary',
          bgColor: 'bg-primary/10'
        },
        {
          label: 'Réservations à venir',
          value: stats?.upcomingBookings || 0,
          icon: 'Clock',
          color: 'text-warning',
          bgColor: 'bg-warning/10'
        },
        {
          label: 'Dépenses totales',
          value: `${stats?.totalSpent || 0}€`,
          icon: 'CreditCard',
          color: 'text-success',
          bgColor: 'bg-success/10'
        },
        {
          label: 'Réservations terminées',
          value: stats?.completedBookings || 0,
          icon: 'CheckCircle',
          color: 'text-secondary',
          bgColor: 'bg-secondary/10'
        }
      ];
    }
  };

  const statsData = getStatsForRole();

  const formatChange = (change) => {
    if (!change) return null;
    const isPositive = change > 0;
    return (
      <div className={`flex items-center text-xs ${
        isPositive ? 'text-success' : 'text-error'
      }`}>
        <Icon 
          name={isPositive ? 'TrendingUp' : 'TrendingDown'} 
          size={12} 
          className="mr-1" 
        />
        {Math.abs(change)}%
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {statsData?.map((stat, index) => (
        <div
          key={index}
          className="bg-card border border-border rounded-lg p-4 shadow-elevation-1 hover:shadow-elevation-2 transition-shadow"
        >
          <div className="flex items-center justify-between">
            <div className={`w-10 h-10 rounded-lg ${stat?.bgColor} flex items-center justify-center`}>
              <Icon name={stat?.icon} size={20} className={stat?.color} />
            </div>
            {stat?.change !== undefined && formatChange(stat?.change)}
          </div>
          
          <div className="mt-3">
            <div className="flex items-baseline space-x-2">
              <p className="text-2xl font-bold text-foreground">{stat?.value}</p>
              {stat?.urgent > 0 && (
                <span className="px-2 py-1 text-xs bg-error text-error-foreground rounded-full animate-pulse-gentle">
                  {stat?.urgent} urgent{stat?.urgent > 1 ? 's' : ''}
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-1">{stat?.label}</p>
          </div>

          {/* Additional context for agency stats */}
          {userRole === 'agency' && (
            <div className="mt-3 pt-3 border-t border-border">
              {stat?.label === 'Confirmations en attente' && stat?.urgent > 0 && (
                <div className="flex items-center text-xs text-error">
                  <Icon name="AlertTriangle" size={12} className="mr-1" />
                  {stat?.urgent} confirmation{stat?.urgent > 1 ? 's' : ''} urgente{stat?.urgent > 1 ? 's' : ''} (&lt; 2h)
                </div>
              )}
              {stat?.label === 'Taux de confirmation' && (
                <div className="text-xs text-muted-foreground">
                  Objectif: 95% minimum
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default BookingStats;