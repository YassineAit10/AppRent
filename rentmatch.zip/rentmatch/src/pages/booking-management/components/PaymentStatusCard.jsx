import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PaymentStatusCard = ({ 
  booking, 
  onPaymentAction,
  onViewReceipt,
  onRequestRefund 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getPaymentStatusConfig = (status) => {
    const configs = {
      pending: {
        color: 'warning',
        icon: 'Clock',
        label: 'Paiement en attente',
        description: 'Traitement en cours',
        bgClass: 'bg-warning/10 text-warning border-warning/20'
      },
      secured: {
        color: 'success',
        icon: 'Shield',
        label: 'Paiement sécurisé',
        description: 'Fonds bloqués en séquestre',
        bgClass: 'bg-success/10 text-success border-success/20'
      },
      released: {
        color: 'primary',
        icon: 'CheckCircle',
        label: 'Paiement libéré',
        description: 'Transaction terminée',
        bgClass: 'bg-primary/10 text-primary border-primary/20'
      },
      refunded: {
        color: 'secondary',
        icon: 'RotateCcw',
        label: 'Remboursé',
        description: 'Fonds retournés',
        bgClass: 'bg-secondary/10 text-secondary border-secondary/20'
      },
      failed: {
        color: 'error',
        icon: 'XCircle',
        label: 'Paiement échoué',
        description: 'Action requise',
        bgClass: 'bg-error/10 text-error border-error/20'
      }
    };
    return configs?.[status] || configs?.pending;
  };

  const statusConfig = getPaymentStatusConfig(booking?.paymentStatus);

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPaymentBreakdown = () => {
    return [
      {
        label: 'Prix de base',
        amount: booking?.pricing?.basePrice || 0,
        type: 'base'
      },
      {
        label: 'Options supplémentaires',
        amount: booking?.pricing?.extras || 0,
        type: 'extras'
      },
      {
        label: 'Assurance',
        amount: booking?.pricing?.insurance || 0,
        type: 'insurance'
      },
      {
        label: 'Taxes',
        amount: booking?.pricing?.taxes || 0,
        type: 'taxes'
      },
      {
        label: 'Frais de service',
        amount: booking?.pricing?.serviceFee || 0,
        type: 'service'
      }
    ]?.filter(item => item?.amount > 0);
  };

  const paymentBreakdown = getPaymentBreakdown();
  const totalAmount = booking?.totalPrice || 0;
  const depositAmount = booking?.depositAmount || 0;
  const remainingAmount = totalAmount - depositAmount;

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-lg ${statusConfig?.bgClass?.split(' ')?.[0]} flex items-center justify-center`}>
              <Icon name={statusConfig?.icon} size={20} className={statusConfig?.color} />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{statusConfig?.label}</h3>
              <p className="text-sm text-muted-foreground">{statusConfig?.description}</p>
            </div>
          </div>
          
          <div className="text-right">
            <p className="text-lg font-bold text-foreground">{totalAmount}€</p>
            {depositAmount > 0 && (
              <p className="text-sm text-muted-foreground">
                Acompte: {depositAmount}€
              </p>
            )}
          </div>
        </div>

        {/* Status Badge */}
        <div className="mt-3">
          <span className={`inline-flex items-center px-3 py-1 text-sm rounded-full border ${statusConfig?.bgClass}`}>
            <Icon name={statusConfig?.icon} size={14} className="mr-1" />
            {statusConfig?.label}
          </span>
        </div>
      </div>
      {/* Payment Details */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-medium text-foreground">Détails du paiement</h4>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
          </Button>
        </div>

        {/* Quick Payment Info */}
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Méthode de paiement</span>
            <span className="font-medium text-foreground">
              {booking?.paymentMethod === 'escrow' ? 'Paiement sécurisé' : 'Paiement sur place'}
            </span>
          </div>
          
          {booking?.paymentDate && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Date de paiement</span>
              <span className="font-medium text-foreground">
                {formatDate(booking?.paymentDate)}
              </span>
            </div>
          )}

          {booking?.transactionId && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Référence</span>
              <span className="font-mono text-sm text-foreground">
                {booking?.transactionId}
              </span>
            </div>
          )}
        </div>

        {/* Expanded Details */}
        {isExpanded && (
          <div className="mt-4 pt-4 border-t border-border animate-slide-down">
            {/* Payment Breakdown */}
            <div className="mb-4">
              <h5 className="font-medium text-foreground mb-3">Détail des coûts</h5>
              <div className="space-y-2">
                {paymentBreakdown?.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item?.label}</span>
                    <span className="font-medium text-foreground">{item?.amount}€</span>
                  </div>
                ))}
                <div className="pt-2 border-t border-border">
                  <div className="flex justify-between font-semibold">
                    <span className="text-foreground">Total</span>
                    <span className="text-foreground">{totalAmount}€</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Schedule */}
            {depositAmount > 0 && remainingAmount > 0 && (
              <div className="mb-4">
                <h5 className="font-medium text-foreground mb-3">Échéancier de paiement</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Acompte (réservation)</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-foreground">{depositAmount}€</span>
                      <Icon name="CheckCircle" size={14} className="text-success" />
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Solde (à la prise en charge)</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-foreground">{remainingAmount}€</span>
                      {booking?.status === 'completed' ? (
                        <Icon name="CheckCircle" size={14} className="text-success" />
                      ) : (
                        <Icon name="Clock" size={14} className="text-warning" />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Escrow Information */}
            {booking?.paymentMethod === 'escrow' && booking?.paymentStatus === 'secured' && (
              <div className="mb-4 p-3 bg-success/5 border border-success/20 rounded-md">
                <div className="flex items-start space-x-2">
                  <Icon name="Shield" size={16} className="text-success mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-success">Paiement sécurisé</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Vos fonds sont bloqués en séquestre et seront libérés automatiquement 
                      après confirmation de la prise en charge du véhicule.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Refund Information */}
            {booking?.refundInfo && (
              <div className="mb-4">
                <h5 className="font-medium text-foreground mb-3">Informations de remboursement</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Montant remboursé</span>
                    <span className="font-medium text-foreground">{booking?.refundInfo?.amount}€</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date de remboursement</span>
                    <span className="font-medium text-foreground">
                      {formatDate(booking?.refundInfo?.date)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Délai de traitement</span>
                    <span className="font-medium text-foreground">3-5 jours ouvrés</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 mt-4">
          {booking?.paymentStatus === 'pending' && (
            <Button
              variant="default"
              size="sm"
              onClick={() => onPaymentAction('complete', booking)}
            >
              <Icon name="CreditCard" size={16} />
              Finaliser le paiement
            </Button>
          )}

          {booking?.paymentStatus === 'failed' && (
            <Button
              variant="default"
              size="sm"
              onClick={() => onPaymentAction('retry', booking)}
            >
              <Icon name="RefreshCw" size={16} />
              Réessayer le paiement
            </Button>
          )}

          {['secured', 'released', 'refunded']?.includes(booking?.paymentStatus) && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewReceipt(booking)}
            >
              <Icon name="FileText" size={16} />
              Voir le reçu
            </Button>
          )}

          {booking?.paymentStatus === 'secured' && booking?.status === 'confirmed' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onRequestRefund(booking)}
              className="text-error hover:bg-error/10"
            >
              <Icon name="RotateCcw" size={16} />
              Demander un remboursement
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentStatusCard;