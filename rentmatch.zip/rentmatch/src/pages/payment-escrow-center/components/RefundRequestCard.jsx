import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RefundRequestCard = ({ refund, onViewDetails, onCancelRequest, onUploadDocument }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getStatusConfig = (status) => {
    const configs = {
      pending: {
        color: 'text-warning',
        bgColor: 'bg-warning/10',
        icon: 'Clock',
        label: 'En cours de traitement'
      },
      approved: {
        color: 'text-success',
        bgColor: 'bg-success/10',
        icon: 'CheckCircle',
        label: 'Approuvé'
      },
      processing: {
        color: 'text-primary',
        bgColor: 'bg-primary/10',
        icon: 'RefreshCw',
        label: 'En traitement'
      },
      completed: {
        color: 'text-success',
        bgColor: 'bg-success/10',
        icon: 'Check',
        label: 'Remboursé'
      },
      rejected: {
        color: 'text-error',
        bgColor: 'bg-error/10',
        icon: 'XCircle',
        label: 'Refusé'
      },
      cancelled: {
        color: 'text-muted-foreground',
        bgColor: 'bg-muted',
        icon: 'X',
        label: 'Annulé'
      }
    };
    return configs?.[status] || configs?.pending;
  };

  const statusConfig = getStatusConfig(refund?.status);

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    })?.format(amount);
  };

  const getEstimatedProcessingTime = (paymentMethod) => {
    const times = {
      card: '3-5 jours ouvrés',
      bank: '1-3 jours ouvrés',
      paypal: '1-2 jours ouvrés',
      apple: '1-3 jours ouvrés',
      google: '1-3 jours ouvrés'
    };
    return times?.[paymentMethod] || '3-5 jours ouvrés';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-elevation-2 transition-shadow">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start space-x-3">
          <div className={`w-10 h-10 rounded-full ${statusConfig?.bgColor} flex items-center justify-center`}>
            <Icon name={statusConfig?.icon} size={20} className={statusConfig?.color} />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">
              Demande de remboursement #{refund?.requestId}
            </h3>
            <p className="text-sm text-muted-foreground">
              Réservation #{refund?.bookingReference}
            </p>
            <div className="flex items-center space-x-2 mt-1">
              <span className={`px-2 py-1 text-xs rounded-full ${statusConfig?.bgColor} ${statusConfig?.color} font-medium`}>
                {statusConfig?.label}
              </span>
              <span className="text-xs text-muted-foreground">
                {formatDate(refund?.requestedAt)}
              </span>
            </div>
          </div>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-foreground">
            {formatAmount(refund?.amount)}
          </p>
          <p className="text-sm text-muted-foreground">
            Montant demandé
          </p>
        </div>
      </div>
      {/* Quick Info */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Tag" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Motif</p>
          <p className="text-sm font-medium text-foreground">{refund?.reason}</p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="CreditCard" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Méthode</p>
          <p className="text-sm font-medium text-foreground">{refund?.paymentMethod}</p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Clock" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Délai estimé</p>
          <p className="text-sm font-medium text-foreground">
            {getEstimatedProcessingTime(refund?.paymentMethod)}
          </p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="User" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Traité par</p>
          <p className="text-sm font-medium text-foreground">
            {refund?.processedBy || 'En attente'}
          </p>
        </div>
      </div>
      {/* Expanded Details */}
      {isExpanded && (
        <div className="border-t border-border pt-3 mt-3 animate-slide-down">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Refund Details */}
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="FileText" size={16} className="mr-2" />
                Détails de la demande
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Montant original:</span>
                  <span className="text-foreground">{formatAmount(refund?.originalAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Frais retenus:</span>
                  <span className="text-foreground">{formatAmount(refund?.feesRetained)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Montant à rembourser:</span>
                  <span className="text-foreground font-medium">{formatAmount(refund?.amount)}</span>
                </div>
                {refund?.description && (
                  <div className="mt-3">
                    <span className="text-muted-foreground block mb-1">Description:</span>
                    <p className="text-foreground text-sm bg-muted/30 p-2 rounded-md">
                      {refund?.description}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Processing Timeline */}
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Timeline" size={16} className="mr-2" />
                Suivi du traitement
              </h4>
              <div className="space-y-2">
                {refund?.timeline?.map((event, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm">
                    <div className={`w-2 h-2 rounded-full mt-2 ${event?.completed ? 'bg-success' : 'bg-muted'}`}></div>
                    <div className="flex-1">
                      <span className={event?.completed ? 'text-foreground' : 'text-muted-foreground'}>
                        {event?.label}
                      </span>
                      {event?.date && (
                        <p className="text-xs text-muted-foreground">
                          {formatDate(event?.date)}
                        </p>
                      )}
                      {event?.note && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {event?.note}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Documents */}
          {refund?.documents && refund?.documents?.length > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Paperclip" size={16} className="mr-2" />
                Documents joints
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {refund?.documents?.map((doc, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-muted/30 rounded-md">
                    <Icon name="FileText" size={16} className="text-muted-foreground" />
                    <span className="text-sm text-foreground flex-1 truncate">{doc?.name}</span>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                      <Icon name="Download" size={14} />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Admin Notes */}
          {refund?.adminNotes && (
            <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-md">
              <h4 className="font-medium text-primary mb-2 flex items-center">
                <Icon name="MessageSquare" size={16} className="mr-2" />
                Notes administratives
              </h4>
              <p className="text-sm text-muted-foreground">{refund?.adminNotes}</p>
            </div>
          )}

          {/* Rejection Reason */}
          {refund?.status === 'rejected' && refund?.rejectionReason && (
            <div className="mt-4 p-3 bg-error/5 border border-error/20 rounded-md">
              <h4 className="font-medium text-error mb-2 flex items-center">
                <Icon name="AlertTriangle" size={16} className="mr-2" />
                Motif du refus
              </h4>
              <p className="text-sm text-muted-foreground">{refund?.rejectionReason}</p>
            </div>
          )}
        </div>
      )}
      {/* Actions */}
      <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? 'Moins de détails' : 'Plus de détails'}
          <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} className="ml-1" />
        </Button>

        <div className="flex items-center space-x-2">
          {refund?.status === 'pending' && refund?.canUploadDocuments && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onUploadDocument?.(refund?.requestId)}
            >
              <Icon name="Upload" size={16} className="mr-1" />
              Ajouter document
            </Button>
          )}
          
          {['pending', 'approved']?.includes(refund?.status) && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onCancelRequest?.(refund?.requestId)}
              className="text-error border-error hover:bg-error/10"
            >
              <Icon name="X" size={16} className="mr-1" />
              Annuler
            </Button>
          )}
          
          <Button
            variant="default"
            size="sm"
            onClick={() => onViewDetails?.(refund?.requestId)}
          >
            Voir détails
            <Icon name="ArrowRight" size={16} className="ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RefundRequestCard;