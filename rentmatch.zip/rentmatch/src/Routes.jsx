import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import LiveOffersDashboard from './pages/live-offers-dashboard';
import AgencyDashboard from './pages/agency-dashboard';
import CreateRentalDemand from './pages/create-rental-demand';
import BookingManagement from './pages/booking-management';
import PaymentEscrowCenter from './pages/payment-escrow-center';
import ClientRegistrationLogin from './pages/client-registration-login';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<AgencyDashboard />} />
        <Route path="/live-offers-dashboard" element={<LiveOffersDashboard />} />
        <Route path="/agency-dashboard" element={<AgencyDashboard />} />
        <Route path="/create-rental-demand" element={<CreateRentalDemand />} />
        <Route path="/booking-management" element={<BookingManagement />} />
        <Route path="/payment-escrow-center" element={<PaymentEscrowCenter />} />
        <Route path="/client-registration-login" element={<ClientRegistrationLogin />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
