import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const DemandCard = ({ demand, onCreateOffer, onViewDetails }) => {
  const [timeLeft, setTimeLeft] = useState('');
  const [urgencyLevel, setUrgencyLevel] = useState('normal');

  // Calculate time remaining and urgency
  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date();
      const deadline = new Date(demand.responseDeadline);
      const diff = deadline - now;

      if (diff <= 0) {
        setTimeLeft('Expiré');
        setUrgencyLevel('expired');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

      if (hours < 2) {
        setUrgencyLevel('urgent');
        setTimeLeft(`${hours}h ${minutes}m`);
      } else if (hours < 24) {
        setUrgencyLevel('warning');
        setTimeLeft(`${hours}h ${minutes}m`);
      } else {
        setUrgencyLevel('normal');
        const days = Math.floor(hours / 24);
        const remainingHours = hours % 24;
        setTimeLeft(`${days}j ${remainingHours}h`);
      }
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [demand?.responseDeadline]);

  const getUrgencyColor = () => {
    switch (urgencyLevel) {
      case 'urgent': return 'text-error bg-error/10 border-error/20';
      case 'warning': return 'text-warning bg-warning/10 border-warning/20';
      case 'expired': return 'text-muted-foreground bg-muted border-border';
      default: return 'text-success bg-success/10 border-success/20';
    }
  };

  const getClientRatingColor = (rating) => {
    if (rating >= 4.5) return 'text-success';
    if (rating >= 4.0) return 'text-primary';
    if (rating >= 3.5) return 'text-warning';
    return 'text-muted-foreground';
  };

  const formatBudget = (budget) => {
    return `${budget?.toLocaleString('fr-FR')}€`;
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getDurationInDays = () => {
    const start = new Date(demand.startDate);
    const end = new Date(demand.endDate);
    const diffTime = Math.abs(end - start);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const isHighProbability = demand?.matchScore >= 85;
  const isExpired = urgencyLevel === 'expired';

  return (
    <div className={`bg-card border rounded-lg shadow-elevation-1 hover:shadow-elevation-2 transition-all duration-200 ${
      isHighProbability ? 'border-primary/30 bg-primary/5' : 'border-border'
    } ${isExpired ? 'opacity-60' : ''}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            {/* Client Avatar */}
            <div className="relative">
              {demand?.client?.avatar ? (
                <Image
                  src={demand?.client?.avatar}
                  alt={demand?.client?.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
              )}
              {demand?.client?.verified && (
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-success rounded-full flex items-center justify-center">
                  <Icon name="Check" size={8} color="white" />
                </div>
              )}
            </div>

            {/* Client Info */}
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h4 className="font-medium text-foreground">{demand?.client?.name}</h4>
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={14} className={getClientRatingColor(demand?.client?.rating)} />
                  <span className={`text-sm font-medium ${getClientRatingColor(demand?.client?.rating)}`}>
                    {demand?.client?.rating?.toFixed(1)}
                  </span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                {demand?.client?.totalBookings} réservations • Membre depuis {demand?.client?.memberSince}
              </p>
            </div>
          </div>

          {/* Match Score & Urgency */}
          <div className="flex flex-col items-end space-y-2">
            {isHighProbability && (
              <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full font-medium">
                Match {demand?.matchScore}%
              </span>
            )}
            <div className={`px-2 py-1 border rounded-full text-xs font-medium ${getUrgencyColor()}`}>
              {timeLeft}
            </div>
          </div>
        </div>
      </div>
      {/* Demand Details */}
      <div className="p-4 space-y-4">
        {/* Location & Dates */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-center space-x-2">
            <Icon name="MapPin" size={16} className="text-muted-foreground" />
            <div>
              <p className="text-sm font-medium text-foreground">{demand?.location}</p>
              <p className="text-xs text-muted-foreground">Lieu de prise en charge</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Calendar" size={16} className="text-muted-foreground" />
            <div>
              <p className="text-sm font-medium text-foreground">
                {formatDate(demand?.startDate)} - {formatDate(demand?.endDate)}
              </p>
              <p className="text-xs text-muted-foreground">{getDurationInDays()} jours</p>
            </div>
          </div>
        </div>

        {/* Vehicle Preferences */}
        <div className="flex items-start space-x-2">
          <Icon name="Car" size={16} className="text-muted-foreground mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">Véhicule souhaité</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {demand?.vehiclePreferences?.map((pref, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded"
                >
                  {pref}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Budget */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="DollarSign" size={16} className="text-muted-foreground" />
            <div>
              <p className="text-sm font-medium text-foreground">
                Budget: {formatBudget(demand?.budgetPerDay)}/jour
              </p>
              <p className="text-xs text-muted-foreground">
                Total estimé: {formatBudget(demand?.budgetPerDay * getDurationInDays())}
              </p>
            </div>
          </div>
          {demand?.paymentMethod === 'escrow' && (
            <span className="px-2 py-1 bg-success/10 text-success text-xs rounded-full font-medium">
              Paiement sécurisé
            </span>
          )}
        </div>

        {/* Special Requirements */}
        {demand?.specialRequirements && demand?.specialRequirements?.length > 0 && (
          <div className="flex items-start space-x-2">
            <Icon name="AlertCircle" size={16} className="text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium text-foreground">Exigences spéciales</p>
              <p className="text-sm text-muted-foreground">{demand?.specialRequirements?.join(', ')}</p>
            </div>
          </div>
        )}
      </div>
      {/* Actions */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
            <span>ID: {demand?.id}</span>
            <span>Publié il y a {demand?.timeAgo}</span>
            {demand?.responseCount > 0 && (
              <span className="text-warning">{demand?.responseCount} offres reçues</span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewDetails?.(demand)}
              disabled={isExpired}
            >
              <Icon name="Eye" size={14} />
              Détails
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => onCreateOffer?.(demand)}
              disabled={isExpired}
              className={isHighProbability ? 'bg-primary hover:bg-primary/90' : ''}
            >
              <Icon name="Plus" size={14} />
              Créer une offre
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DemandCard;