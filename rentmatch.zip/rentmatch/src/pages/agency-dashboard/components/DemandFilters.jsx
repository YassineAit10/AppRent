import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const DemandFilters = ({ onFiltersChange, activeFilters = {} }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [filters, setFilters] = useState({
    location: activeFilters?.location || '',
    dateRange: activeFilters?.dateRange || { start: '', end: '' },
    vehicleTypes: activeFilters?.vehicleTypes || [],
    budgetRange: activeFilters?.budgetRange || { min: '', max: '' },
    clientRating: activeFilters?.clientRating || '',
    urgency: activeFilters?.urgency || '',
    ...activeFilters
  });

  const vehicleTypeOptions = [
    { value: 'economy', label: 'Économique' },
    { value: 'compact', label: 'Compacte' },
    { value: 'intermediate', label: 'Intermédiaire' },
    { value: 'standard', label: 'Standard' },
    { value: 'fullsize', label: 'Grande taille' },
    { value: 'premium', label: 'Premium' },
    { value: 'luxury', label: 'Luxe' },
    { value: 'suv', label: 'SUV' },
    { value: 'van', label: 'Utilitaire' }
  ];

  const clientRatingOptions = [
    { value: '', label: 'Tous les clients' },
    { value: '4.5', label: '4.5+ étoiles' },
    { value: '4.0', label: '4.0+ étoiles' },
    { value: '3.5', label: '3.5+ étoiles' },
    { value: '3.0', label: '3.0+ étoiles' }
  ];

  const urgencyOptions = [
    { value: '', label: 'Toutes les urgences' },
    { value: 'urgent', label: 'Urgent (< 2h)' },
    { value: 'normal', label: 'Normal (< 24h)' },
    { value: 'flexible', label: 'Flexible (> 24h)' }
  ];

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange?.(newFilters);
  };

  const handleVehicleTypeChange = (vehicleType, checked) => {
    const newTypes = checked 
      ? [...filters?.vehicleTypes, vehicleType]
      : filters?.vehicleTypes?.filter(type => type !== vehicleType);
    handleFilterChange('vehicleTypes', newTypes);
  };

  const clearAllFilters = () => {
    const emptyFilters = {
      location: '',
      dateRange: { start: '', end: '' },
      vehicleTypes: [],
      budgetRange: { min: '', max: '' },
      clientRating: '',
      urgency: ''
    };
    setFilters(emptyFilters);
    onFiltersChange?.(emptyFilters);
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters?.location) count++;
    if (filters?.dateRange?.start || filters?.dateRange?.end) count++;
    if (filters?.vehicleTypes?.length > 0) count++;
    if (filters?.budgetRange?.min || filters?.budgetRange?.max) count++;
    if (filters?.clientRating) count++;
    if (filters?.urgency) count++;
    return count;
  };

  const activeFilterCount = getActiveFilterCount();

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-primary" />
          <h3 className="font-semibold text-foreground">Filtres</h3>
          {activeFilterCount > 0 && (
            <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full font-medium">
              {activeFilterCount}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAllFilters}
              className="text-xs"
            >
              Effacer
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="lg:hidden"
          >
            <Icon name={isCollapsed ? 'ChevronDown' : 'ChevronUp'} size={16} />
          </Button>
        </div>
      </div>
      {/* Filters Content */}
      <div className={`${isCollapsed ? 'hidden lg:block' : 'block'}`}>
        <div className="p-4 space-y-6">
          {/* Location Filter */}
          <div>
            <Input
              label="Localisation"
              type="text"
              placeholder="Ville, région, aéroport..."
              value={filters?.location}
              onChange={(e) => handleFilterChange('location', e?.target?.value)}
              className="mb-0"
            />
          </div>

          {/* Date Range Filter */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Période de location
            </label>
            <div className="grid grid-cols-2 gap-2">
              <Input
                type="date"
                placeholder="Date début"
                value={filters?.dateRange?.start}
                onChange={(e) => handleFilterChange('dateRange', {
                  ...filters?.dateRange,
                  start: e?.target?.value
                })}
              />
              <Input
                type="date"
                placeholder="Date fin"
                value={filters?.dateRange?.end}
                onChange={(e) => handleFilterChange('dateRange', {
                  ...filters?.dateRange,
                  end: e?.target?.value
                })}
              />
            </div>
          </div>

          {/* Vehicle Types Filter */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Types de véhicules
            </label>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {vehicleTypeOptions?.map((option) => (
                <Checkbox
                  key={option?.value}
                  label={option?.label}
                  checked={filters?.vehicleTypes?.includes(option?.value)}
                  onChange={(e) => handleVehicleTypeChange(option?.value, e?.target?.checked)}
                />
              ))}
            </div>
          </div>

          {/* Budget Range Filter */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Budget (€/jour)
            </label>
            <div className="grid grid-cols-2 gap-2">
              <Input
                type="number"
                placeholder="Min"
                value={filters?.budgetRange?.min}
                onChange={(e) => handleFilterChange('budgetRange', {
                  ...filters?.budgetRange,
                  min: e?.target?.value
                })}
              />
              <Input
                type="number"
                placeholder="Max"
                value={filters?.budgetRange?.max}
                onChange={(e) => handleFilterChange('budgetRange', {
                  ...filters?.budgetRange,
                  max: e?.target?.value
                })}
              />
            </div>
          </div>

          {/* Client Rating Filter */}
          <div>
            <Select
              label="Note client minimum"
              options={clientRatingOptions}
              value={filters?.clientRating}
              onChange={(value) => handleFilterChange('clientRating', value)}
            />
          </div>

          {/* Urgency Filter */}
          <div>
            <Select
              label="Urgence de la demande"
              options={urgencyOptions}
              value={filters?.urgency}
              onChange={(value) => handleFilterChange('urgency', value)}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default DemandFilters;