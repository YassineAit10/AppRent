import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const DateTimeSelector = ({ 
  pickupDate, 
  pickupTime, 
  returnDate, 
  returnTime,
  onPickupDateChange,
  onPickupTimeChange, 
  onReturnDateChange,
  onReturnTimeChange,
  errors = {}
}) => {
  const [showCalendar, setShowCalendar] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const today = new Date();
  const minDate = today?.toISOString()?.split('T')?.[0];
  
  // Generate time slots
  const timeSlots = [];
  for (let hour = 6; hour <= 23; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const timeString = `${hour?.toString()?.padStart(2, '0')}:${minute?.toString()?.padStart(2, '0')}`;
      timeSlots?.push(timeString);
    }
  }

  const popularTimes = ['08:00', '09:00', '10:00', '14:00', '15:00', '16:00', '18:00'];

  const calculateDuration = () => {
    if (!pickupDate || !returnDate) return null;
    
    const pickup = new Date(`${pickupDate}T${pickupTime || '10:00'}`);
    const returnDateTime = new Date(`${returnDate}T${returnTime || '10:00'}`);
    
    const diffTime = returnDateTime - pickup;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffDays >= 1) {
      return `${diffDays} jour${diffDays > 1 ? 's' : ''}`;
    } else {
      return `${diffHours} heure${diffHours > 1 ? 's' : ''}`;
    }
  };

  const getQuickDateOptions = () => {
    const options = [];
    const tomorrow = new Date(today);
    tomorrow?.setDate(today?.getDate() + 1);
    
    const nextWeek = new Date(today);
    nextWeek?.setDate(today?.getDate() + 7);
    
    const nextMonth = new Date(today);
    nextMonth?.setMonth(today?.getMonth() + 1);

    return [
      { label: 'Demain', date: tomorrow?.toISOString()?.split('T')?.[0] },
      { label: 'Dans 7 jours', date: nextWeek?.toISOString()?.split('T')?.[0] },
      { label: 'Dans 1 mois', date: nextMonth?.toISOString()?.split('T')?.[0] }
    ];
  };

  const handleQuickDate = (date, type) => {
    if (type === 'pickup') {
      onPickupDateChange(date);
      // Auto-set return date to next day if not set
      if (!returnDate) {
        const nextDay = new Date(date);
        nextDay?.setDate(nextDay?.getDate() + 1);
        onReturnDateChange(nextDay?.toISOString()?.split('T')?.[0]);
      }
    } else {
      onReturnDateChange(date);
    }
  };

  const duration = calculateDuration();

  return (
    <div className="space-y-6">
      {/* Duration Display */}
      {duration && (
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} className="text-primary" />
              <span className="text-sm font-medium text-primary">Durée de location</span>
            </div>
            <span className="text-lg font-semibold text-primary">{duration}</span>
          </div>
        </div>
      )}
      {/* Pickup Section */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Calendar" size={20} className="mr-2 text-success" />
          Prise en charge
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Input
              label="Date de prise en charge"
              type="date"
              value={pickupDate}
              onChange={(e) => onPickupDateChange(e?.target?.value)}
              min={minDate}
              error={errors?.pickupDate}
              required
            />
            
            {/* Quick Date Options */}
            <div className="flex flex-wrap gap-2">
              {getQuickDateOptions()?.map((option) => (
                <Button
                  key={option?.label}
                  variant="ghost"
                  size="sm"
                  onClick={() => handleQuickDate(option?.date, 'pickup')}
                  className="text-xs h-7"
                >
                  {option?.label}
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Input
              label="Heure de prise en charge"
              type="time"
              value={pickupTime}
              onChange={(e) => onPickupTimeChange(e?.target?.value)}
              error={errors?.pickupTime}
            />
            
            {/* Popular Times */}
            <div className="flex flex-wrap gap-1">
              {popularTimes?.map((time) => (
                <Button
                  key={time}
                  variant={pickupTime === time ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onPickupTimeChange(time)}
                  className="text-xs h-7 px-2"
                >
                  {time}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Return Section */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Calendar" size={20} className="mr-2 text-warning" />
          Retour
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Input
              label="Date de retour"
              type="date"
              value={returnDate}
              onChange={(e) => onReturnDateChange(e?.target?.value)}
              min={pickupDate || minDate}
              error={errors?.returnDate}
              required
            />
            
            {/* Quick Return Options */}
            {pickupDate && (
              <div className="flex flex-wrap gap-2">
                {[1, 2, 3, 7]?.map((days) => {
                  const returnOption = new Date(pickupDate);
                  returnOption?.setDate(returnOption?.getDate() + days);
                  const returnDateStr = returnOption?.toISOString()?.split('T')?.[0];
                  
                  return (
                    <Button
                      key={days}
                      variant="ghost"
                      size="sm"
                      onClick={() => onReturnDateChange(returnDateStr)}
                      className="text-xs h-7"
                    >
                      +{days} jour{days > 1 ? 's' : ''}
                    </Button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Input
              label="Heure de retour"
              type="time"
              value={returnTime}
              onChange={(e) => onReturnTimeChange(e?.target?.value)}
              error={errors?.returnTime}
            />
            
            {/* Popular Return Times */}
            <div className="flex flex-wrap gap-1">
              {popularTimes?.map((time) => (
                <Button
                  key={time}
                  variant={returnTime === time ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onReturnTimeChange(time)}
                  className="text-xs h-7 px-2"
                >
                  {time}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Rental Tips */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-foreground">Conseils pour votre réservation</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Les créneaux 8h-10h et 16h-18h sont les plus demandés</li>
              <li>• Réservez au moins 24h à l'avance pour plus de choix</li>
              <li>• Les locations longues (7+ jours) bénéficient souvent de tarifs préférentiels</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DateTimeSelector;