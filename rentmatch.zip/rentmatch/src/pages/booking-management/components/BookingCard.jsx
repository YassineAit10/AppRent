import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const BookingCard = ({ 
  booking, 
  userRole = 'client',
  onStatusUpdate,
  onMessageClick,
  onViewDetails,
  onModifyBooking,
  onCancelBooking 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getStatusConfig = (status) => {
    const configs = {
      confirmed: {
        color: 'success',
        icon: 'CheckCircle',
        label: 'Confirmé',
        bgClass: 'bg-success/10 text-success border-success/20'
      },
      prepared: {
        color: 'primary',
        icon: 'Car',
        label: 'Véhicule préparé',
        bgClass: 'bg-primary/10 text-primary border-primary/20'
      },
      active: {
        color: 'warning',
        icon: 'Clock',
        label: 'En cours',
        bgClass: 'bg-warning/10 text-warning border-warning/20'
      },
      completed: {
        color: 'secondary',
        icon: 'Flag',
        label: 'Terminé',
        bgClass: 'bg-secondary/10 text-secondary border-secondary/20'
      },
      cancelled: {
        color: 'error',
        icon: 'XCircle',
        label: 'Annulé',
        bgClass: 'bg-error/10 text-error border-error/20'
      }
    };
    return configs?.[status] || configs?.confirmed;
  };

  const statusConfig = getStatusConfig(booking?.status);
  const isUpcoming = new Date(booking.pickupDate) > new Date();
  const daysUntilPickup = Math.ceil((new Date(booking.pickupDate) - new Date()) / (1000 * 60 * 60 * 24));

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('fr-FR', {
      weekday: 'short',
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatTime = (dateString) => {
    return new Date(dateString)?.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-2 hover:shadow-elevation-3 transition-shadow">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <Image
              src={booking?.vehicle?.image}
              alt={booking?.vehicle?.name}
              className="w-16 h-12 rounded-md object-cover"
            />
            <div>
              <h3 className="font-semibold text-foreground">{booking?.vehicle?.name}</h3>
              <p className="text-sm text-muted-foreground">{booking?.vehicle?.category}</p>
              <div className="flex items-center space-x-2 mt-1">
                <span className={`px-2 py-1 text-xs rounded-full border ${statusConfig?.bgClass}`}>
                  <Icon name={statusConfig?.icon} size={12} className="inline mr-1" />
                  {statusConfig?.label}
                </span>
                {isUpcoming && daysUntilPickup <= 7 && (
                  <span className="px-2 py-1 text-xs rounded-full bg-accent/10 text-accent border border-accent/20">
                    Dans {daysUntilPickup} jour{daysUntilPickup > 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onMessageClick(booking)}
              className="text-success hover:bg-success/10"
            >
              <Icon name="MessageCircle" size={16} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
            </Button>
          </div>
        </div>
      </div>
      {/* Quick Info */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Prise en charge</p>
            <p className="font-medium text-foreground">{formatDate(booking?.pickupDate)}</p>
            <p className="text-muted-foreground">{formatTime(booking?.pickupDate)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Retour</p>
            <p className="font-medium text-foreground">{formatDate(booking?.returnDate)}</p>
            <p className="text-muted-foreground">{formatTime(booking?.returnDate)}</p>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="MapPin" size={16} className="text-muted-foreground" />
            <span className="text-sm text-foreground">{booking?.pickupLocation}</span>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold text-foreground">{booking?.totalPrice}€</p>
            <p className="text-xs text-muted-foreground">
              {booking?.paymentStatus === 'secured' ? 'Paiement sécurisé' : 'Paiement en attente'}
            </p>
          </div>
        </div>
      </div>
      {/* Expanded Details */}
      {isExpanded && (
        <div className="border-t border-border animate-slide-down">
          {/* Booking Timeline */}
          <div className="p-4 border-b border-border">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="Clock" size={16} className="mr-2" />
              Progression de la réservation
            </h4>
            <div className="space-y-3">
              {[
                { status: 'confirmed', label: 'Réservation confirmée', completed: true },
                { status: 'prepared', label: 'Véhicule préparé', completed: booking?.status !== 'confirmed' },
                { status: 'active', label: 'Prise en charge', completed: ['active', 'completed']?.includes(booking?.status) },
                { status: 'completed', label: 'Retour effectué', completed: booking?.status === 'completed' }
              ]?.map((step, index) => (
                <div key={step?.status} className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    step?.completed ? 'bg-success' : 'bg-muted border-2 border-muted-foreground'
                  }`}></div>
                  <span className={`text-sm ${
                    step?.completed ? 'text-foreground font-medium' : 'text-muted-foreground'
                  }`}>
                    {step?.label}
                  </span>
                  {step?.completed && (
                    <Icon name="Check" size={14} className="text-success" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Location Details */}
          <div className="p-4 border-b border-border">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="MapPin" size={16} className="mr-2" />
              Lieux de prise en charge et retour
            </h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-foreground">{booking?.pickupLocation}</p>
                  <p className="text-sm text-muted-foreground">{booking?.pickupAddress}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(booking?.pickupDate)} à {formatTime(booking?.pickupDate)}
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-error rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-foreground">{booking?.returnLocation}</p>
                  <p className="text-sm text-muted-foreground">{booking?.returnAddress}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(booking?.returnDate)} à {formatTime(booking?.returnDate)}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Vehicle Details */}
          <div className="p-4 border-b border-border">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="Car" size={16} className="mr-2" />
              Détails du véhicule
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Modèle</p>
                <p className="font-medium text-foreground">{booking?.vehicle?.name}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Catégorie</p>
                <p className="font-medium text-foreground">{booking?.vehicle?.category}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Transmission</p>
                <p className="font-medium text-foreground">{booking?.vehicle?.transmission}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Carburant</p>
                <p className="font-medium text-foreground">{booking?.vehicle?.fuel}</p>
              </div>
            </div>
            {booking?.vehicle?.features && (
              <div className="mt-3">
                <p className="text-muted-foreground text-sm mb-2">Équipements inclus</p>
                <div className="flex flex-wrap gap-2">
                  {booking?.vehicle?.features?.map((feature, index) => (
                    <span key={index} className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded">
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Contact Information */}
          {userRole === 'agency' && booking?.clientInfo && (
            <div className="p-4 border-b border-border">
              <h4 className="font-medium text-foreground mb-3 flex items-center">
                <Icon name="User" size={16} className="mr-2" />
                Informations client
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Nom</span>
                  <span className="font-medium text-foreground">{booking?.clientInfo?.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Téléphone</span>
                  <span className="font-medium text-foreground">{booking?.clientInfo?.phone}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Email</span>
                  <span className="font-medium text-foreground">{booking?.clientInfo?.email}</span>
                </div>
              </div>
            </div>
          )}

          {/* Agency Information */}
          {userRole === 'client' && booking?.agencyInfo && (
            <div className="p-4 border-b border-border">
              <h4 className="font-medium text-foreground mb-3 flex items-center">
                <Icon name="Building" size={16} className="mr-2" />
                Informations agence
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Agence</span>
                  <span className="font-medium text-foreground">{booking?.agencyInfo?.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Contact</span>
                  <span className="font-medium text-foreground">{booking?.agencyInfo?.phone}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-muted-foreground">Note</span>
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} className="text-warning fill-current" />
                    <span className="font-medium text-foreground">{booking?.agencyInfo?.rating}</span>
                    <span className="text-muted-foreground">({booking?.agencyInfo?.reviews} avis)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="p-4">
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onViewDetails(booking)}
              >
                <Icon name="Eye" size={16} />
                Voir détails
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onMessageClick(booking)}
                className="text-success hover:bg-success/10"
              >
                <Icon name="MessageCircle" size={16} />
                WhatsApp
              </Button>

              {booking?.status === 'confirmed' && isUpcoming && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onModifyBooking(booking)}
                >
                  <Icon name="Edit" size={16} />
                  Modifier
                </Button>
              )}

              {userRole === 'agency' && booking?.status === 'confirmed' && (
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => onStatusUpdate(booking?.id, 'prepared')}
                >
                  <Icon name="Car" size={16} />
                  Marquer préparé
                </Button>
              )}

              {['confirmed', 'prepared']?.includes(booking?.status) && isUpcoming && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => onCancelBooking(booking)}
                >
                  <Icon name="X" size={16} />
                  Annuler
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingCard;