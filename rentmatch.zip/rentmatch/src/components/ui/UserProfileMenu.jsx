import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const UserProfileMenu = ({ 
  user = {}, 
  userRole = 'client',
  onLogout,
  onRoleSwitch 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  // Default user data
  const userData = {
    name: user?.name || (userRole === 'agency' ? 'Agence Immobilière' : 'Utilisateur'),
    email: user?.email || 'user@rentmatch.fr',
    avatar: user?.avatar || null,
    verified: user?.verified || false,
    memberSince: user?.memberSince || '2024',
    ...user
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    setIsOpen(false);
    if (onLogout) {
      onLogout();
    } else {
      // Default logout behavior
      localStorage.removeItem('authToken');
      navigate('/client-registration-login');
    }
  };

  const handleMenuItemClick = (path) => {
    setIsOpen(false);
    if (path) navigate(path);
  };

  const getRoleDisplayName = (role) => {
    switch (role) {
      case 'agency': return 'Professionnel';
      case 'client': return 'Particulier';
      default: return 'Utilisateur';
    }
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'agency': return 'Building';
      case 'client': return 'User';
      default: return 'User';
    }
  };

  const menuItems = [
    {
      section: 'Compte',
      items: [
        {
          label: 'Mon Profil',
          icon: 'User',
          path: '/client-registration-login',
          description: 'Gérer vos informations personnelles'
        },
        {
          label: 'Paramètres',
          icon: 'Settings',
          path: '/settings',
          description: 'Préférences et configuration'
        },
        {
          label: 'Sécurité',
          icon: 'Shield',
          path: '/security',
          description: 'Mot de passe et authentification'
        }
      ]
    },
    {
      section: 'Activité',
      items: userRole === 'agency' ? [
        {
          label: 'Tableau de bord',
          icon: 'BarChart3',
          path: '/agency-dashboard',
          description: 'Vue d\'ensemble de votre activité'
        },
        {
          label: 'Demandes reçues',
          icon: 'Inbox',
          path: '/live-offers-dashboard',
          description: 'Gérer les demandes clients'
        },
        {
          label: 'Statistiques',
          icon: 'TrendingUp',
          path: '/analytics',
          description: 'Performance et métriques'
        }
      ] : [
        {
          label: 'Mes Demandes',
          icon: 'Search',
          path: '/create-rental-demand',
          description: 'Créer et gérer vos demandes'
        },
        {
          label: 'Offres Reçues',
          icon: 'Home',
          path: '/live-offers-dashboard',
          description: 'Consulter les offres disponibles'
        },
        {
          label: 'Historique',
          icon: 'History',
          path: '/history',
          description: 'Vos réservations passées'
        }
      ]
    },
    {
      section: 'Support',
      items: [
        {
          label: 'Centre d\'aide',
          icon: 'HelpCircle',
          path: '/help',
          description: 'FAQ et guides d\'utilisation'
        },
        {
          label: 'Contacter le support',
          icon: 'MessageCircle',
          path: '/contact',
          description: 'Obtenir de l\'aide personnalisée'
        }
      ]
    }
  ];

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-3 px-3 py-2 h-auto focus-ring"
      >
        {/* Avatar */}
        <div className="relative">
          {userData?.avatar ? (
            <img
              src={userData?.avatar}
              alt={userData?.name}
              className="w-8 h-8 rounded-full object-cover"
            />
          ) : (
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <Icon name={getRoleIcon(userRole)} size={16} color="white" />
            </div>
          )}
          {userData?.verified && (
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-success rounded-full flex items-center justify-center">
              <Icon name="Check" size={10} color="white" />
            </div>
          )}
        </div>

        {/* User Info */}
        <div className="hidden sm:block text-left">
          <p className="text-sm font-medium text-foreground truncate max-w-32">
            {userData?.name}
          </p>
          <p className="text-xs text-muted-foreground">
            {getRoleDisplayName(userRole)}
          </p>
        </div>

        <Icon name="ChevronDown" size={16} className="text-muted-foreground" />
      </Button>
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-80 bg-popover border border-border rounded-lg shadow-elevation-3 animate-slide-down z-dropdown">
          {/* Header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="relative">
                {userData?.avatar ? (
                  <img
                    src={userData?.avatar}
                    alt={userData?.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Icon name={getRoleIcon(userRole)} size={20} color="white" />
                  </div>
                )}
                {userData?.verified && (
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-success rounded-full flex items-center justify-center">
                    <Icon name="Check" size={12} color="white" />
                  </div>
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground truncate">{userData?.name}</p>
                <p className="text-sm text-muted-foreground truncate">{userData?.email}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <span className={`px-2 py-0.5 text-xs rounded-full ${
                    userRole === 'agency' ?'bg-primary/10 text-primary' :'bg-secondary/10 text-secondary'
                  }`}>
                    {getRoleDisplayName(userRole)}
                  </span>
                  {userData?.verified && (
                    <span className="px-2 py-0.5 text-xs rounded-full bg-success/10 text-success">
                      Vérifié
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Menu Sections */}
          <div className="max-h-96 overflow-y-auto">
            {menuItems?.map((section, sectionIndex) => (
              <div key={section?.section}>
                <div className="px-4 py-2 bg-muted/30">
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    {section?.section}
                  </h4>
                </div>
                
                {section?.items?.map((item) => (
                  <button
                    key={item?.label}
                    onClick={() => handleMenuItemClick(item?.path)}
                    className="w-full flex items-center space-x-3 px-4 py-3 hover:bg-muted transition-colors text-left"
                  >
                    <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                      <Icon name={item?.icon} size={16} className="text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{item?.label}</p>
                      <p className="text-xs text-muted-foreground truncate">{item?.description}</p>
                    </div>
                    <Icon name="ChevronRight" size={14} className="text-muted-foreground" />
                  </button>
                ))}
                
                {sectionIndex < menuItems?.length - 1 && (
                  <div className="border-b border-border"></div>
                )}
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="border-t border-border p-2">
            {onRoleSwitch && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setIsOpen(false);
                  onRoleSwitch();
                }}
                className="w-full justify-start mb-1"
              >
                <Icon name="RefreshCw" size={16} />
                <span className="ml-2">
                  Passer en mode {userRole === 'agency' ? 'Client' : 'Agence'}
                </span>
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="w-full justify-start text-error hover:bg-error/10 hover:text-error"
            >
              <Icon name="LogOut" size={16} />
              <span className="ml-2">Déconnexion</span>
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserProfileMenu;