import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FinancialSummaryCard = ({ summary, onExportReport, onViewTransactions }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    })?.format(amount);
  };

  const periods = [
    { key: 'week', label: 'Cette semaine' },
    { key: 'month', label: 'Ce mois' },
    { key: 'quarter', label: 'Ce trimestre' },
    { key: 'year', label: 'Cette année' }
  ];

  const currentData = summary?.[selectedPeriod] || summary?.month;

  const getChangeColor = (change) => {
    if (change > 0) return 'text-success';
    if (change < 0) return 'text-error';
    return 'text-muted-foreground';
  };

  const getChangeIcon = (change) => {
    if (change > 0) return 'TrendingUp';
    if (change < 0) return 'TrendingDown';
    return 'Minus';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-foreground">Résumé financier</h2>
          <p className="text-sm text-muted-foreground">
            Vue d'ensemble de vos transactions et soldes
          </p>
        </div>
        
        {/* Period Selector */}
        <div className="flex items-center space-x-1 bg-muted/30 rounded-lg p-1">
          {periods?.map((period) => (
            <button
              key={period?.key}
              onClick={() => setSelectedPeriod(period?.key)}
              className={`px-3 py-1.5 text-sm rounded-md transition-colors ${
                selectedPeriod === period?.key
                  ? 'bg-primary text-primary-foreground font-medium'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {period?.label}
            </button>
          ))}
        </div>
      </div>
      {/* Main Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Total Balance */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Icon name="Wallet" size={20} className="text-primary" />
            <span className="text-xs text-primary font-medium">SOLDE TOTAL</span>
          </div>
          <p className="text-2xl font-bold text-foreground mb-1">
            {formatAmount(currentData?.totalBalance)}
          </p>
          <div className="flex items-center space-x-1">
            <Icon 
              name={getChangeIcon(currentData?.balanceChange)} 
              size={14} 
              className={getChangeColor(currentData?.balanceChange)} 
            />
            <span className={`text-sm ${getChangeColor(currentData?.balanceChange)}`}>
              {Math.abs(currentData?.balanceChange)?.toFixed(1)}%
            </span>
            <span className="text-xs text-muted-foreground">vs période précédente</span>
          </div>
        </div>

        {/* Escrow Holdings */}
        <div className="bg-warning/5 border border-warning/20 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Icon name="Shield" size={20} className="text-warning" />
            <span className="text-xs text-warning font-medium">SÉQUESTRE</span>
          </div>
          <p className="text-2xl font-bold text-foreground mb-1">
            {formatAmount(currentData?.escrowHoldings)}
          </p>
          <p className="text-sm text-muted-foreground">
            {currentData?.activeEscrows} transaction{currentData?.activeEscrows > 1 ? 's' : ''} active{currentData?.activeEscrows > 1 ? 's' : ''}
          </p>
        </div>

        {/* Total Spent */}
        <div className="bg-error/5 border border-error/20 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Icon name="ArrowUpRight" size={20} className="text-error" />
            <span className="text-xs text-error font-medium">DÉPENSES</span>
          </div>
          <p className="text-2xl font-bold text-foreground mb-1">
            {formatAmount(currentData?.totalSpent)}
          </p>
          <div className="flex items-center space-x-1">
            <Icon 
              name={getChangeIcon(currentData?.spentChange)} 
              size={14} 
              className={getChangeColor(currentData?.spentChange)} 
            />
            <span className={`text-sm ${getChangeColor(currentData?.spentChange)}`}>
              {Math.abs(currentData?.spentChange)?.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Refunds */}
        <div className="bg-success/5 border border-success/20 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Icon name="RotateCcw" size={20} className="text-success" />
            <span className="text-xs text-success font-medium">REMBOURSEMENTS</span>
          </div>
          <p className="text-2xl font-bold text-foreground mb-1">
            {formatAmount(currentData?.totalRefunds)}
          </p>
          <p className="text-sm text-muted-foreground">
            {currentData?.refundCount} remboursement{currentData?.refundCount > 1 ? 's' : ''}
          </p>
        </div>
      </div>
      {/* Transaction Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Payment Methods Usage */}
        <div>
          <h3 className="font-semibold text-foreground mb-3 flex items-center">
            <Icon name="CreditCard" size={18} className="mr-2" />
            Utilisation des méthodes de paiement
          </h3>
          <div className="space-y-3">
            {currentData?.paymentMethodsUsage?.map((method, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: method?.color }}></div>
                  <span className="text-sm text-foreground">{method?.name}</span>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">
                    {formatAmount(method?.amount)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {method?.percentage}% • {method?.count} transaction{method?.count > 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h3 className="font-semibold text-foreground mb-3 flex items-center">
            <Icon name="Activity" size={18} className="mr-2" />
            Activité récente
          </h3>
          <div className="space-y-3">
            {currentData?.recentActivity?.slice(0, 4)?.map((activity, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  activity?.type === 'payment' ? 'bg-error/10 text-error' :
                  activity?.type === 'refund'? 'bg-success/10 text-success' : 'bg-primary/10 text-primary'
                }`}>
                  <Icon 
                    name={
                      activity?.type === 'payment' ? 'ArrowUpRight' :
                      activity?.type === 'refund'? 'ArrowDownLeft' : 'Shield'
                    } 
                    size={14} 
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {activity?.description}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(activity.date)?.toLocaleDateString('fr-FR', {
                      day: '2-digit',
                      month: '2-digit',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
                <p className={`text-sm font-medium ${
                  activity?.type === 'payment' ? 'text-error' :
                  activity?.type === 'refund'? 'text-success' : 'text-foreground'
                }`}>
                  {activity?.type === 'payment' ? '-' : activity?.type === 'refund' ? '+' : ''}
                  {formatAmount(Math.abs(activity?.amount))}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Actions */}
      <div className="flex items-center justify-between pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onViewTransactions?.('all')}
          >
            <Icon name="List" size={16} className="mr-1" />
            Toutes les transactions
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onViewTransactions?.('escrow')}
          >
            <Icon name="Shield" size={16} className="mr-1" />
            Séquestres actifs
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onExportReport?.(selectedPeriod)}
          >
            <Icon name="Download" size={16} className="mr-1" />
            Exporter rapport
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => onViewTransactions?.('detailed')}
          >
            Rapport détaillé
            <Icon name="ArrowRight" size={16} className="ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FinancialSummaryCard;