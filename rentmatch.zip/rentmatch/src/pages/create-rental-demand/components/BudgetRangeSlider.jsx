import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const BudgetRangeSlider = ({ 
  minBudget = 25, 
  maxBudget = 200, 
  onBudgetChange,
  currency = 'EUR',
  error 
}) => {
  const [range, setRange] = useState([minBudget, maxBudget]);
  const [isDragging, setIsDragging] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);

  const absoluteMin = 20;
  const absoluteMax = 500;

  // Budget suggestions based on categories
  const budgetSuggestions = [
    { label: 'Économique', range: [25, 45], icon: 'DollarSign', color: 'success' },
    { label: 'Standard', range: [45, 75], icon: 'DollarSign', color: 'primary' },
    { label: 'Confort', range: [75, 120], icon: 'DollarSign', color: 'secondary' },
    { label: 'Premium', range: [120, 200], icon: 'Crown', color: 'warning' },
    { label: 'Luxe', range: [200, 350], icon: 'Crown', color: 'accent' }
  ];

  useEffect(() => {
    onBudgetChange(range);
  }, [range, onBudgetChange]);

  const handleRangeChange = (newRange) => {
    setRange(newRange);
  };

  const handleSuggestionClick = (suggestionRange) => {
    setRange(suggestionRange);
    setShowSuggestions(false);
  };

  const formatCurrency = (amount) => {
    const symbol = currency === 'EUR' ? '€' : '$';
    return `${amount}${symbol}`;
  };

  const calculatePercentage = (value) => {
    return ((value - absoluteMin) / (absoluteMax - absoluteMin)) * 100;
  };

  const handleSliderChange = (e, index) => {
    const value = parseInt(e?.target?.value);
    const newRange = [...range];
    newRange[index] = value;
    
    // Ensure min doesn't exceed max and vice versa
    if (index === 0 && value >= newRange?.[1]) {
      newRange[1] = value + 10;
    } else if (index === 1 && value <= newRange?.[0]) {
      newRange[0] = value - 10;
    }
    
    setRange(newRange);
  };

  const getDailyEstimate = () => {
    const avgBudget = (range?.[0] + range?.[1]) / 2;
    return {
      daily: avgBudget,
      weekly: Math.round(avgBudget * 7 * 0.85), // 15% discount for weekly
      monthly: Math.round(avgBudget * 30 * 0.7) // 30% discount for monthly
    };
  };

  const estimates = getDailyEstimate();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Budget par jour</h3>
        <p className="text-sm text-muted-foreground">
          Définissez votre fourchette de prix pour attirer les meilleures offres
        </p>
      </div>
      {error && (
        <div className="text-sm text-error bg-error/10 border border-error/20 rounded-md p-3">
          {error}
        </div>
      )}
      {/* Budget Range Display */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Minimum</p>
            <p className="text-2xl font-bold text-foreground">{formatCurrency(range?.[0])}</p>
          </div>
          <div className="flex items-center space-x-2 text-muted-foreground">
            <div className="w-8 h-px bg-border"></div>
            <Icon name="ArrowRight" size={16} />
            <div className="w-8 h-px bg-border"></div>
          </div>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Maximum</p>
            <p className="text-2xl font-bold text-foreground">{formatCurrency(range?.[1])}</p>
          </div>
        </div>

        {/* Custom Range Slider */}
        <div className="relative h-6 mb-4">
          <div className="absolute top-1/2 transform -translate-y-1/2 w-full h-2 bg-border rounded-full"></div>
          <div 
            className="absolute top-1/2 transform -translate-y-1/2 h-2 bg-primary rounded-full"
            style={{
              left: `${calculatePercentage(range?.[0])}%`,
              width: `${calculatePercentage(range?.[1]) - calculatePercentage(range?.[0])}%`
            }}
          ></div>
          
          {/* Min Slider */}
          <input
            type="range"
            min={absoluteMin}
            max={absoluteMax}
            value={range?.[0]}
            onChange={(e) => handleSliderChange(e, 0)}
            className="absolute top-0 w-full h-6 opacity-0 cursor-pointer"
          />
          
          {/* Max Slider */}
          <input
            type="range"
            min={absoluteMin}
            max={absoluteMax}
            value={range?.[1]}
            onChange={(e) => handleSliderChange(e, 1)}
            className="absolute top-0 w-full h-6 opacity-0 cursor-pointer"
          />
          
          {/* Min Handle */}
          <div 
            className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2 w-6 h-6 bg-primary border-2 border-background rounded-full shadow-md cursor-pointer"
            style={{ left: `${calculatePercentage(range?.[0])}%` }}
          ></div>
          
          {/* Max Handle */}
          <div 
            className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2 w-6 h-6 bg-primary border-2 border-background rounded-full shadow-md cursor-pointer"
            style={{ left: `${calculatePercentage(range?.[1])}%` }}
          ></div>
        </div>

        {/* Manual Input */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">
              Budget minimum
            </label>
            <div className="relative">
              <input
                type="number"
                min={absoluteMin}
                max={range?.[1] - 10}
                value={range?.[0]}
                onChange={(e) => handleRangeChange([parseInt(e?.target?.value) || absoluteMin, range?.[1]])}
                className="w-full px-3 py-2 pr-8 border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                {currency === 'EUR' ? '€' : '$'}
              </span>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">
              Budget maximum
            </label>
            <div className="relative">
              <input
                type="number"
                min={range?.[0] + 10}
                max={absoluteMax}
                value={range?.[1]}
                onChange={(e) => handleRangeChange([range?.[0], parseInt(e?.target?.value) || absoluteMax])}
                className="w-full px-3 py-2 pr-8 border border-border rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                {currency === 'EUR' ? '€' : '$'}
              </span>
            </div>
          </div>
        </div>
      </div>
      {/* Budget Suggestions */}
      {showSuggestions && (
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground flex items-center">
            <Icon name="Target" size={16} className="mr-2 text-primary" />
            Suggestions de budget
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {budgetSuggestions?.map((suggestion) => {
              const isSelected = range?.[0] === suggestion?.range?.[0] && range?.[1] === suggestion?.range?.[1];
              return (
                <button
                  key={suggestion?.label}
                  onClick={() => handleSuggestionClick(suggestion?.range)}
                  className={`flex items-center space-x-3 p-3 rounded-lg border transition-all text-left ${
                    isSelected 
                      ? `border-${suggestion?.color} bg-${suggestion?.color}/10 text-${suggestion?.color}`
                      : 'border-border hover:border-primary/50 hover:bg-muted/50'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    isSelected 
                      ? `bg-${suggestion?.color}/20 text-${suggestion?.color}`
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    <Icon name={suggestion?.icon} size={16} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{suggestion?.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatCurrency(suggestion?.range?.[0])} - {formatCurrency(suggestion?.range?.[1])}
                    </p>
                  </div>
                  {isSelected && (
                    <Icon name="Check" size={16} className={`text-${suggestion?.color}`} />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
      {/* Cost Estimates */}
      <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
        <h4 className="text-sm font-medium text-primary mb-3 flex items-center">
          <Icon name="Calculator" size={16} className="mr-2" />
          Estimation des coûts
        </h4>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-xs text-muted-foreground">Par jour</p>
            <p className="text-lg font-semibold text-foreground">
              {formatCurrency(estimates?.daily)}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Par semaine</p>
            <p className="text-lg font-semibold text-foreground">
              {formatCurrency(estimates?.weekly)}
            </p>
            <p className="text-xs text-success">-15%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Par mois</p>
            <p className="text-lg font-semibold text-foreground">
              {formatCurrency(estimates?.monthly)}
            </p>
            <p className="text-xs text-success">-30%</p>
          </div>
        </div>
      </div>
      {/* Budget Tips */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-foreground">Conseils pour optimiser votre budget</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Un budget flexible attire plus d'offres des agences</li>
              <li>• Les réservations longues bénéficient de tarifs dégressifs</li>
              <li>• Évitez les périodes de forte demande pour économiser</li>
              <li>• Comparez les options avec/sans franchise</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetRangeSlider;