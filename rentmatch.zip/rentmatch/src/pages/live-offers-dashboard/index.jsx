import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Header from '../../components/ui/Header';
import DemandSelector from './components/DemandSelector';
import OfferCard from './components/OfferCard';
import OfferFilters from './components/OfferFilters';
import OfferComparison from './components/OfferComparison';
import LiveNotifications from './components/LiveNotifications';
import OfferStats from './components/OfferStats';

const LiveOffersDashboard = () => {
  const navigate = useNavigate();
  const [selectedDemand, setSelectedDemand] = useState(null);
  const [offers, setOffers] = useState([]);
  const [filteredOffers, setFilteredOffers] = useState([]);
  const [comparedOffers, setComparedOffers] = useState([]);
  const [showComparison, setShowComparison] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    priceMin: '',
    priceMax: '',
    vehicleType: 'all',
    agencyRating: 'all',
    maxDistance: '',
    sortBy: 'newest',
    showExpired: false,
    verifiedOnly: false,
    instantBooking: false
  });

  // Mock data
  const mockActiveDemands = [
    {
      id: 1,
      location: "Paris Centre",
      startDate: "2024-08-20",
      endDate: "2024-08-25",
      vehicleType: "sedan",
      budget: 45,
      offerCount: 8
    },
    {
      id: 2,
      location: "Lyon Gare",
      startDate: "2024-08-22",
      endDate: "2024-08-24",
      vehicleType: "compact",
      budget: 35,
      offerCount: 5
    },
    {
      id: 3,
      location: "Marseille Aéroport",
      startDate: "2024-08-25",
      endDate: "2024-08-30",
      vehicleType: "suv",
      budget: 65,
      offerCount: 12
    }
  ];

  const mockOffers = [
    {
      id: 1,
      agency: {
        name: "EuroRent Pro",
        rating: 4.8,
        reliabilityScore: 95,
        distance: 2.3,
        phone: "+33 1 42 86 17 20",
        email: "contact@eurorentpro.fr"
      },
      vehicle: {
        brand: "Peugeot",
        model: "308",
        year: 2023,
        transmission: "Automatique",
        fuel: "Essence",
        images: [
          "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400",
          "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400"
        ]
      },
      pricing: {
        dailyRate: 42,
        totalAmount: 210,
        originalAmount: 230,
        discount: 20,
        duration: 5,
        baseAmount: 180,
        insurance: 15,
        extras: 15
      },
      features: [
        "GPS inclus",
        "Assurance tous risques",
        "Kilométrage illimité",
        "Carburant inclus"
      ],
      terms: "Permis de conduire valide depuis plus de 2 ans requis. Caution de 500€ bloquée sur carte bancaire.",
      cancellationPolicy: "Annulation gratuite jusqu\'à 24h avant la prise en charge. Remboursement partiel ensuite.",
      expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000)?.toISOString(), // 2 hours from now
      createdAt: new Date(Date.now() - 15 * 60 * 1000)?.toISOString()
    },
    {
      id: 2,
      agency: {
        name: "CityDrive",
        rating: 4.5,
        reliabilityScore: 88,
        distance: 1.8,
        phone: "+33 1 45 23 67 89",
        email: "info@citydrive.fr"
      },
      vehicle: {
        brand: "Renault",
        model: "Clio",
        year: 2022,
        transmission: "Manuelle",
        fuel: "Diesel",
        images: [
          "https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=400",
          "https://images.unsplash.com/photo-1571607388263-1044f9ea01dd?w=400"
        ]
      },
      pricing: {
        dailyRate: 38,
        totalAmount: 190,
        originalAmount: 190,
        discount: 0,
        duration: 5,
        baseAmount: 170,
        insurance: 10,
        extras: 10
      },
      features: [
        "GPS inclus",
        "Assurance tiers",
        "200km/jour inclus"
      ],
      terms: "Permis de conduire valide requis. Caution de 300€.",
      cancellationPolicy: "Annulation gratuite jusqu\'à 48h avant.",
      expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000)?.toISOString(),
      createdAt: new Date(Date.now() - 30 * 60 * 1000)?.toISOString()
    },
    {
      id: 3,
      agency: {
        name: "Premium Cars",
        rating: 4.9,
        reliabilityScore: 97,
        distance: 3.5,
        phone: "+33 1 56 78 90 12",
        email: "booking@premiumcars.fr"
      },
      vehicle: {
        brand: "BMW",
        model: "Série 3",
        year: 2024,
        transmission: "Automatique",
        fuel: "Hybride",
        images: [
          "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=400",
          "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=400"
        ]
      },
      pricing: {
        dailyRate: 75,
        totalAmount: 375,
        originalAmount: 400,
        discount: 25,
        duration: 5,
        baseAmount: 325,
        insurance: 25,
        extras: 25
      },
      features: [
        "GPS premium",
        "Assurance tous risques",
        "Kilométrage illimité",
        "Conciergerie 24/7",
        "Véhicule de remplacement"
      ],
      terms: "Permis de conduire valide depuis plus de 3 ans. Caution de 1000€.",
      cancellationPolicy: "Annulation gratuite jusqu\'à 12h avant.",
      expiresAt: new Date(Date.now() + 6 * 60 * 60 * 1000)?.toISOString(),
      createdAt: new Date(Date.now() - 45 * 60 * 1000)?.toISOString()
    }
  ];

  const mockNotifications = [
    {
      id: 1,
      type: 'new_offer',
      title: 'Nouvelle offre reçue !',
      message: 'EuroRent Pro a répondu à votre demande',
      timestamp: new Date(),
      offerId: 1,
      offerDetails: {
        agency: 'EuroRent Pro',
        price: 42,
        vehicle: 'Peugeot 308'
      }
    }
  ];

  // Initialize data
  useEffect(() => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setSelectedDemand(mockActiveDemands?.[0]);
      setOffers(mockOffers);
      setFilteredOffers(mockOffers);
      setNotifications(mockNotifications);
      setIsLoading(false);
    }, 1000);
  }, []);

  // Filter offers based on current filters
  useEffect(() => {
    let filtered = [...offers];

    // Price filter
    if (filters?.priceMin) {
      filtered = filtered?.filter(offer => offer?.pricing?.dailyRate >= parseInt(filters?.priceMin));
    }
    if (filters?.priceMax) {
      filtered = filtered?.filter(offer => offer?.pricing?.dailyRate <= parseInt(filters?.priceMax));
    }

    // Vehicle type filter
    if (filters?.vehicleType !== 'all') {
      // This would normally filter by vehicle type
    }

    // Agency rating filter
    if (filters?.agencyRating !== 'all') {
      const minRating = parseFloat(filters?.agencyRating);
      filtered = filtered?.filter(offer => offer?.agency?.rating >= minRating);
    }

    // Distance filter
    if (filters?.maxDistance) {
      filtered = filtered?.filter(offer => offer?.agency?.distance <= parseInt(filters?.maxDistance));
    }

    // Verified only filter
    if (filters?.verifiedOnly) {
      filtered = filtered?.filter(offer => offer?.agency?.reliabilityScore >= 90);
    }

    // Show expired filter
    if (!filters?.showExpired) {
      filtered = filtered?.filter(offer => new Date(offer.expiresAt) > new Date());
    }

    // Sort offers
    switch (filters?.sortBy) {
      case 'price_asc':
        filtered?.sort((a, b) => a?.pricing?.dailyRate - b?.pricing?.dailyRate);
        break;
      case 'price_desc':
        filtered?.sort((a, b) => b?.pricing?.dailyRate - a?.pricing?.dailyRate);
        break;
      case 'rating':
        filtered?.sort((a, b) => b?.agency?.rating - a?.agency?.rating);
        break;
      case 'distance':
        filtered?.sort((a, b) => a?.agency?.distance - b?.agency?.distance);
        break;
      case 'time_remaining':
        filtered?.sort((a, b) => new Date(a.expiresAt) - new Date(b.expiresAt));
        break;
      case 'newest':
      default:
        filtered?.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
    }

    setFilteredOffers(filtered);
  }, [offers, filters]);

  const handleDemandSelect = (demand) => {
    setSelectedDemand(demand);
    // In real app, this would fetch offers for the selected demand
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleResetFilters = () => {
    setFilters({
      priceMin: '',
      priceMax: '',
      vehicleType: 'all',
      agencyRating: 'all',
      maxDistance: '',
      sortBy: 'newest',
      showExpired: false,
      verifiedOnly: false,
      instantBooking: false
    });
  };

  const handleToggleComparison = (offerId) => {
    setComparedOffers(prev => {
      const isAlreadyCompared = prev?.find(offer => offer?.id === offerId);
      
      if (isAlreadyCompared) {
        return prev?.filter(offer => offer?.id !== offerId);
      } else if (prev?.length < 3) {
        const offerToAdd = offers?.find(offer => offer?.id === offerId);
        return [...prev, offerToAdd];
      }
      
      return prev;
    });
  };

  const handleRemoveFromComparison = (offerId) => {
    setComparedOffers(prev => prev?.filter(offer => offer?.id !== offerId));
  };

  const handleAcceptOffer = (offer, paymentMethod) => {
    console.log('Accepting offer:', offer?.id, 'Payment method:', paymentMethod);
    
    if (paymentMethod === 'escrow') {
      navigate('/payment-escrow-center', { 
        state: { 
          offer, 
          demand: selectedDemand,
          paymentMethod: 'escrow'
        } 
      });
    } else {
      navigate('/booking-management', { 
        state: { 
          offer, 
          demand: selectedDemand,
          paymentMethod: 'location'
        } 
      });
    }
  };

  const handleRejectOffer = (offerId) => {
    setOffers(prev => prev?.filter(offer => offer?.id !== offerId));
    console.log('Offer rejected:', offerId);
  };

  const handleViewDetails = (offer) => {
    console.log('View offer details:', offer?.id);
    // Could open a modal or navigate to details page
  };

  const handleNotificationDismiss = (notificationId) => {
    setNotifications(prev => prev?.filter(n => n?.id !== notificationId));
  };

  const handleViewOffer = (offerId) => {
    const offerElement = document.getElementById(`offer-${offerId}`);
    if (offerElement) {
      offerElement?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Calculate stats
  const stats = {
    totalOffers: offers?.length,
    newOffers: offers?.filter(offer => 
      new Date() - new Date(offer.createdAt) < 60 * 60 * 1000 // Less than 1 hour old
    )?.length,
    expiringOffers: offers?.filter(offer => 
      new Date(offer.expiresAt) - new Date() < 2 * 60 * 60 * 1000 // Less than 2 hours remaining
    )?.length,
    averagePrice: Math.round(offers?.reduce((sum, offer) => sum + offer?.pricing?.dailyRate, 0) / offers?.length) || 0,
    bestPrice: Math.min(...offers?.map(offer => offer?.pricing?.dailyRate)) || 0,
    responseRate: 85
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole="client" notificationCount={3} />
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Chargement des offres...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="client" notificationCount={notifications?.length} />
      {/* Live Notifications */}
      <LiveNotifications
        notifications={notifications}
        onDismiss={handleNotificationDismiss}
        onViewOffer={handleViewOffer}
        soundEnabled={true}
      />
      {/* Main Content */}
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Header Section */}
        <div className="mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-2">
                Offres en Direct
              </h1>
              <p className="text-muted-foreground">
                Consultez et comparez les offres reçues pour vos demandes de location
              </p>
            </div>

            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowComparison(!showComparison)}
                disabled={comparedOffers?.length === 0}
              >
                <Icon name="BarChart3" size={16} />
                <span className="ml-2">Comparer ({comparedOffers?.length})</span>
              </Button>
              
              <Button
                variant="default"
                onClick={() => navigate('/create-rental-demand')}
              >
                <Icon name="Plus" size={16} />
                <span className="ml-2">Nouvelle demande</span>
              </Button>
            </div>
          </div>

          {/* Demand Selector */}
          <DemandSelector
            activeDemands={mockActiveDemands}
            selectedDemand={selectedDemand}
            onDemandSelect={handleDemandSelect}
            liveOfferCount={filteredOffers?.length}
          />
        </div>

        {/* Stats */}
        <div className="mb-6">
          <OfferStats {...stats} />
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <OfferFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              onResetFilters={handleResetFilters}
              isOpen={showFilters}
              onToggle={() => setShowFilters(!showFilters)}
            />
          </div>

          {/* Offers List */}
          <div className="lg:col-span-3">
            {filteredOffers?.length === 0 ? (
              <div className="text-center py-12">
                <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Aucune offre trouvée
                </h3>
                <p className="text-muted-foreground mb-6">
                  {selectedDemand 
                    ? "Aucune offre ne correspond à vos critères de recherche." :"Sélectionnez une demande pour voir les offres disponibles."
                  }
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-4">
                  <Button
                    variant="outline"
                    onClick={handleResetFilters}
                  >
                    <Icon name="RotateCcw" size={16} />
                    <span className="ml-2">Réinitialiser les filtres</span>
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => navigate('/create-rental-demand')}
                  >
                    <Icon name="Plus" size={16} />
                    <span className="ml-2">Créer une demande</span>
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredOffers?.map((offer) => (
                  <div key={offer?.id} id={`offer-${offer?.id}`}>
                    <OfferCard
                      offer={offer}
                      onAcceptOffer={handleAcceptOffer}
                      onRejectOffer={handleRejectOffer}
                      onViewDetails={handleViewDetails}
                      onToggleComparison={handleToggleComparison}
                      isInComparison={comparedOffers?.some(o => o?.id === offer?.id)}
                      showComparison={comparedOffers?.length > 0}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Comparison Modal */}
      {showComparison && comparedOffers?.length > 0 && (
        <OfferComparison
          comparedOffers={comparedOffers}
          onRemoveFromComparison={handleRemoveFromComparison}
          onAcceptOffer={handleAcceptOffer}
          onClose={() => setShowComparison(false)}
        />
      )}
    </div>
  );
};

export default LiveOffersDashboard;