import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const QuickStats = ({ stats }) => {
  const statItems = [
    {
      key: 'activeDemands',
      label: 'Demandes actives',
      value: stats?.activeDemands || 0,
      icon: 'Search',
      color: 'text-primary bg-primary/10',
      trend: stats?.demandsChange || 0
    },
    {
      key: 'pendingOffers',
      label: 'Offres en attente',
      value: stats?.pendingOffers || 0,
      icon: 'Clock',
      color: 'text-warning bg-warning/10',
      trend: stats?.offersChange || 0
    },
    {
      key: 'confirmedBookings',
      label: 'Réservations confirmées',
      value: stats?.confirmedBookings || 0,
      icon: 'CheckCircle',
      color: 'text-success bg-success/10',
      trend: stats?.bookingsChange || 0
    },
    {
      key: 'responseRate',
      label: 'Taux de réponse',
      value: `${stats?.responseRate || 0}%`,
      icon: 'TrendingUp',
      color: 'text-secondary bg-secondary/10',
      trend: stats?.responseRateChange || 0
    },
    {
      key: 'avgResponseTime',
      label: 'Temps de réponse moyen',
      value: stats?.avgResponseTime || '0h',
      icon: 'Timer',
      color: 'text-accent bg-accent/10',
      trend: stats?.responseTimeChange || 0
    },
    {
      key: 'monthlyRevenue',
      label: 'Revenus du mois',
      value: `${(stats?.monthlyRevenue || 0)?.toLocaleString('fr-FR')}€`,
      icon: 'DollarSign',
      color: 'text-primary bg-primary/10',
      trend: stats?.revenueChange || 0
    }
  ];

  const getTrendIcon = (trend) => {
    if (trend > 0) return 'TrendingUp';
    if (trend < 0) return 'TrendingDown';
    return 'Minus';
  };

  const getTrendColor = (trend) => {
    if (trend > 0) return 'text-success';
    if (trend < 0) return 'text-error';
    return 'text-muted-foreground';
  };

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="BarChart3" size={20} className="text-primary" />
          <h3 className="font-semibold text-foreground">Statistiques rapides</h3>
        </div>
        <Button variant="ghost" size="sm" className="text-xs">
          <Icon name="RefreshCw" size={14} />
          Actualiser
        </Button>
      </div>
      {/* Stats Grid */}
      <div className="p-4">
        <div className="grid grid-cols-1 gap-4">
          {statItems?.map((stat) => (
            <div
              key={stat?.key}
              className="p-3 rounded-lg border border-border hover:shadow-elevation-1 transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-md flex items-center justify-center ${stat?.color}`}>
                    <Icon name={stat?.icon} size={16} />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{stat?.label}</p>
                    <p className="text-lg font-semibold text-foreground">{stat?.value}</p>
                  </div>
                </div>
                {stat?.trend !== 0 && (
                  <div className={`flex items-center space-x-1 ${getTrendColor(stat?.trend)}`}>
                    <Icon name={getTrendIcon(stat?.trend)} size={12} />
                    <span className="text-xs font-medium">
                      {Math.abs(stat?.trend)}%
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Performance Indicators */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Score de fiabilité</span>
            <div className="flex items-center space-x-2">
              <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-success rounded-full transition-all duration-300"
                  style={{ width: `${stats?.reliabilityScore || 0}%` }}
                ></div>
              </div>
              <span className="font-medium text-foreground">{stats?.reliabilityScore || 0}%</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Taux de conversion</span>
            <div className="flex items-center space-x-2">
              <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary rounded-full transition-all duration-300"
                  style={{ width: `${stats?.conversionRate || 0}%` }}
                ></div>
              </div>
              <span className="font-medium text-foreground">{stats?.conversionRate || 0}%</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Satisfaction client</span>
            <div className="flex items-center space-x-1">
              <Icon name="Star" size={14} className="text-warning" />
              <span className="font-medium text-foreground">
                {(stats?.customerSatisfaction || 0)?.toFixed(1)}/5.0
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickStats;