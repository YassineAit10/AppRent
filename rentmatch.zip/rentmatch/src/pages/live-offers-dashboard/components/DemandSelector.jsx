import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DemandSelector = ({ 
  activeDemands = [], 
  selectedDemand, 
  onDemandSelect,
  liveOfferCount = 0 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const formatDateRange = (startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return `${start?.getDate()}/${start?.getMonth() + 1} - ${end?.getDate()}/${end?.getMonth() + 1}`;
  };

  const getVehicleTypeIcon = (type) => {
    switch (type) {
      case 'compact': return 'Car';
      case 'sedan': return 'Car';
      case 'suv': return 'Truck';
      case 'van': return 'Bus';
      default: return 'Car';
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full sm:w-auto justify-between min-w-80"
      >
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary/10 rounded-md flex items-center justify-center">
            <Icon name={getVehicleTypeIcon(selectedDemand?.vehicleType)} size={16} className="text-primary" />
          </div>
          <div className="text-left">
            <p className="font-medium text-foreground">
              {selectedDemand?.location || 'Sélectionner une demande'}
            </p>
            <p className="text-sm text-muted-foreground">
              {selectedDemand ? formatDateRange(selectedDemand?.startDate, selectedDemand?.endDate) : 'Aucune demande active'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {liveOfferCount > 0 && (
            <span className="px-2 py-1 bg-success text-success-foreground text-xs rounded-full font-medium animate-pulse-gentle">
              {liveOfferCount} offre{liveOfferCount > 1 ? 's' : ''}
            </span>
          )}
          <Icon name="ChevronDown" size={16} />
        </div>
      </Button>
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-lg shadow-elevation-3 animate-slide-down z-dropdown max-h-96 overflow-y-auto">
          <div className="p-3 border-b border-border">
            <h3 className="font-semibold text-foreground flex items-center">
              <Icon name="Search" size={16} className="mr-2" />
              Demandes actives
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {activeDemands?.length} demande{activeDemands?.length > 1 ? 's' : ''} en cours
            </p>
          </div>

          {activeDemands?.length === 0 ? (
            <div className="p-6 text-center">
              <Icon name="Search" size={32} className="text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground mb-3">Aucune demande active</p>
              <Button variant="primary" size="sm" onClick={() => setIsOpen(false)}>
                Créer une demande
                <Icon name="Plus" size={14} className="ml-1" />
              </Button>
            </div>
          ) : (
            <div className="py-2">
              {activeDemands?.map((demand) => (
                <button
                  key={demand?.id}
                  onClick={() => {
                    onDemandSelect(demand);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-3 hover:bg-muted transition-colors ${
                    selectedDemand?.id === demand?.id ? 'bg-primary/5 border-r-2 border-r-primary' : ''
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    selectedDemand?.id === demand?.id ? 'bg-primary text-primary-foreground' : 'bg-muted'
                  }`}>
                    <Icon name={getVehicleTypeIcon(demand?.vehicleType)} size={18} />
                  </div>
                  
                  <div className="flex-1 text-left">
                    <p className="font-medium text-foreground">{demand?.location}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatDateRange(demand?.startDate, demand?.endDate)} • {demand?.vehicleType}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Budget: {demand?.budget}€/jour • {demand?.offerCount || 0} offre{(demand?.offerCount || 0) > 1 ? 's' : ''}
                    </p>
                  </div>

                  {demand?.offerCount > 0 && (
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-success rounded-full animate-pulse-gentle"></div>
                      <span className="text-xs font-medium text-success">{demand?.offerCount}</span>
                    </div>
                  )}
                </button>
              ))}
            </div>
          )}

          <div className="p-3 border-t border-border bg-muted/30">
            <Button variant="ghost" size="sm" fullWidth>
              <Icon name="Plus" size={14} />
              <span className="ml-2">Créer une nouvelle demande</span>
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DemandSelector;