import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const OfferCard = ({ 
  offer, 
  onAcceptOffer, 
  onRejectOffer, 
  onViewDetails,
  onToggleComparison,
  isInComparison = false,
  showComparison = false 
}) => {
  const [timeRemaining, setTimeRemaining] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);

  // Calculate time remaining
  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const expiry = new Date(offer.expiresAt);
      const diff = expiry - now;

      if (diff <= 0) {
        setTimeRemaining('Expiré');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      if (hours > 0) {
        setTimeRemaining(`${hours}h ${minutes}m`);
      } else {
        setTimeRemaining(`${minutes}m`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [offer?.expiresAt]);

  const getReliabilityColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 70) return 'text-warning';
    return 'text-error';
  };

  const getReliabilityBadge = (score) => {
    if (score >= 90) return { label: 'Excellent', color: 'bg-success/10 text-success' };
    if (score >= 70) return { label: 'Bon', color: 'bg-warning/10 text-warning' };
    return { label: 'Moyen', color: 'bg-error/10 text-error' };
  };

  const isExpired = new Date(offer.expiresAt) <= new Date();
  const reliabilityBadge = getReliabilityBadge(offer?.agency?.reliabilityScore);

  return (
    <div className={`bg-card border border-border rounded-lg shadow-elevation-1 transition-all duration-300 ${
      isInComparison ? 'ring-2 ring-primary' : 'hover:shadow-elevation-2'
    } ${isExpired ? 'opacity-60' : ''}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Building" size={20} className="text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{offer?.agency?.name}</h3>
              <div className="flex items-center space-x-2 mt-1">
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={14} className="text-warning fill-current" />
                  <span className="text-sm font-medium">{offer?.agency?.rating}</span>
                </div>
                <span className={`px-2 py-0.5 text-xs rounded-full ${reliabilityBadge?.color}`}>
                  {reliabilityBadge?.label}
                </span>
                <span className="text-xs text-muted-foreground">
                  {offer?.agency?.distance}km
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {showComparison && (
              <Button
                variant={isInComparison ? "default" : "outline"}
                size="sm"
                onClick={() => onToggleComparison(offer?.id)}
              >
                <Icon name={isInComparison ? "Check" : "Plus"} size={14} />
              </Button>
            )}
            <div className={`px-2 py-1 rounded-md text-xs font-medium ${
              isExpired ? 'bg-error/10 text-error' : 'bg-warning/10 text-warning'
            }`}>
              {timeRemaining}
            </div>
          </div>
        </div>
      </div>
      {/* Vehicle Images */}
      <div className="relative">
        <div className="flex overflow-x-auto space-x-2 p-4 pb-2">
          {offer?.vehicle?.images?.map((image, index) => (
            <div key={index} className="flex-shrink-0 w-24 h-20 rounded-md overflow-hidden">
              <Image
                src={image}
                alt={`${offer?.vehicle?.model} - Image ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
        
        {/* Vehicle Info Overlay */}
        <div className="absolute bottom-2 left-4 bg-surface/90 backdrop-blur-sm rounded-md px-2 py-1">
          <p className="text-sm font-medium text-foreground">
            {offer?.vehicle?.brand} {offer?.vehicle?.model}
          </p>
          <p className="text-xs text-muted-foreground">
            {offer?.vehicle?.year} • {offer?.vehicle?.transmission} • {offer?.vehicle?.fuel}
          </p>
        </div>
      </div>
      {/* Pricing */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="text-2xl font-bold text-foreground">
              {offer?.pricing?.dailyRate}€
              <span className="text-sm font-normal text-muted-foreground">/jour</span>
            </p>
            <p className="text-sm text-muted-foreground">
              Total: {offer?.pricing?.totalAmount}€ ({offer?.pricing?.duration} jours)
            </p>
          </div>
          
          {offer?.pricing?.discount > 0 && (
            <div className="text-right">
              <p className="text-sm text-success font-medium">
                -{offer?.pricing?.discount}€ remise
              </p>
              <p className="text-xs text-muted-foreground line-through">
                {offer?.pricing?.originalAmount}€
              </p>
            </div>
          )}
        </div>

        {/* Pricing Breakdown */}
        <div className="space-y-1 text-xs text-muted-foreground">
          <div className="flex justify-between">
            <span>Location ({offer?.pricing?.duration} jours)</span>
            <span>{offer?.pricing?.baseAmount}€</span>
          </div>
          {offer?.pricing?.insurance > 0 && (
            <div className="flex justify-between">
              <span>Assurance</span>
              <span>{offer?.pricing?.insurance}€</span>
            </div>
          )}
          {offer?.pricing?.extras > 0 && (
            <div className="flex justify-between">
              <span>Options</span>
              <span>{offer?.pricing?.extras}€</span>
            </div>
          )}
        </div>
      </div>
      {/* Features */}
      <div className="p-4 border-b border-border">
        <h4 className="text-sm font-medium text-foreground mb-2">Inclus</h4>
        <div className="grid grid-cols-2 gap-2">
          {offer?.features?.map((feature, index) => (
            <div key={index} className="flex items-center space-x-2">
              <Icon name="Check" size={14} className="text-success" />
              <span className="text-sm text-muted-foreground">{feature}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Expanded Details */}
      {isExpanded && (
        <div className="p-4 border-b border-border bg-muted/30 animate-slide-down">
          <div className="space-y-3">
            <div>
              <h5 className="text-sm font-medium text-foreground mb-1">Conditions</h5>
              <p className="text-sm text-muted-foreground">{offer?.terms}</p>
            </div>
            
            <div>
              <h5 className="text-sm font-medium text-foreground mb-1">Politique d'annulation</h5>
              <p className="text-sm text-muted-foreground">{offer?.cancellationPolicy}</p>
            </div>

            <div>
              <h5 className="text-sm font-medium text-foreground mb-1">Contact agence</h5>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-1">
                  <Icon name="Phone" size={14} className="text-muted-foreground" />
                  <span className="text-muted-foreground">{offer?.agency?.phone}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Mail" size={14} className="text-muted-foreground" />
                  <span className="text-muted-foreground">{offer?.agency?.email}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Actions */}
      <div className="p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex-1"
          >
            <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={16} />
            <span className="ml-1">{isExpanded ? 'Masquer' : 'Voir détails'}</span>
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onViewDetails(offer)}
          >
            <Icon name="ExternalLink" size={16} />
          </Button>
        </div>

        {!isExpired && (
          <div className="space-y-2">
            <Button
              variant="default"
              fullWidth
              onClick={() => onAcceptOffer(offer, 'escrow')}
              disabled={isExpired}
            >
              <Icon name="Shield" size={16} />
              <span className="ml-2">Accepter avec séquestre</span>
            </Button>
            
            <Button
              variant="outline"
              fullWidth
              onClick={() => onAcceptOffer(offer, 'location')}
              disabled={isExpired}
            >
              <Icon name="MapPin" size={16} />
              <span className="ml-2">Payer sur place</span>
            </Button>
          </div>
        )}

        {isExpired && (
          <div className="text-center py-2">
            <p className="text-sm text-error">Cette offre a expiré</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OfferCard;