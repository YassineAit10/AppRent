import React, { useState, useEffect } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const OnboardingTooltip = ({ isVisible, onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const benefits = [
    {
      icon: 'Shield',
      title: 'Disponibilité garantie',
      description: 'Fini les véhicules fantômes ! Chaque offre est vérifiée et garantie disponible.',
      color: 'text-success'
    },
    {
      icon: 'CreditCard',
      title: 'Paiement sécurisé',
      description: 'Vos fonds sont protégés en séquestre jusqu\'à confirmation de votre réservation.',
      color: 'text-primary'
    },
    {
      icon: 'Clock',
      title: 'Réponse rapide',
      description: 'Recevez des offres personnalisées en moins de 2 heures après votre demande.',
      color: 'text-warning'
    }
  ];

  useEffect(() => {
    if (!isVisible) return;

    const timer = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % benefits?.length);
    }, 4000);

    return () => clearInterval(timer);
  }, [isVisible, benefits?.length]);

  if (!isVisible) return null;

  const currentBenefit = benefits?.[currentStep];

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-popover border border-border rounded-lg shadow-elevation-3 p-4 animate-slide-up z-tooltip">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          <div className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center ${currentBenefit?.color}`}>
            <Icon name={currentBenefit?.icon} size={16} />
          </div>
          <h4 className="font-semibold text-foreground text-sm">
            {currentBenefit?.title}
          </h4>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="w-6 h-6 -mt-1 -mr-1"
        >
          <Icon name="X" size={14} />
        </Button>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        {currentBenefit?.description}
      </p>
      <div className="flex items-center justify-between">
        <div className="flex space-x-1">
          {benefits?.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentStep ? 'bg-primary' : 'bg-muted'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentStep((prev) => (prev - 1 + benefits?.length) % benefits?.length)}
          >
            <Icon name="ChevronLeft" size={14} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentStep((prev) => (prev + 1) % benefits?.length)}
          >
            <Icon name="ChevronRight" size={14} />
          </Button>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-border">
        <p className="text-xs text-muted-foreground text-center">
          Rejoignez des milliers de clients satisfaits
        </p>
      </div>
    </div>
  );
};

export default OnboardingTooltip;