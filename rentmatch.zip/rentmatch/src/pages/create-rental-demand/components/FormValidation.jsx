import React, { useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const FormValidation = ({ 
  formData = {}, 
  errors = {},
  onValidationChange 
}) => {
  const validationRules = [
    {
      key: 'location',
      label: 'Lieu de prise en charge',
      required: true,
      validator: (data) => data?.location && data?.location?.address,
      message: 'Veuillez sélectionner un lieu de prise en charge'
    },
    {
      key: 'dates',
      label: 'Dates de location',
      required: true,
      validator: (data) => data?.pickupDate && data?.returnDate,
      message: 'Veuillez sélectionner les dates de début et fin'
    },
    {
      key: 'dateLogic',
      label: 'Cohérence des dates',
      required: true,
      validator: (data) => {
        if (!data?.pickupDate || !data?.returnDate) return true;
        return new Date(data.returnDate) > new Date(data.pickupDate);
      },
      message: 'La date de retour doit être postérieure à la date de prise en charge'
    },
    {
      key: 'categories',
      label: 'Catégories de véhicules',
      required: true,
      validator: (data) => data?.categories && data?.categories?.length > 0,
      message: 'Veuillez sélectionner au moins une catégorie de véhicule'
    },
    {
      key: 'budget',
      label: 'Budget',
      required: true,
      validator: (data) => data?.minBudget && data?.maxBudget && data?.minBudget < data?.maxBudget,
      message: 'Veuillez définir un budget valide'
    },
    {
      key: 'driverAge',
      label: 'Âge du conducteur',
      required: false,
      validator: (data) => {
        if (!data?.preferences?.driverAge) return true;
        const age = parseInt(data?.preferences?.driverAge);
        return age >= 18 && age <= 99;
      },
      message: 'L\'âge du conducteur doit être entre 18 et 99 ans'
    }
  ];

  const validateForm = () => {
    const newErrors = {};
    let isValid = true;

    validationRules?.forEach(rule => {
      if (!rule?.validator(formData)) {
        newErrors[rule.key] = rule?.message;
        if (rule?.required) {
          isValid = false;
        }
      }
    });

    if (onValidationChange) {
      onValidationChange(isValid, newErrors);
    }

    return { isValid, errors: newErrors };
  };

  React.useEffect(() => {
    validateForm();
  }, [formData]);

  const getValidationStatus = (rule) => {
    let isValid = rule?.validator(formData);
    const hasError = errors?.[rule?.key];
    
    if (hasError || !isValid) {
      return { status: 'error', icon: 'XCircle', color: 'text-error' };
    } else if (isValid) {
      return { status: 'success', icon: 'CheckCircle', color: 'text-success' };
    } else {
      return { status: 'pending', icon: 'Clock', color: 'text-muted-foreground' };
    }
  };

  const completedSteps = validationRules?.filter(rule => rule?.validator(formData))?.length;
  const totalSteps = validationRules?.filter(rule => rule?.required)?.length;
  const progressPercentage = (completedSteps / validationRules?.length) * 100;

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-medium text-foreground">Progression du formulaire</h4>
          <span className="text-sm text-muted-foreground">
            {completedSteps}/{validationRules?.length} étapes
          </span>
        </div>
        
        <div className="w-full bg-border rounded-full h-2 mb-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-300"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
        
        <p className="text-xs text-muted-foreground">
          {progressPercentage === 100 
            ? 'Formulaire complet - Prêt à publier !' 
            : `${Math.round(progressPercentage)}% complété`
          }
        </p>
      </div>
      {/* Validation Checklist */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground flex items-center">
          <Icon name="CheckSquare" size={16} className="mr-2 text-primary" />
          Liste de vérification
        </h4>
        
        <div className="space-y-2">
          {validationRules?.map((rule) => {
            const validation = getValidationStatus(rule);
            return (
              <div
                key={rule?.key}
                className={`flex items-center space-x-3 p-3 rounded-lg border ${
                  validation?.status === 'error' ?'border-error/20 bg-error/5' 
                    : validation?.status === 'success' ?'border-success/20 bg-success/5' :'border-border bg-background'
                }`}
              >
                <Icon 
                  name={validation?.icon} 
                  size={16} 
                  className={validation?.color} 
                />
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium ${
                    validation?.status === 'error' ? 'text-error' : 'text-foreground'
                  }`}>
                    {rule?.label}
                    {rule?.required && <span className="text-error ml-1">*</span>}
                  </p>
                  {errors?.[rule?.key] && (
                    <p className="text-xs text-error mt-1">{errors?.[rule?.key]}</p>
                  )}
                </div>
                {!rule?.required && (
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    Optionnel
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>
      {/* Form Summary */}
      {completedSteps >= totalSteps && (
        <div className="bg-success/5 border border-success/20 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Icon name="CheckCircle" size={20} className="text-success" />
            <div>
              <p className="text-sm font-medium text-success">Formulaire prêt à être publié</p>
              <p className="text-xs text-muted-foreground mt-1">
                Toutes les informations requises ont été renseignées
              </p>
            </div>
          </div>
        </div>
      )}
      {/* Error Summary */}
      {Object.keys(errors)?.length > 0 && (
        <div className="bg-error/5 border border-error/20 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="AlertCircle" size={20} className="text-error mt-0.5" />
            <div>
              <p className="text-sm font-medium text-error mb-2">
                {Object.keys(errors)?.length} erreur{Object.keys(errors)?.length > 1 ? 's' : ''} à corriger
              </p>
              <ul className="space-y-1">
                {Object.entries(errors)?.map(([key, message]) => (
                  <li key={key} className="text-xs text-error">
                    • {message}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
      {/* Tips for Better Offers */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">Conseils pour recevoir plus d'offres</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Soyez flexible sur les dates pour plus d'options</li>
              <li>• Ajoutez des photos de référence pour clarifier vos attentes</li>
              <li>• Détaillez vos besoins spécifiques dans les commentaires</li>
              <li>• Un budget réaliste attire des agences sérieuses</li>
              <li>• Répondez rapidement aux offres reçues</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormValidation;