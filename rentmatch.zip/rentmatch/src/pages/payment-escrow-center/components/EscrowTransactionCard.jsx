import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const EscrowTransactionCard = ({ transaction, onViewDetails, onDispute, onDownloadReceipt }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getStatusConfig = (status) => {
    const configs = {
      active: {
        color: 'text-primary',
        bgColor: 'bg-primary/10',
        icon: 'Shield',
        label: 'Fonds sécurisés'
      },
      pending: {
        color: 'text-warning',
        bgColor: 'bg-warning/10',
        icon: 'Clock',
        label: 'En attente'
      },
      released: {
        color: 'text-success',
        bgColor: 'bg-success/10',
        icon: 'CheckCircle',
        label: 'Libéré'
      },
      refunded: {
        color: 'text-secondary',
        bgColor: 'bg-secondary/10',
        icon: 'RotateCcw',
        label: 'Remboursé'
      },
      disputed: {
        color: 'text-error',
        bgColor: 'bg-error/10',
        icon: 'AlertTriangle',
        label: 'Litige'
      }
    };
    return configs?.[status] || configs?.pending;
  };

  const statusConfig = getStatusConfig(transaction?.status);

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    })?.format(amount);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-elevation-2 transition-shadow">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start space-x-3">
          <div className={`w-10 h-10 rounded-full ${statusConfig?.bgColor} flex items-center justify-center`}>
            <Icon name={statusConfig?.icon} size={20} className={statusConfig?.color} />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">
              Réservation #{transaction?.bookingReference}
            </h3>
            <p className="text-sm text-muted-foreground">
              {transaction?.vehicleType} • {transaction?.location}
            </p>
            <div className="flex items-center space-x-2 mt-1">
              <span className={`px-2 py-1 text-xs rounded-full ${statusConfig?.bgColor} ${statusConfig?.color} font-medium`}>
                {statusConfig?.label}
              </span>
              <span className="text-xs text-muted-foreground">
                {formatDate(transaction?.createdAt)}
              </span>
            </div>
          </div>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-foreground">
            {formatAmount(transaction?.totalAmount)}
          </p>
          <p className="text-sm text-muted-foreground">
            Dépôt: {formatAmount(transaction?.depositAmount)}
          </p>
        </div>
      </div>
      {/* Quick Info */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Calendar" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Dates</p>
          <p className="text-sm font-medium text-foreground">
            {new Date(transaction.startDate)?.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })} - 
            {new Date(transaction.endDate)?.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}
          </p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Building" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Agence</p>
          <p className="text-sm font-medium text-foreground">{transaction?.agencyName}</p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="CreditCard" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Méthode</p>
          <p className="text-sm font-medium text-foreground">{transaction?.paymentMethod}</p>
        </div>
        <div className="text-center p-2 bg-muted/30 rounded-md">
          <Icon name="Clock" size={16} className="text-muted-foreground mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Libération</p>
          <p className="text-sm font-medium text-foreground">
            {transaction?.releaseDate ? formatDate(transaction?.releaseDate) : 'En attente'}
          </p>
        </div>
      </div>
      {/* Expanded Details */}
      {isExpanded && (
        <div className="border-t border-border pt-3 mt-3 animate-slide-down">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Amount Breakdown */}
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Calculator" size={16} className="mr-2" />
                Détail des montants
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Prix de base:</span>
                  <span className="text-foreground">{formatAmount(transaction?.baseAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Options:</span>
                  <span className="text-foreground">{formatAmount(transaction?.optionsAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Taxes:</span>
                  <span className="text-foreground">{formatAmount(transaction?.taxAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Frais de service:</span>
                  <span className="text-foreground">{formatAmount(transaction?.serviceAmount)}</span>
                </div>
                <div className="border-t border-border pt-2 flex justify-between font-medium">
                  <span className="text-foreground">Total:</span>
                  <span className="text-foreground">{formatAmount(transaction?.totalAmount)}</span>
                </div>
              </div>
            </div>

            {/* Timeline */}
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Timeline" size={16} className="mr-2" />
                Chronologie
              </h4>
              <div className="space-y-2">
                {transaction?.timeline?.map((event, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm">
                    <div className={`w-2 h-2 rounded-full ${event?.completed ? 'bg-success' : 'bg-muted'}`}></div>
                    <span className={event?.completed ? 'text-foreground' : 'text-muted-foreground'}>
                      {event?.label}
                    </span>
                    {event?.date && (
                      <span className="text-xs text-muted-foreground ml-auto">
                        {formatDate(event?.date)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Release Conditions */}
          {transaction?.status === 'active' && transaction?.releaseConditions && (
            <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-md">
              <h4 className="font-medium text-primary mb-2 flex items-center">
                <Icon name="Info" size={16} className="mr-2" />
                Conditions de libération
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                {transaction?.releaseConditions?.map((condition, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <Icon name="Check" size={14} className="text-primary mt-0.5 flex-shrink-0" />
                    <span>{condition}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
      {/* Actions */}
      <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? 'Moins de détails' : 'Plus de détails'}
          <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} className="ml-1" />
        </Button>

        <div className="flex items-center space-x-2">
          {transaction?.status === 'released' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDownloadReceipt?.(transaction?.id)}
            >
              <Icon name="Download" size={16} className="mr-1" />
              Reçu
            </Button>
          )}
          
          {transaction?.status === 'active' && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDispute?.(transaction?.id)}
            >
              <Icon name="AlertTriangle" size={16} className="mr-1" />
              Litige
            </Button>
          )}
          
          <Button
            variant="default"
            size="sm"
            onClick={() => onViewDetails?.(transaction?.id)}
          >
            Voir détails
            <Icon name="ArrowRight" size={16} className="ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EscrowTransactionCard;